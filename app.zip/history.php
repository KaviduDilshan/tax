<div class="pages">
    <div data-page="team" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php include 'inc/top_header.php'; ?>

            <div id="pages_maincontent">

                <h2 class="page_title" style="text-align: center;"><strong>MY HISTORY & REPORTS</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <div class="swiper-container-team swiper-init" data-effect="slide" data-space-between="10" data-pagination=".swiper-pagination-team" data-slides-per-view="2">

                        <div class="page_single layout_fullwidth_padding">
                            <ul class="features_list">	
                                <li><a href="transaction_history.php"><img src="images/icons/black/tabs.png" alt="" title="" /><span>Transaction History</span></a></li>  		
                                <li><a href="my_customers.php"><img src="images/icons/black/tabs.png" alt="" title="" /><span>My Customers</span></a></li>
                                <li><a href="return_history.php"><img src="images/icons/black/tabs.png" alt="" title="" /><span>Return Product History</span></a></li>
                            </ul>
                            <div class="shop_pagination">
                                <a href="index.php" class="prev_shop">BACK</a>
                                <span class="shop_pagenr"> </span>
                                <a href="index.php" class="next_shop">BILLING</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>