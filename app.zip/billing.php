<?php
session_start();
include_once '../inc/functions.php'; 
if(!isset($_SESSION["user"])){
    header("location:../app/");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Maruti Admin</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
    </head>
    <body style="padding-top: 2%;">
        <div id="content" style="margin: 0px;">
            <div class="container-fluid">
                <div class="row-fluid">
                    <div class="span8">
                        <form action="data/transaction.php" method="post" class="form-horizontal">
                        <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                        <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                        <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                        <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
                            <div class="span12">
                                <div style="">
                                    <table class="table table-bordered " id="tab_logic" data-responsive="table" style="">
                                        <thead>
                                            <tr>
                                                <th> Product</th>
                                                <th> Qty </th>
                                                <th> Total </th>
                                                <th> Remove </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                $invoice = base64_decode($_GET["invoice"]);
                                $ret_det = getReturnDet($conn, $invoice);
                                $ret_user = getUserReturnDet($conn, ($_GET["c"]));
                                $ous_det = getUserTrans($conn, ($_GET["c"]));
                                $user_det = getUserDet($conn, ($_GET["c"]));
                                $ous_amount = $ous_det["SUM(total)"] - $ous_det["SUM(paid_amount)"] - $ret_user;
                                $re_tot = floatval($ret_det["SUM(total)"]);
                                $loop = 1;
                                $sales_re = getSalesByInvoice($conn, base64_decode($_GET["invoice"]));
                                $sub_tot = 0;
                                $full_url="c=".$_GET["c"]."&r=".$_GET["r"]."&invoice=".$_GET["invoice"]."&cat=".$_GET["cat"];
                                while ($row = mysqli_fetch_array($sales_re)) {
                                    $pro_id = $row["pro_id"];
                                    $pro_det = getProDet($conn, $pro_id);
                                    $sub_tot += (floatval($row["quantity"]) * $row["unit_price"]);
                                    $url = "?s=".$row["sales_id"]."&c=".$_GET["c"]."&r=".$_GET["r"]."&invoice=".$_GET["invoice"]."&cat=".$_GET["cat"];
                                    ?>
                                    <tr class="record">
                                        <td style=""><?= $pro_det["product_name"] ?></td>
                                       <td style=""><input type="text" style="width: 40px; text-align: center;" name="srow_quantity" id="srow_quantity" value='<?= $row["quantity"] ?>' class="span12 qty" readonly=""/></td>
                                       <td style=""><input type="text" style="width: 70px; text-align: right;" value='<?= number_format($row["total"], 2, ".", ",") ?>' class="span12 row_total" readonly=""/></td>
                                       <td style=""><a href='data/del_sales.php<?=$url?>'><button type="button" class="btn-sm btn-warning">X</button></a></td>
                                     </tr>
                                    <?php
                                    $loop++;
                                }
                                $g_tot = $sub_tot - $re_tot;
                                ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                    <div class="span4">
                        <div style="background-color: #fff; padding: 2%;">
                            <table class="table table-bordered" id="tab_logic_total" style="border: none">
                                <tbody>
                                    <tr>
                                        <th class="text-right" style="width: 60%;">Sub Total</th>
                                        <td class="form-group2">
                                            <input type="text" id="sub_total" value="<?= number_format($sub_tot, 2, ".", ",") ?>" readonly/>
                                        </td>
                                    </tr>
                                <?php
                                if ($user_det["credit_accept"] != 0) {
                                    $g_tot = ($sub_tot + $ous_amount);
                                    ?>
                                    <tr>
                                        <th class="text-right">Oustanding</th>
                                        <td class="form-group2">
                                            <input type="text" id="other_dis" value="<?= number_format($ous_amount, 2, ".", ",") ?>" placeholder="0.00" readonly/>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                   <tr>
                                        <th class="text-right" style="width: 60%;">Bill Amount</th>
                                        <td class="form-group2">
                                            <input type="text" id="total" value="<?=$g_tot?>" readonly required hidden>
                                            <input type="text" value="<?= number_format($g_tot, 2, ".", ",") ?>" readonly/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right">Paid Amount</th>
                                        <td class="form-group2">
                                            <input type="number" name="paid_amount" id="paid_amount"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="form-group2 text-right">Balance</th>
                                        <td class="form-group2 mb10">
                                            <input type="number" name="balance" id="balance" class="balance" readonly/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right">Return</th>
                                        <td class="form-group2">
                                            <input type="hidden" name="return" value="<?= $re_tot ?>">
                                            <input type="text" value="<?= number_format($re_tot, 2, ".", ",") ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right">Payment Type</th>
                                        <td class="form-group2">
                                            <select name="pay_type" style="width:75%;">
                                                <option value="1" >Cash</option>
                                                <!--<option value="2">Credit Card</option>-->
                                                <option value="3">Cheque</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="form-group2" style="margin-left: 15%; margin-top: 5%;">
                                <button type="submit" name="add" class="btn btn-success" style="width: 40%">Print Bill</button>
                                <a href="../app/#!/return.php?<?=$full_url?>" name="save_bill" class="btn btn-warning" style="width: 40%">Back</a>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="new/js/jquery.nicescroll.js"></script>
        <script src="new/js/scripts.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="new/js/bootstrap.min.js"></script>
        <!-- /Bootstrap Core JavaScript -->	   
        <!-- morris JavaScript -->	
        <script src="new/js/raphael-min.js"></script>
        <script src="new/js/morris.js"></script>
        <script>
                                                function reduceBal() {
                                                    localStorage.setItem("ch", $("#balance").val());
                                                    $("#balance").val("0.00");
                                                    document.getElementById("chec").setAttribute("onclick", "rec()");
                                                }
                                                function rec() {
                                                    $("#balance").val(localStorage.getItem("ch"));
                                                    localStorage.removeItem("ch");
                                                    document.getElementById("chec").setAttribute("onclick", "reduceBal()");
                                                }
                                            
                                                $("#paid_amount").on("input", function () {
                                                    var paid_amount = $(this).val();
                                                    var sub_total = $("#total").val();
                                                    var balance = (sub_total - paid_amount).toFixed(2);
                                                    $("#balance").val(balance);
                                                });
        </script>
    </body>
</html>