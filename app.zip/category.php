<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            session_start();
            include 'inc/top_header.php';
        //    include 'sessions.php';
            $_SESSION["tmp_invoice"] = $_GET["invoice"];
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>SELECT CATEGORY</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <ul class="features_list_block">
                        <?php
                        $cat_re = getCats($conn);
                        while ($row = mysqli_fetch_array($cat_re)) {
                            ?>
                            <li><a href="product.php?invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>&c=<?= $_GET["c"] ?>&cat=<?= base64_encode($row["category_id"]) ?>"><img src="images/icons/black/electronics.png" alt="" title="" /><span><?= $row["name"] ?></span></a></li>
                            <?php
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="customer.php?invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="shop.php" class="next_shop">PRODUCTS</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'inc/footer.php';
