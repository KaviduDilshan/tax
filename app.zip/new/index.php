<!DOCTYPE html>
<html>
    <head>
        <?php
        session_start();
        $_SESSION['from_home'] = 1;
        include 'inc/urls.php';
        $in2="";
         if (isset($_GET["invoice"]) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
            $in2="?invoice=" . $_GET["invoice"];
         }
        ?>
        <script>
            window.onbeforeunload = function() { window.location.href='index.php' };
        </script>
    </head>
    <body id="mobile_wrap">
        <!--Left & right Slide bar-->
        <?php include 'inc/slider.php'; ?>

        <div class="views">
            <div class="view view-main">
                <div class="pages">
                    <div data-page="index" class="page homepage">
                        <div class="page-content homepagecontent">	
                            <!--Top Header-->
                            <?php include 'inc/top_header.php'; ?>

                            <!-- Slider -->
                            <div class="swiper-container swiper-init" data-effect="slide" data-parallax="true" data-pagination=".swiper-pagination" data-pagination-clickable="true">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <img src="images/slider/3.jpg" alt="" title="" />
                                        <div class="slider-caption">
                                            <h2 data-swiper-parallax="-100%">VENRO CHANDANA AYURVEDIC</h2>
                                            <span class="subtitle" data-swiper-parallax="-60%">Kandy, Bogambara</span>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">		  
                                        <img src="images/slider/2.jpg" alt="" title="" />
                                        <div class="slider-caption">
                                            <h2 data-swiper-parallax="-100%">START BILLING WITH APP</h2>
                                            <span class="subtitle" data-swiper-parallax="-60%">Please login First</span>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <img src="images/slider/1.jpg" alt="" title="" />
                                        <div class="slider-caption">
                                            <h2 data-swiper-parallax="-100%">VIEW PRODUCTS</h2>
                                            <span class="subtitle" data-swiper-parallax="-60%">& Your History</span>
                                        </div>
                                    </div> 		   
                                </div>
                            </div>	
                            <div class="swiper-pagination"></div>						  

                            <nav class="main-nav">
                                <ul>
                                    <li><a <?= userLogined('customer.php'.$in2) ?>><img src="images/icons/green/form.png" alt="" title="" /><span>START BILLING</span></a></li>
                                    <li><a <?= userLogined('customer_list_view.php') ?>><img src="images/icons/green/building.png" alt="" title="" /><span>CUSTOMERS</span></a></li>
                                    <?php if (!userLogined()) { ?>
                                        <li><a href="#" data-popup=".popup-login" class="open-popup"><img src="images/icons/green/lock.png" alt="" title="" /><span>LOGIN</span></a></li>
                                            <?php } else { ?>
                                        <li><a href="#" onclick="logOut()"><img src="images/icons/green/logout.png" alt="" title="" /><span>LOGOUT</span></a></li>
                                    <?php } ?>
                                    <li><a <?= userLogined("pay_oustanding.php") ?>><img src="images/icons/green/more.png" alt="" title="" /><span>PAY OUSTANDING</span></a></li>
                                    <li><a <?= userLogined("cash_count.php") ?>><img src="images/icons/green/dribbble.png" alt="" title="" /><span>CASH COUNT</span></a></li>
                                    <li><a <?= userLogined("expenses.php") ?>><img src="images/icons/green/bus.png" alt="" title="" /><span>EXPENSES</span></a></li>
                                    <li><a <?= userLogined("shop.php") ?>><img src="images/icons/green/shop.png" alt="" title="" /><span>PRODUCT lIST</span></a></li>
                                    <li><a <?= userLogined("history.php") ?>><img src="images/icons/green/categories.png" alt="" title="" /><span>HISTORY</span></a></li>
                                    <li><a href="#" onclick="redirectTo('backup/index_f.php')"><img src="images/icons/green/toggle.png" alt="" title="" /><span>SYNC BILL</span></a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Popup -->
        <?php include 'inc/models.php'; ?>
        <?php include 'inc/footer.php'; ?>
    </body>
</html>