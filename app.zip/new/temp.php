<a href="bill_preview.php?c=<?= $user_det["c_id"] ?>&invoice=<?= base64_encode($last_trans_det["invoice"]) ?>&new_invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>&cat=0">
    <button type="button" class="form-control btn-sm btn-primary" style="font-size: 15px;">Old Bill - <strong>( <?php echo $user_det['customer_code']; ?> ) </strong></button></a>
<br>


<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
            include 'sessions.php';
            if (isset($_SESSION['from_home'])) {
            unset($_SESSION['from_home']);
            }
            $trans_det = getTransDetByInvoice($conn, $invoice);
            $user_det = getUserDet($conn, $customer);
            if ($trans_det != null) {
            $c_id = $user_det["c_id"];
            $this_t_id = intval($trans_det["t_id"]);
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>BILL PREVIEW</strong> ( <strong><?= $user_det["customer_code"] ?></strong> )</h2>
                <div class="contactform">
                    <div class="page_single layout_fullwidth_padding">

                        <ul class="responsive_table">
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;">CODE</div>
                                <div class="table_section">ITEM</div>
                                <div class="table_section_small">QTY</div> 
                                <div class="table_section_small">PRICE</div>
                                <div class="table_section_small">TOTAL</div>
                            </li>
                            <?php
                            $ret_det = getReturnDet($conn, $invoice);
                            $ous_det = getUserTrans($conn, $customer);
                            $query = "SELECT MAX(t_id) FROM transaction WHERE t_id < $this_t_id AND c_id=$c_id";
                            $prev_trans_t_id = mysqli_fetch_assoc(mysqli_query($conn, $query))["MAX(t_id)"];
                            $last_trans_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM transaction WHERE t_id = \"$prev_trans_t_id\""));
                            $ous_amount = floatval($last_trans_det["ous"]);
                            $re_tot = floatval($ret_det["SUM(total)"]);
                            $date_last = $last_trans_det["transaction_date"];
                            $loop = 1;
                            $sales_re = getSalesByInvoice($conn, $invoice);
                            $sub_tot = 0;
                            while ($row = mysqli_fetch_array($sales_re)) {
                            $pro_id = $row["pro_id"];
                            $pro_det = getProDet($conn, $pro_id);
                            $sub_tot += (floatval($row["quantity"]) * $row["unit_price"]);
                            $fqty = '';
                            $freeTot = getFreeItem($conn, $pro_id, $invoice);
                            if ($freeTot > 0) {
                            $fqty = ' - ( ' . $freeTot . ' )';
                            }
                            ?>
                            <li class="table_row" id="s_row_<?= $loop ?>">
                                <div class="table_section_small text-right" style="width: 15px;"><strong><?= $pro_det["barcode"] ?></strong></div>
                                <div class="table_section"><?= $pro_det["product_name"] . $fqty ?></div>
                                <div class="table_section_small"><?= $row["quantity"] ?></div> 
                                <div class="table_section_small"><?= number_format($row["unit_price"], 2, ".", ",") ?></div>
                                <div class="table_section_small"><?= number_format($row["total"], 2, ".", ",") ?></div> 
                            </li>
                            <?php
                            $loop++;
                            }
                            ?>
                            <li class="table_row" style="margin-top: 10px;">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Last Billing Date</strong> </div>
                                <div class="table_section_small"><strong>-</strong></div> 
                                <div class="table_section_small2"><strong><?= $date_last ?></strong></div> 
                            </li>
                            <li class="table_row" style="margin-top: 10px;">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Sub Total</strong> </div>
                                <div class="table_section_small"><strong><?= ($loop - 1) ?></strong></div> 
                                <div class="table_section_small2"><strong><?= number_format($sub_tot, 2, ".", ",") ?></strong></div> 
                            </li>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Return</strong> </div>
                                <div class="table_section_small"><strong> <?= floatval($ret_det["SUM(quantity)"]) ?> </strong></div> 
                                <div class="table_section_small2"><strong><?= number_format($re_tot, 2, ".", ",") ?></strong></div> 
                            </li>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Free Items</strong> </div>
                                <div class="table_section_small"><strong> <?= floatval(getFreeSales($conn, $invoice)["SUM(quantity)"]) ?> </strong></div> 
                                <div class="table_section_small2"><strong></strong></div> 
                            </li>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Total Amount</strong> </div>
                                <div class="table_section_small"><strong> - </strong></div> 
                                <div class="table_section_small2"><strong><?= number_format((($sub_tot) - $re_tot), 2, ".", ",") ?></strong></div> 
                            </li>
                            <?php
                            if ($user_det["credit_accept"] != 0) {
                            ?>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Oustanding</strong> </div>
                                <div class="table_section_small"><strong> - </strong></div> 
                                <div class="table_section_small2"><strong><?= number_format($ous_amount, 2, ".", ",") ?></strong></div> 
                            </li>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Grand Total</strong> </div>
                                <div class="table_section_small"><strong> - </strong></div> 
                                <div class="table_section_small2"><strong><?= number_format((($sub_tot + $ous_amount) - $re_tot), 2, ".", ",") ?></strong></div> 
                            </li>
                            <?php } ?>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Paid Amount</strong> </div>
                                <div class="table_section_small"><strong> - </strong></div> 
                                <div class="table_section_small2"><strong><?= number_format(floatval($trans_det["paid_amount"]), 2, ".", ",") ?></strong></div> 
                            </li>
                            <li class="table_row">
                                <div class="table_section_small" style="width: 15px;"> - </div>
                                <div class="table_section"> <strong>Balance</strong> </div>
                                <div class="table_section_small"><strong> - </strong></div> 
                                <div class="table_section_small2"><strong><?= number_format((($sub_tot + $ous_amount) - $re_tot) - (floatval($trans_det["paid_amount"])), 2, ".", ",") ?></strong></div> 
                            </li>
                        </ul>
                    </div>
                    <div class="shop_pagination">
                        <?php
                        if (isset($_GET["new_invoice"])) {
                        $full_url = "?c=" . base64_decode($_GET["c"]) . "&r=" . $_GET["r"] . "&invoice=" . $_GET["new_invoice"] . "&cat=" . $_GET["cat"];
                        ?>
                        <a href="#" onclick="redirectTo('return2.php<?= $full_url ?>')" class="prev_shop">BACK</a>
                        <?php
                        } else {
                        ?>
                        <a href="transaction_history.php" class="prev_shop">BACK</a>
                        <?php } ?>
                        <span class="shop_pagenr"> </span>
                        <a href="#" onclick="redirectTo('bill_print/woosim/print.php<?= "?c=" . base64_decode($_GET["c"]) . "&r=" . $_GET["r"] . "&invoice=" . $_GET["invoice"] . "&new_invoice=" . $_GET["new_invoice"] . "&cat=" . $_GET["cat"] ?>&type=3')" class="prev_shop">Print</a>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<?php
include 'inc/footer.php';
}
?>
