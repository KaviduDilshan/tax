
function reduceBal() {
    localStorage.setItem("ch", $("#balance").val());
    $("#balance").val("0.00");
    document.getElementById("chec").setAttribute("onclick", "rec()");
}
function rec() {
    $("#balance").val(localStorage.getItem("ch"));
    localStorage.removeItem("ch");
    document.getElementById("chec").setAttribute("onclick", "reduceBal()");
}

$(document).ready(function () {
    $('#tab_logic tbody').on('keyup change', function () {
        calc();
    });
    $('#tax').on('keyup change', function () {
        calc_total();
    });
    $('#paid_amount').on('keyup change', function () {
        calc_total();
    });

});

function calc()
{
    $('#tab_logic tbody tr').each(function (i, element) {
        var html = $(this).html();
        if (html != '')
        {
            var qty = $(this).find('.qty').val();
            var price = $(this).find('.price').val();
            $(this).find('.total').val((qty * price).toFixed(2));

            calc_total();
        }
    });
}

calc();

function calc_total()
{
    var total = 0;
    $('.total').each(function () {
        total += parseFloat($(this).val());
    });
    var other_dis = $('#other_dis').val();
    $('#sub_total').val(total.toFixed(2));
    var tax_sum = total / 100 * $('#tax').val();
    $('#tax_amount').val(tax_sum.toFixed(2));
    $('#total_amount').val((total - tax_sum - other_dis).toFixed(2));
    var total2 = $('#total_amount').val();
    var paid2 = $('#paid_amount').val();
    var paid = paid2 - total2;
    $('#balance').val(paid.toFixed(2));
    localStorage.setItem("ch", paid.toFixed(2));
}