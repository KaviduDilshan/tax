<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            session_start();
            include 'inc/top_header.php';
            include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>TRANSACTION HISTORY</strong></h2>
                <div class="contactform">
                    <form method="post" action="data/trans_find.php" class="cmxform" id="ContactForm">
                        <input type="text" name="user" value="<?=base64_encode($_SESSION["user"]["a_id"])?>" readonly hidden required>
                        <div class="form_row">
                                <label>CUSTOMER CODE:</label>
                                <input type="text" name="c_code" value="" class="form_input">
                            </div>
                            <input type="submit" name="add" value="FIND" class="form_submit">
                    </form>
                </div>
                <div class="page_single layout_fullwidth_padding">
                    
                    <ul class="responsive_table">
                        <li class="table_row">
                            <div class="table_section_small" style="width: 15px;">#</div>
                            <div class="table_section_small">BILL</div>
                            <div class="table_section_small">C.CODE</div>
                            <div class="table_section">DATE</div>
                            <div class="table_section_small">TOTAL</div>
                        </li>
                        <?php
                        if(!isset($_GET["t"])){
                        $trans_re = getCusTransByUser($conn, $_SESSION["user"]["a_id"]);
                        while ($row = mysqli_fetch_array($trans_re)) {
                             $cus_det = getUserDet($conn, $row["c_id"]);
                            $c_code=trim($cus_det["customer_code"]);
                            if($c_code==null){
                                $c_code="-";
                            }
                            ?>
                            <li class="table_row">
                                <div class="table_section_small text-right" style="width: 15px; color: green;"><a href="bill_preview.php?invoice=<?= base64_encode($row["invoice"]) ?>&c=<?= base64_encode($cus_det["c_id"]) ?>"><strong>#</strong></a></div>
                                <div class="table_section_small"><?= $row["t_id"] ?></div>
                                <div class="table_section_small"><?= $c_code ?></div> 
                                <div class="table_section"><?= explode(" ", $row["transaction_date"])[0] ?></div> 
                                <div class="table_section_small"><?= number_format($row["total"], 2, ".", ",") ?></div> 
                            </li>
                            <?php
                        }
                        }else{
                            $t_id=base64_decode(trim($_GET["t"]));
                            $trans_det=getTransDetByID($conn, $t_id) ;
                            if($trans_det!=null){
                                $cus_det = getUserDet($conn, $trans_det["c_id"]);
                                ?>
                            <li class="table_row">
                                <div class="table_section_small text-right" style="width: 15px; color: green;"><a href="bill_preview.php?invoice=<?= base64_encode($trans_det["invoice"]) ?>&c=<?= base64_encode($cus_det["c_id"]) ?>"><strong>#</strong></a></div>
                                <div class="table_section_small"><?= $trans_det["t_id"] ?></div>
                                <div class="table_section_small"><?= $cus_det["customer_code"] ?></div> 
                                <div class="table_section"><?= explode(" ", $trans_det["transaction_date"])[0] ?></div> 
                                <div class="table_section_small"><?= number_format($trans_det["total"], 2, ".", ",") ?></div> 
                            </li>
                            <?php
                            }
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="history.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="index.php" class="next_shop">HOME</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>