<?php
include_once '../inc/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <?php
        session_start();
        $max_s_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(sales_id) FROM sales_order"))["MAX(sales_id)"]) + 1;
        $max_t_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(t_id) FROM transaction"))["MAX(t_id)"]) + 1;
        $invoice = base64_encode($_SESSION["user"]["a_id"] . (($max_s_id * $max_t_id) * mt_rand(100, 1000) * mt_rand(10000, 100000)));
        
        $in2 = "&invoice=" . $invoice;
        
        $_SESSION['from_home'] = 1;
//        $in2 = "";
//        if (isset($_GET["invoice"]) && ($_GET["r_id"] != null) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
//            $in2 = "&invoice=" . $_GET["invoice"];
//        }
        ?>
        <script>
            window.onbeforeunload = function () {
                window.location.href = 'index.php';
            };
        </script>
        <title>Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 5%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> SELECT CUSTOMER </strong></h5></div><br>
        <div class="col col-sm-12">
            <div class="row">
                <div class="col col-sm-12">
                    <a <?= userLogined('new_customer.php' . $in2) ?> style="width: 100%; background-color: #9d0000;"><span>ADD NEW CUSTOMER</span></a><br>
                </div> <br>
            </div>
            <div class="row">
                <?php
                    $r_id = isset($_GET["r_id"]);
                    $query_cus = "SELECT * FROM `customer` WHERE r_id=$r_id";
                    $result_cus = mysqli_query($conn, $query_cus);
                    while ($row_cus = mysqli_fetch_array($result_cus)) {
                        ?>
                        <div class="col col-sm-12">
                            <a <?= userLogined('return2.php?c=' . $row_cus['c_id'] . "&r_id=" . $r_id . $in2) ?> style="width: 100%; background-color: #007aff;"><span><?php echo $row_cus['customer_name']; ?> | <?php echo $row_cus['customer_code']; ?></span></a><br>
                        </div> <br>
                        <?php
                    }
                    ?>
            </div>
        </div>
    </body>
</html>