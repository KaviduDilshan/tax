<?php include_once 'sessions.php'; ?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 2%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> SUBMIT YOUR CASH </strong></h5></div><br>
        <div class="col col-sm-12">
            <form method="post" action="data/cash_count.php">
                <input type="text" Placeholder="Route Number" name="route" class="form-control" required>
                <br>
                <table class="table-bordered" style="width: 100%; background-color: #fff">
                    <tr>
                        <th style="width: 40%;">CASH</th>
                        <th style="width: 25%;">COUNT</th>
                        <th style="width: 35%;">TOTAL</th>
                    </tr>
                    <tr>
                        <td style="width: 40%;"><input type="number" name="cash" value="5000.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_5000" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_5000" readonly style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="cash" value="1000.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_1000" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_1000" readonly style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="cash" value="500.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_500" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_500" readonly style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="cash" value="100.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_100" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_100" readonly style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="cash" value="50.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_50" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_50" readonly style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="cash" value="20.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_20" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_20" readonly style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <td><input type="number" name="cash" value="10.00" readonly style="width: 100%;"></td>
                        <td><input type="number" class="counts" name="count_10" placeholder="0" style="width: 100%;"></td>
                        <td><input type="number" name="total_10" readonly style="width: 100%;"></td>
                    </tr>
                </table>
                <br>
                <input type="submit" name="add" class="btn btn-success" value="NEXT" style="width: 100% ;"/>
            </form>
            <br>
            <a href="index.php" class="btn btn-primary" style="width: 100%;">BACK TO HOME</a>
            <br>
        </div>
    </body>
    <script type="text/javascript" src="js/calc_c_count.js"></script>
</html>

