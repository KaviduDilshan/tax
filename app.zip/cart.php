<div class="pages">
    <div data-page="cart" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php include 'inc/top_header.php'; ?>
            <div id="pages_maincontent">
                <h2 class="page_title">FINAL STEP</h2>

                <div class="page_single layout_fullwidth_padding">	
                    <div class="cartcontainer">            
                        <div class="cart_item" id="cartitem1">
                            <div class="item_title"><span>01.</span> Vehicle Title</div>
                            <div class="item_thumb"><a href="shop-item.html" class="close-panel"><img src="images/photos/photo1.jpg" alt="" title="" /></a></div>
                            <div class="item_qnty">
                                <p>(Vehical Overview) Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.</p>
                            </div>  
                        </div>
                        <div class="page_single layout_fullwidth_padding">
                            <div class="contactform">
                                <form method="POST" action="#">
                                    <div class="form_row">
                                        <label>Name:</label>
                                        <input type="text" name="name" value="Dinesh Rajapakshe" class="form_input" readonly/>
                                    </div>

                                    <div class="form_row">
                                        <label>Email:</label>
                                        <input type="text" name="email" value="dinesh@mail.com" class="form_input" readonly />
                                    </div>

                                    <div class="form_row">
                                        <label>Contact Number:</label>
                                        <input type="text" name="email" value="077777777" class="form_input" readonly />
                                    </div>

                                    <div class="form_row">
                                        <label>From Date:</label>
                                        <input type="date" name="email" value="" class="form_input" />
                                    </div>
                                    <div class="form_row">
                                        <label>To Date:</label>
                                        <input type="date" name="email" value="" class="form_input" />
                                    </div>
                                    <div class="form_row"> 
                                        <label>Message:</label>
                                        <textarea name="message" class="form_textarea" rows="" cols="">your message here</textarea>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <a href="success.php" class="button_full btyellow">PROCEED TO HIRE</a>           

                    </div>


                </div>

            </div>


        </div>
    </div>
</div>