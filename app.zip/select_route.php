<?php
include_once '../inc/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <?php
        session_start();
        $_SESSION['from_home'] = 1;
        $in2 = "";
        if (isset($_GET["invoice"]) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
            $in2 = "&invoice=" . $_GET["invoice"];
        }
        ?>
        <script>
            window.onbeforeunload = function () {
                window.location.href = 'index.php';
            };
        </script>
        <title>Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 5%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> SELECT ROUTE </strong></h5></div><br>
        <div class="col col-sm-12">
            <div class="row">
                <?php
                    $query_rou = "SELECT * FROM `route`";
                    $result_rou = mysqli_query($conn, $query_rou);
                    while ($row_rou = mysqli_fetch_array($result_rou)) {
                        ?>
                        <div class="col col-sm-12">
                            <a <?= userLogined('select_customer.php?r_id=' . $row_rou['r_id'] . $in2) ?> style="width: 100%; background-color: #007aff;"><span><?php echo $row_rou['name']; ?></span></a><br>
                        </div> <br>
                        <?php
                    }
                    ?>
            </div>
        </div>
    </body>
</html>