<?php
//if (!isset($_GET['id'])) {
    ?>
    <!--<a href="my.bluetoothprint.scheme://http://localhost/bill_print/response.php?id=45"><h1>Print</h1></a>-->
    <?php
//} else {

    session_start();
    $_SESSION['from_print'] = 1;
    include '../../conn.php';
    include '../../inc/functions.php';
    $con = $conn;

    if (isset($_GET["invoice"]) && !isset($_SESSION['from_home'])) {
        $invoice = base64_decode($_GET["invoice"]);
        $ret_det = getReturnDet($conn, $invoice);
        $re_tot = floatval($ret_det["SUM(total)"]);
        $free_count = intval(getFreeCount($con, $invoice));
        $trans = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM transaction WHERE invoice='$invoice'"));
        $res_id = $trans['t_id'];
        $c_id = $trans['c_id'];
        $cc_coden = $trans["c_id"];
        $cus_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM customer WHERE `c_id`=\"$cc_coden\""));
        $res_date = $trans['transaction_date'];

        $tmp_sql = "SELECT sum(sub_total),sum(rturn),sum(discount),sum(paid_amount),sum(paid_cheque) FROM `transaction` WHERE `c_id`=\"$cc_coden\"";
        $last_trans_det = mysqli_fetch_assoc(mysqli_query($conn, $tmp_sql));
        $ous_amount = floatval($last_trans_det["sum(sub_total)"] - ($last_trans_det["sum(rturn)"] + $last_trans_det["sum(discount)"] + $last_trans_det["sum(paid_amount)"] + $last_trans_det["sum(paid_cheque)"]));

        $total_pro = mysqli_num_rows(mysqli_query($con, "SELECT * FROM sales_order WHERE invoice='$invoice'"));

        $symbol_line = '------------------------------------------------';
//you can print text, image, barcode and QR code by sending request from your website. You just need to send data in JSON format
        $a = array();

//sending text entry
// $obj1->type = 0;//text
// $obj1->content = 'Sooriya Products';//any string	
// $obj1->bold = 1;//0 if no, 1 if yes
// $obj1->align =1;//0 if left, 1 if center, 2 if right
// $obj1->format = 1;//0 if normal, 1 if double Height, 2 if double Height + Width, 3 if double Width, 4 if small
// array_push($a,$obj1);
// sending image entry		
        $obj2->type = 1; //image
        $obj2->path = 'http://localhost/bill_print/logo.jpg'; //complete filepath on your web server; make sure that it is not big size
        $obj2->align = 1; //0 if left, 1 if center, 2 if right; set left align for big size images
        array_push($a, $obj2);

//sending barcode entry	
// $obj3->type = 2;//barcode
// $obj3->value = '1234567890123';//valid barcode value
// $obj3->width = 100;//valid barcode width
// $obj3->height = 50;//valid barcode height
// $obj3->align = 0;//0 if left, 1 if center, 2 if right
// array_push($a,$obj3);
//sending QR entry		
// $obj4->type = 3;//QR code
// $obj4->value = 'sample qr text';//valid QR code value
// $obj4->size = 40;//valid QR code size in mm
// $obj4->align = 2;//0 if left, 1 if center, 2 if right
// array_push($a,$obj4);
//sending empty line

        $obj5->type = 0; //text
        $obj5->content = " "; //empty line
        $obj5->bold = 0;
        $obj5->align = 0;
        array_push($a, $obj5);

//sending multi lines text
// $obj6->type = 0;//text
// $obj6->content = '200/1, Opalla, Galagedara | 0772691141 <br /><br />';//multiple lines text
// $obj6->bold = 0;
// $obj6->align = 1;
// array_push($a,$obj6);
// //sending multi lines text
// $obj7->type = 0;//text
// $obj7->content = " ";
// $obj7->bold = 0;
// $obj7->align = 0;
// array_push($a,$obj7);
//sending multi lines text
        $obj8->type = 0; //text
        $obj8->content = 'Item                       Qty             Total';
        $obj8->bold = 1;
        $obj8->align = 0;
        array_push($a, $obj8);

        $obj9->type = 0; //text
        $obj9->content = $symbol_line; //empty line
        $obj9->bold = 0;
        $obj9->align = 0;
        array_push($a, $obj9);

        $data = array(
            array("product_name" => "Parippu Luus 450KG XXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXX XXXXXXXXXXX XX", "qty" => 10.0, "total" => 1000.00),
            array("product_name" => "asdsadsad Lusadasus 450KG XXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXX XXXXXXXXXXX XX", "qty" => 18, "total" => 100.00),
            array("product_name" => "dddddddddddddd d 450KG XXXXXXXXXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXXXX XXXXXXXXXXX XX", "qty" => 18, "total" => 100.00)
        );

        $loop = 10;
        foreach ($data as $x => $x_value) {
            $item = $x_value["product_name"];
            $qty = $x_value["qty"];
            $total = $x_value["total"];

            $ex_sapce = "";
            $len = 21 - (strlen($qty) + strlen($total));

            for ($i = 0; $i < 27; $i++) {
                $ex_sapce .= " ";
            }

            $qty = $ex_sapce . $qty;
            $ex_sapce = "";

            for ($i = 0; $i < $len; $i++) {
                $ex_sapce .= " ";
            }

            $qty .= $ex_sapce;
            $data_set = ${'obj' . $loop}[0];

            //sending multi lines text
            $data_set->type = 0;
            $data_set->content = $item;
            $data_set->bold = 0;
            $data_set->align = 0;
            array_push($a, $data_set);
            $loop++;

            $data_set = ${'obj' . $loop}[0];
            //sending multi lines text
            $data_set->type = 0;
            $data_set->content = $qty . $total;
            $data_set->bold = 0;
            $data_set->align = 0;
            array_push($a, $data_set);
            $loop++;

            $data_set = ${'obj' . $loop}[0];
            //sending multi lines text

            $data_set->type = 0;
            $data_set->content = $symbol_line;
            $data_set->bold = 0;
            $data_set->align = 0;
            array_push($a, $data_set);
            $loop++;
        }

        $sub_total = $trans['sub_total'];
        $discount = $trans['discount'];
        $return = $trans['rturn'];
        $total = $sub_total - ($discount + $return);

        $outstanding = $ous_amount;
        $paid_amount = $trans['paid_cheque'] + $trans['paid_amount'];
        $grand_total = $trans['total'];

//sending multi lines text
        $obj12->type = 0;
        $obj12->content = "Sub Total : " . number_format($sub_total, 2, '.', ',');
        $obj12->bold = 1;
        $obj12->align = 2;
        array_push($a, $obj12);

//sending multi lines text
        $obj13->type = 0;
        $obj13->content = "Discount : " . number_format($discount, 2, '.', ',');
        $obj13->bold = 1;
        $obj13->align = 2;
        array_push($a, $obj13);

//sending multi lines text
        $obj14->type = 0;
        $obj14->content = "Return Amount : " . number_format($return, 2, '.', ',');
        $obj14->bold = 1;
        $obj14->align = 2;
        array_push($a, $obj14);

//sending multi lines text
        $obj15->type = 0;
        $obj15->content = "Total Amount : " . number_format($total, 2, '.', ',');
        $obj15->bold = 1;
        $obj15->align = 2;
        array_push($a, $obj15);

//sending multi lines text
        $obj16->type = 0;
        $obj16->content = "Outstanding : " . number_format($outstanding, 2, '.', ',');
        $obj16->bold = 1;
        $obj16->align = 2;
        array_push($a, $obj16);

//sending multi lines text
        $obj17->type = 0;
        $obj17->content = "Paid Amount : " . number_format($paid_amount, 2, '.', ',');
        $obj17->bold = 1;
        $obj17->align = 2;
        array_push($a, $obj17);

//sending multi lines text
        $obj18->type = 0;
        $obj18->content = $symbol_line;
        $obj18->bold = 0;
        $obj18->align = 0;
        array_push($a, $obj18);

//sending multi lines text
        $obj19->type = 0;
        $obj19->content = "Grand Total (Rs.): " . number_format($grand_total, 2, '.', ',');
        $obj19->bold = 1;
        $obj19->align = 2;
        $obj19->format = 1;
        array_push($a, $obj19);

//sending multi lines text
        $obj20->type = 0;
        $obj20->content = $symbol_line;
        $obj20->bold = 0;
        $obj20->align = 0;
        array_push($a, $obj20);

//sending multi lines text
        $obj21->type = 0;
        $obj21->content = "Thank You For Your Business!";
        $obj21->bold = 0;
        $obj21->align = 1;
        array_push($a, $obj21);

//sending multi lines text
        $obj22->type = 0;
        $obj22->content = "Developed By Tritcal Int. | 081-205 0436";
        $obj22->bold = 0;
        $obj22->align = 1;
        array_push($a, $obj22);

        $obj23->type = 0; //text
        $obj23->content = " "; //empty line
        $obj23->bold = 0;
        $obj23->align = 0;
        array_push($a, $obj23);

        echo json_encode($a, JSON_FORCE_OBJECT);
        
        ?>
        <script>
            window.location.href = '../../index.php';
        </script>
    <?php
    }
//}
?>