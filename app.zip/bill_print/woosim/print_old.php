<?php
session_start();
include '../../../conn.php';
include '../../../inc/functions.php';
$t = 1;
$row_height = 0;
$input_height = 35;
$con = $conn;
if (isset($_GET["invoice"])) {
    $invoice = base64_decode($_GET["invoice"]);
    $ret_det = getReturnDet($conn, $invoice);
    $re_tot = floatval($ret_det["SUM(total)"]);
    $free_count = intval(getFreeCount($con, $invoice));
    $trans = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM transaction WHERE invoice='$invoice'"));
    $res_id = $trans['t_id'];
    $c_id = $trans['c_id'];
    $cus_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM customer WHERE c_id=$c_id"));
    $res_date = $trans['transaction_date'];
    $t_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(t_id) FROM transaction WHERE c_id=$c_id AND invoice != '$invoice' AND status=0"))["MAX(t_id)"]);
    $ous_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM transaction WHERE t_id=$t_id"));
    $ous = floatval($trans["ous"]);
    $this_bill_ous = floatval($trans["ous"]);
    $total_pro = mysqli_num_rows(mysqli_query($con, "SELECT sales_id FROM sales_order WHERE invoice='$invoice'"));
    $url = "?c=" . $c_id . "&cat=&r=" . base64_encode($cus_det["r_id"]) . "&invoice=" . $_GET["invoice"] . "&prev=1";

    if ($total_pro > 2) {
        $prefer_height = 900 + ($total_pro * ($input_height + 90));
    } else {
        $prefer_height = 1500;
    }

    $chars_per_line = 60;
    $symbol_line = "";
    $symbol = "-";
    while ($chars_per_line > 0) {
        $symbol_line .= $symbol;
        $chars_per_line--;
    }
    $item_title = "Items";
    $qty = "Qty";
    $u_price = "Unit Price";
    $amount = "Amount";

    $ex_u_price = "";
    $u_price_len = strlen($u_price);
    while ($u_price_len < 15) {
        $ex_u_price .= " ";
        $u_price_len++;
    }
    $u_price .= $ex_u_price;
    $item_len = strlen($item_title);
    $item_space = $qty_apace = "";
    while ($item_len < 35) {
        $item_space .= " ";
        $item_len++;
    }
    $qty_len = strlen($qty);
    while ($qty_len < 15) {
        $qty_apace .= " ";
        $qty_len++;
    }
    $item_title .= $item_space;
    $qty .= $qty_apace;

    $base_row = $item_title . $qty . $amount;
    $item_row = "";

    $pay_type = $trans["pay_type"];
    $pay_type_txt = "Cash Payment";
    $this_bill_pay_amount = floatval($trans['paid_amount'])+floatval($trans['paid_cheque']);
    if ($pay_type == 2) {
        $pay_type_txt = "Cash And Cheque";
    } else if ($pay_type == 3) {
        $pay_type_txt = "Cheque Payment";
        $this_bill_pay_amount = floatval($trans['paid_cheque']);
    }
    ?>
    <!DOCTYPE html>
    <style>
        body,head{color:#666;font:14px "Roboto", sans-serif;-webkit-font-smoothing:antialiased;background-color:#eee}
    </style>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <script type="text/javascript" charset="utf-8" src='./js/jquery-1.11.1.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSEncoder-1.0.0.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSComm-1.0.0.min.js'></script>
            <style type="text/css"> @import url("./css/style.css");</style>
        </head>

        <body>
            <p align="center">
                <button id="print_but" onclick="print_sample(1)" class="buttons" style="display:none; width:300px; height:100px; font-size:20px;"><strong>- Another Copy -</strong></button><br>
                <button class="buttons" style="width:300px; height:100px; font-size:20px;"><a href="#" id="end_but" style="display:none; text-decoration:None;"><strong>- End Printing -</strong></a></button><br><br>
                <?php if ($_GET["type"] != 3) { ?>
                <button class="buttons" style="width:300px; height:100px; font-size:20px;"><a href="../../data/canel_bill.php<?= $url ?>" style=" text-decoration:None;"><strong>- Cancel -</strong></a></button>
            <?php } ?>
            <!--<br>-->
            <!--    <button class="buttons" style="width:300px; height:100px; font-size:20px;"><a href="http://my.bluetoothprint.scheme://https://venrochandana.com/app/bill_print/woosim/test_print.php" style=" text-decoration:None;"><strong>- Testing Purpose -</strong></a></button>-->
            </p>
            <br/>
            <p align="center" id="result">
            </p>
            <script type="text/javascript" charset="utf-8">
                var prefer_height = parseInt('<?php echo $prefer_height ?>');

                var finishedCallback = function (result) {
                    var code = result['ERR_CODE'];

                    switch (code)
                    {
                        case "0":
                            alert("Success");
                            break;
                        case "1":
                            alert("Printer is not connected.");
                            break;
                        case "4":
                            alert("Session is not opened.");
                            break;
                        default:
                            break;
                    }
                };

                function print_sample(ctype=0) {

                    var comm = new WSComm();
                    var encoder = new WSEncoder();

                    var printableXml = encoder.setPrintMode("page");

                    //1 inch:192 , 2 inch:384, 3 inch:576, 4 inch:768
                    printableXml += encoder.pm_setPrintingArea({x: 2, y: 0, width: 576, height: prefer_height});

                    printableXml += encoder.addText({width: 2, height: 2, data: "        VENRO AYURVEDIC"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 2, height: 2, data: "     MEDICINE DISTRIUBUTOR"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "   No 116/1/A Thalapitiya, Uduwela, Kandy. | Tel: 0767109232"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "           Email: info@venrochandana.com | Dr. No: 11936"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "        Reg. No: CPC/DS/PHT/2099 | Ayur No: 6/2/1/13/25"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "<?= $symbol_line ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(15);
                    printableXml += encoder.setFontSize(1);
                    printableXml += encoder.addText({width: 1, height: 1, data: "Date       : <?php echo $res_date ?>         Receipt No : <?php echo $res_id ?>"}), printableXml += encoder.addNewLine();
                    //  printableXml += encoder.addText({width: 1, height: 1, data: "Receipt No : <?php //echo $res_id           ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "Customer   : <?php echo ucwords($cus_det["customer_name"]) ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "Type       : <?php echo $pay_type_txt ?>"}), printableXml += encoder.addNewLine();
                    
                    
                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({width: 2, height: 1, data: "   BILL NO   :   <?=$res_id?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                    if(ctype > 0){
                         printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({width: 2, height: 1, data: "           BILL COPY"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                    }
                    //        printableXml += encoder.addText({width: 1, height: 1, data: ""}), printableXml += encoder.addNewLine();
                    // printableXml+= encoder.pm_setPosition({x:650, y:105}); 
                    // printableXml+= encoder.addText({data:"2015-01-27"}), printableXml+= encoder.addNewLine();
                    // printableXml+= encoder.setFontSize(0);
                    // printableXml+= encoder.pm_setPosition({x:650, y:5});
                    // printableXml+= encoder.addQrCode({version:0, level:'H', size:2, data:"www.woosim.com/english"});
                    // printableXml += encoder.pm_addBox({x: 0, y: 130, width: 384, height: 0, thickness: 2});
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(5);
                    printableXml += encoder.addText({data: "<?php echo $base_row ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    

    <?php
    $new_loop=1;
    $total_sales = mysqli_fetch_row(mysqli_query($con, "SELECT MAX(sales_id) FROM sales_order"))[0];
    while ($new_loop<=$total_sales) {
        $row = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM sales_order WHERE sales_id=$new_loop"));
        if ($row != null) {
            $tb_invo = $row["invoice"];
            if ($tb_invo == $invoice) {
                $tem_pn = "";
                $pro_id = $row["pro_id"];
                $free_items_per = floatval(mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM free_sales WHERE pro_id=$pro_id AND invoice='$invoice'"))["quantity"]);
                if ($free_items_per > 0) {
                    $free = " (Free - " . $free_items_per . ")";
                } else {
                    $free = " ";
                }
                $pro_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM products WHERE pro_id=$pro_id"));
                $pro_name = trim($pro_det['barcode']) . ". " . trim($pro_det['product_name']) . $free;
                $qty = trim($row["quantity"]);
                $amount = $row["total"];
                $rec_date = $row["date"];
                $len = strlen($pro_name);
                $len2 = strlen($qty);
                $row_u_price = dotInput($pro_det["unit_price"]);
                $len3 = strlen(dotInput($pro_det["unit_price"]));
                $ex_u_price_space = "";
                while ($len3 < 20) {
                    $ex_u_price_space .= " ";
                    $len3++;
                }
                $row_u_price .= $ex_u_price_space;
                if ($len2 < 15) {
                    $space2 = "";
                    $a = 15 - $len2;
                    while ($a > 0) {
                        $space2 .= " ";
                        $a--;
                    }
                    $qty .= $space2;
                } else {
                    $qty .= "  ";
                }
                if ($len > 33) {
                    $ex_txt = "";
                    $i = 0;
                    $loop = 33;
                    while ($i < $len) {
                        if ($i <= $loop) {
                            $tem_pn .= $pro_name[$i];
                            if ($i == 33) {
                                $tem_pn .= " " . $qty . dotInput($amount);

                                echo 'printableXml+= encoder.addText({data:"' . $tem_pn . '"}), printableXml+= encoder.addNewLine();';
                                // . "\n   "
                                $loop = 62;
                            }
                        }
                        if ($i <= 62 && $i >= 33) {
                            $ex_txt .= $pro_name[$i];
                            if ($i == 62) {
                                $ex_txt .= ".";
                            }
                        }
                        if ($i == 62) {
                            $tem_pn .= "..";
                        }
                        $i++;
                    }
                    $item_row .= $tem_pn;
                    //. "\n"
                } elseif ($len == 33) {
                    $item_row .= $pro_name . "  " . $qty . dotInput($amount);
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                } else {
                    $space = "";
                    $a = 35 - $len;
                    while ($a > 0) {
                        $space .= " ";
                        $a--;
                    }
                    $item_row .= $pro_name . $space . $qty . dotInput($amount);
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                }
                if (strlen($ex_txt) > 0) {
                    echo 'printableXml+= encoder.addText({data:"   ' . $ex_txt . '"}), printableXml+= encoder.addNewLine();';
                }
                echo 'printableXml+= encoder.addText({data:"' . $symbol_line . '"}), printableXml+= encoder.addNewLine();';
                $row_height += $input_height;
                $t++;
                $item_row = "";
            }
        }
        $new_loop++;
    }
// $tot_ous_n = ;
    $prev_bill_ous=floatval($ous_det["ous"]);
    $g_tot = (floatval($trans['sub_total']) + $ous) - $re_tot;
    $sub_total = "Sub Total                                       : " . dotInput(round($trans['sub_total'], 2));
    $return = "Return                                          : " . dotInput(round($re_tot), 2);
    $tot_t = "Bill Amount                                     : " . dotInput(round(floatval($trans['sub_total']) + floatval($prev_bill_ous)), 2);

    $cus_bla = $trans['sub_total'] + $ous;
    $paid = "Paid                                            : " . dotInput(round($this_bill_pay_amount, 2));
    $final = $cus_bla - $trans['paid_amount'];
    $final2 = $final - $re_tot;
    if($ous > 0){
        $total = "Oustanding (LKR)   : " . number_format($trans['ous'], 2, ".", ",");
    }else{
        $total = "Total (LKR)     : " . number_format(round(floatval($trans['sub_total']) + floatval($prev_bill_ous)), 2, ".", ",");
    }
    $balance = "Balance                                         : " . dotInput(round($trans['balance'], 2));
    $this_bill_ous_txt = "                                      : " . dotInput(round($this_bill_ous, 2));
    $oustanding = "Oustanding                                      : " . dotInput(round($ous_det["ous"], 2));
    $c_code = "Customer Code    :   " . trim($cus_det["customer_code"]);
    ?>
                    // printableXml += encoder.pm_addBox({x: 0, y: 270, width: 384, height: 0, thickness: 2});
                    // printableXml += encoder.pm_addBox({x: 0, y: 310, width: 115, height: 0, thickness: 2}), printableXml += encoder.pm_addBox({x: 260, y: 310, width: 124, height: 0, thickness: 2}), printableXml += encoder.addFeedNDot(15);
                    // printableXml += encoder.addFeedNLine(1);
                    // printableXml += encoder.addText({width: 2, height: 1, data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "  "}), printableXml += encoder.addNewLine();

                    // printableXml+= encoder.addText({data:"Number:         "});
                    // printableXml+= encoder.setFontSize(1);
                    // printableXml+= encoder.addText({data:"6688-9988-6644-3311"}), printableXml+= encoder.addNewLine();
                    // printableXml+= encoder.setFontSize(0);
                    printableXml += encoder.setFontSize(1);
                    printableXml += encoder.addText({data: "<?php echo $sub_total ?>"}), printableXml += encoder.addNewLine();
                    <?php if ($prev_bill_ous > 0) { ?>
                        printableXml += encoder.addText({data: "<?php echo $oustanding  ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $tot_t ?>"}), printableXml += encoder.addNewLine();
                    <?php } ?>
                        printableXml += encoder.addText({data: "<?php echo $return ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $paid ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $balance ?>"}), printableXml += encoder.addNewLine();

                        //     printableXml += encoder.addText({data: "<?php //echo $balance           ?>"}), printableXml += encoder.addNewLine();
                        //      printableXml += encoder.addText({data: "<?php //echo $this_bill_ous_txt           ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                            printableXml += encoder.addText({width: 2, height: 1, data: "<?php echo $total ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                        <?php if ($pay_type > 1) { ?>
                            printableXml += encoder.addText({data: "<?= $trans["check_no"] . " ( " . dotInput(round(floatval($trans["paid_cheque"]), 2)) . " )" ?>"}), printableXml += encoder.addNewLine();
                        <?php } ?>

                        // printableXml += encoder.pm_addBox({x: 0, y: 490, width: 384, height: 0, thickness: 2}), printableXml += encoder.addFeedNLine(15);
                        // printableXml += encoder.addText({data: "Total:                  $ 9.50"}), printableXml += encoder.addNewLine();
                        // printableXml+= encoder.addText({data:"Credit Card:            $ 9.50"}), printableXml+= encoder.addNewLine();
                        printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                        //      printableXml += encoder.addText({data: "Packed And Marketed By VENRO CHANDANA AYURVEDA"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "Signature: ..................................."}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "                Thank You For Your Business!"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "     Software By Tritcal International (Pvt) Ltd | Kandy"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "              081 20 50 437 | www.tritcal.com"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({width: 2, height: 2, data: ""}), printableXml += encoder.addNewLine();

                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({width: 2, height: 1, data: "<?php echo $c_code ?>"}), printableXml += encoder.addNewLine();
                        printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();

                        printableXml += encoder.setCutting(0);
                        printableXml += encoder.printData("page");
                        printableXml += encoder.setPrintMode("standard");

                        comm.send(printableXml);
                    }

                    print_sample();
                    document.getElementById("print_but").style.display = "block";
        <?php
        if ($_GET["type"] == 1) {
            ?>
                        document.getElementById("end_but").href = "../../index.php";
                        document.getElementById("end_but").style.display = "block";
            <?php
        } elseif ($_GET["type"] == 3) {
            ?>
                        document.getElementById("end_but").href = "../../../app/#!/bill_preview.php?c=<?= base64_encode($_GET["c"]) ?>&invoice=<?= ($_GET["invoice"]) ?>&new_invoice=<?= $_GET["new_invoice"] ?>&r=<?= $_GET["r"] ?>&cat=<?= $_GET["cat"] ?>";
                        document.getElementById("end_but").style.display = "block";
            <?php
        }
        else {
            ?>
                        document.getElementById("end_but").href = "../../transaction_history.php"";
                                document.getElementById("end_but").style.display = "block";
            <?php
        }
        ?>
                </script>
            </body>
        </html>
        <?php
    } 
    