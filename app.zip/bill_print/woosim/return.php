<?php
session_start();
include '../../../conn.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
include '../../../inc/functions.php';
$t = 1;
$row_height = 0;
$input_height = 20;
$con = $conn;
if (isset($_GET["invoice"])) {
    $invoice = base64_decode($_GET["invoice"]);
    $ret_det = getReturnDet($conn, $invoice);
    $re_tot = floatval($ret_det["SUM(total)"]);
    $free_count = intval(getFreeCount($con, $invoice));
    $trans = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM return_stock WHERE invoice='$invoice'"));
    $res_id = $trans['r_id'];
    $c_id = $trans['c_id'];
    $cus_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM customer WHERE c_id=$c_id"));
    $res_date = $trans['date'];
    $this_bill_ous = 0;
    $total_pro = mysqli_num_rows(mysqli_query($con, "SELECT r_id FROM return_stock WHERE invoice='$invoice'"));

    if ($total_pro > 2) {
        $prefer_height = 850 + ($total_pro * ($input_height + 75));
    } else {
        $prefer_height = 1000;
    }

    $chars_per_line = 60;
    $symbol_line = "";
    $symbol = "-";
    while ($chars_per_line > 0) {
        $symbol_line .= $symbol;
        $chars_per_line--;
    }
    $item_title = "Unit Price";
    $qty = "Qty";
    $u_price = "Unit Price";
    $amount = "Amount";

    $ex_u_price = "";
    $u_price_len = strlen($u_price);
    while ($u_price_len < 15) {
        $ex_u_price .= " ";
        $u_price_len++;
    }
    $u_price .= $ex_u_price;
    $item_len = strlen($item_title);
    $item_space = $qty_apace = "";
    while ($item_len < 35) {
        $item_space .= " ";
        $item_len++;
    }
    $qty_len = strlen($qty);
    while ($qty_len < 15) {
        $qty_apace .= " ";
        $qty_len++;
    }
    $item_title .= $item_space;
    $qty .= $qty_apace;

    $base_row = $item_title . $qty . $amount;
    $item_row = "";

    // $pay_type = $trans["pay_type"];
    $pay_type_txt = "Cash Payment";
    // if ($pay_type == 2) {
    //   $pay_type_txt = "Cheque Payment";
    // } else if ($pay_type == 3) {
    //     $pay_type_txt = "Cheque Payment";
    // }
    // 
    ?>
    <!DOCTYPE html>
    <style>
        body,head{color:#666;font:14px "Roboto", sans-serif;-webkit-font-smoothing:antialiased;background-color:#eee}
    </style>
    <html>
        <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <script type="text/javascript" charset="utf-8" src='./js/jquery-1.11.1.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSEncoder-1.0.0.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSComm-1.0.0.min.js'></script>
            <style type="text/css"> @import url("./css/style.css");</style>
        </head>

        <body>
            <p align="center">
                <button id="print_but" onclick="print_sample()" class="buttons" style="display:none; width:300px; height:100px; font-size:20px;"><strong>- Another Copy -</strong></button><br>
                <button class="buttons" style="width:300px; height:100px; font-size:20px;"><a href="#" id="end_but" style="display:none; text-decoration:None;"><strong>- Continue -</strong></a></button>
            </p>
            <br/>
            <p align="center" id="result">
            </p>
            <script type="text/javascript" charset="utf-8">
                var prefer_height = parseInt('<?php echo $prefer_height ?>');

                var finishedCallback = function (result) {
                    var code = result['ERR_CODE'];

                    switch (code)
                    {
                        case "0":
                            alert("Success");
                            break;
                        case "1":
                            alert("Printer is not connected.");
                            break;
                        case "4":
                            alert("Session is not opened.");
                            break;
                        default:
                            break;
                    }
                };

                function print_sample() {

                    var comm = new WSComm();
                    var encoder = new WSEncoder();

                    var printableXml = encoder.setPrintMode("page");

                    //1 inch:192 , 2 inch:384, 3 inch:576, 4 inch:768
                    printableXml += encoder.pm_setPrintingArea({x: 2, y: 0, width: 576, height: prefer_height});

                    printableXml += encoder.addText({width: 2, height: 2, data: "        VENRO AYURVEDIC"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 2, height: 2, data: "     MEDICINE DISTRIUBUTOR"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "   No 116/1/A Thalapitiya, Uduwela, Kandy. | Tel: 0776109232"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "           Email: info@venrochandana.com | Dr. No: 11936"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "        Reg. No: CPC/DS/PHT/2099 | Ayur No: 6/2/1/13/25"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "<?= $symbol_line ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(15);
                    printableXml += encoder.setFontSize(1);
                    printableXml += encoder.addText({width: 1, height: 1, data: "Date       : <?php echo $res_date ?>         Return No : <?php echo $res_id ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "Customer   : <?php echo ucwords($cus_det["customer_name"]) ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(5);
                    printableXml += encoder.addText({data: "<?php echo $base_row ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();

    <?php
                                $full_url="c=".$_GET["c"]."&r=".$_GET["r"]."&invoice=".$_GET["invoice"]."&cat=".$_GET["cat"];
    $total_sales = mysqli_fetch_row(mysqli_query($con, "SELECT MAX(r_id) FROM return_stock"))[0];
    while ($total_sales > 0) {
        $row = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM return_stock WHERE r_id=$total_sales"));
        if ($row != null) {
            $tb_invo = $row["invoice"];
            if ($tb_invo == $invoice) {
                $tem_pn = "";
                $pro_name = trim(dotInput(strval($row['unit_price'])));
                $qty = trim(strval($row["quantity"]));
                $amount = trim(strval($row["total"]));
                $rec_date = $row["date"];
                $len = strlen($pro_name);
                $len2 = strlen($qty);
                $row_u_price = dotInput($row["quantity"]);
                $len3 = strlen(dotInput($row["quantity"]));
                $ex_u_price_space = "";
                while ($len3 < 20) {
                    $ex_u_price_space .= " ";
                    $len3++;
                }
                $row_u_price .= $ex_u_price_space;
                if ($len2 < 15) {
                    $space2 = "";
                    $a = 15 - $len2;
                    while ($a > 0) {
                        $space2 .= " ";
                        $a--;
                    }
                    $qty .= $space2;
                } else {
                    $qty .= "  ";
                }
                if ($len > 33) {
                    $ex_txt = "";
                    $i = 0;
                    $loop = 33;
                    while ($i < $len) {
                        if ($i <= $loop) {
                            $tem_pn .= $pro_name[$i];
                            if ($i == 33) {
                                $tem_pn .= " " . $qty . dotInput($amount);

                                echo 'printableXml+= encoder.addText({data:"' . $tem_pn . '"}), printableXml+= encoder.addNewLine();';
                                // . "\n   "
                                $loop = 62;
                            }
                        }
                        if ($i <= 62 && $i >= 33) {
                            $ex_txt .= $pro_name[$i];
                            if ($i == 62) {
                                $ex_txt .= ".";
                            }
                        }
                        if ($i == 62) {
                            $tem_pn .= "..";
                        }
                        $i++;
                    }
                    $item_row .= $tem_pn;
                    
                    //. "\n"
                } elseif ($len == 33) {
                    $item_row .= $pro_name . "  " . $qty . dotInput($amount);
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                } else {
                    $space = "";
                    $a = 35 - $len;
                    while ($a > 0) {
                        $space .= " ";
                        $a--;
                    }
                    $item_row .= $pro_name . $space . $qty . dotInput($amount);
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                }
                // if (strlen($ex_txt) > 0) {
                //     echo 'printableXml+= encoder.addText({data:"   ' . $ex_txt . '"}), printableXml+= encoder.addNewLine();';
                // }
                echo 'printableXml+= encoder.addText({data:"' . $symbol_line . '"}), printableXml+= encoder.addNewLine();';
                $row_height += $input_height;
                $t++;
                $item_row = "";
            }
        }
        $total_sales--;
    }

    $sub_total = "Sub Total                                       : " . dotInput(round($re_tot, 2));
    $c_code = "Customer Code    :   " . trim($cus_det["customer_code"]);
    ?>
                    printableXml += encoder.addText({data: "  "}), printableXml += encoder.addNewLine();
                    printableXml += encoder.setFontSize(1);
                    printableXml += encoder.addText({data: "<?php echo $sub_total ?>"}), printableXml += encoder.addNewLine();

                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "Signature: ..................................."}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                  //  printableXml += encoder.addText({data: "                Thank You For Your Business!"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "     Software By Tritcal International (Pvt) Ltd | Kandy"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "              081 20 50 437 | www.tritcal.com"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 2, height: 2, data: ""}), printableXml += encoder.addNewLine();

                    printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 2, height: 1, data: "<?php echo $c_code ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "<?php echo $symbol_line ?>"}), printableXml += encoder.addNewLine();

                    printableXml += encoder.setCutting(0);
                    printableXml += encoder.printData("page");
                    printableXml += encoder.setPrintMode("standard");

                    comm.send(printableXml);
                }
                ;

                print_sample();
                document.getElementById("print_but").style.display = "block";
                document.getElementById("end_but").href = "../../billing2.php?<?=$full_url?>";
                document.getElementById("end_but").style.display = "block";
            </script>
        </body>
    </html>
    <?php
}
