<?php
session_start();
include '../../dbconnect.php';
include '../../valid_fun.php';
$t = 1;
$row_height = 0;
$input_height = 10;
if (isset($_GET["invoice"])) {
    $invoice = $_GET["invoice"];
    $trans = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM mo_pos_transaction WHERE invoice='$invoice'"));
    $res_id = $trans['t_id'];
    $c_id = $trans['c_id'];
    $cus_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM mo_pos_customers WHERE c_id=$c_id"));
    $res_date = $trans['transaction_date'];
    $ous = mysqli_fetch_row(mysqli_query($con, "SELECT SUM(balance) FROM mo_pos_transaction WHERE c_id=$c_id"))[0];
$this_bill_ous=floatval($trans["total"])-floatval($trans["paid_amount"]);
    $total_pro = mysqli_num_rows(mysqli_query($con, "SELECT so_id FROM mo_pos_sales_order WHERE invoice='$invoice'"));

    $prefer_height = 850 + ($total_pro * ($input_height + 50));

    $chars_per_line = 85;
    $symbol_line = "";
    $symbol = "-";
    while ($chars_per_line > 0) {
        $symbol_line .= $symbol;
        $chars_per_line--;
    }
    $item_title = "   Items";
    $qty = "Qty";
    $u_price = "Unit Price";
    $amount = "Amount";
    
    $ex_u_price="";
    $u_price_len=strlen($u_price);
    while($u_price_len<20){
                    $ex_u_price.=" ";
                    $u_price_len++;
                }
$u_price.=$ex_u_price;
    $item_len = strlen($item_title);
    $item_space = $qty_apace = "";
    while ($item_len < 42) {
        $item_space .= " ";
        $item_len++;
    }
    $qty_len = strlen($qty);
    while ($qty_len < 15) {
        $qty_apace .= " ";
        $qty_len++;
    }
    $item_title .= $item_space;
    $qty .= $qty_apace;

    $base_row = $item_title . $qty .$u_price. $amount;
    $item_row = "";

    $pay_type = $trans["pay_type"];
    $pay_type_txt = "Cash Payment";
    if ($pay_type == 2) {
        $pay_type_txt = "Credit Bill";
    } else if ($pay_type == 3) {
        $pay_type_txt = "Cheque Payment";
    }
    ?>
    <!DOCTYPE html>
    <style>
        body,head{color:#666;font:14px "Roboto", sans-serif;-webkit-font-smoothing:antialiased;background-color:#eee}
    </style>
    <html>
        <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <script type="text/javascript" charset="utf-8" src='./js/jquery-1.11.1.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSEncoder-1.0.0.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSComm-1.0.0.min.js'></script>
            <style type="text/css"> @import url("./css/style.css");</style>
        </head>

        <body>
            <br/>
            <p align="center" id="result">
            </p>
            <script type="text/javascript" charset="utf-8">
                var prefer_height = parseInt('<?php echo $prefer_height ?>');

                var finishedCallback = function (result) {
                    var code = result['ERR_CODE'];

                    switch (code)
                    {
                        case "0":
                            alert("Success");
                            break;
                        case "1":
                            alert("Printer is not connected.");
                            break;
                        case "4":
                            alert("Session is not opened.");
                            break;
                        default:
                            break;
                    }
                };

                function print_sample() {

                    var comm = new WSComm();
                    var encoder = new WSEncoder();

                    var printableXml = encoder.setPrintMode("page");

                    //1 inch:192 , 2 inch:384, 3 inch:576, 4 inch:768
                    printableXml += encoder.pm_setPrintingArea({x: 2, y: 0, width: 800, height: prefer_height});
                    printableXml += encoder.addText({width: 2, height: 2, data: "            TARUSHANI DISTRIBUTORS"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "           No. 5/B/1, Tank Road, Uggalla, Katugasthota. Tel: 0777 375 0097"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(15);
                    printableXml += encoder.setFontSize(1);
                    printableXml += encoder.addText({width: 1, height: 1, data: "Date    : <?php echo $res_date ?>                                 Receipt No: <?php echo $res_id ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "Customer: <?php echo ucwords($cus_det["name"]) ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "Type    : <?php echo $pay_type_txt ?>"}), printableXml += encoder.addNewLine();
                    // printableXml+= encoder.pm_setPosition({x:650, y:105}); 
                    // printableXml+= encoder.addText({data:"2015-01-27"}), printableXml+= encoder.addNewLine();
                    // printableXml+= encoder.setFontSize(0);
                    // printableXml+= encoder.pm_setPosition({x:650, y:5});
                    // printableXml+= encoder.addQrCode({version:0, level:'H', size:2, data:"www.woosim.com/english"});
                    // printableXml += encoder.pm_addBox({x: 0, y: 130, width: 384, height: 0, thickness: 2});
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(5);
                    printableXml += encoder.addText({data: "<?php echo $base_row ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();

    <?php
    $total_sales = mysqli_fetch_row(mysqli_query($con, "SELECT MAX(so_id) FROM mo_pos_sales_order"))[0];
    while ($total_sales > 0) {
        $row = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM mo_pos_sales_order WHERE so_id=$total_sales"));
        if ($row != null) {
            $tb_invo = $row["invoice"];
            if ($tb_invo == $invoice) {
                $tem_pn = "";
                $pro_id = $row["pro_id"];
                $pro_det=mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM mo_pos_products WHERE pro_id=$pro_id"));
                $pro_name = $t . ". " . trim($pro_det['name']);
                $qty = trim($row["qty"]);
                $amount = $row["total"];
                $rec_date = $row["date"];
                $len = strlen($pro_name);
                $len2 = strlen($qty);
                $row_u_price=dotInput($pro_det["unit_price"]);
                $len3=strlen(dotInput($pro_det["unit_price"]));
                $ex_u_price_space="";
                while($len3<20){
                    $ex_u_price_space.=" ";
                    $len3++;
                }
                $row_u_price.=$ex_u_price_space;
                if ($len2 < 15) {
                    $space2 = "";
                    $a = 15 - $len2;
                    while ($a > 0) {
                        $space2 .= " ";
                        $a--;
                    }
                    $qty .= $space2;
                } else {
                    $qty .= "  ";
                }
                if ($len > 40) {
                    $ex_txt = "";
                    $i = 0;
                    $loop = 40;
                    while ($i < $len) {
                        if ($i <= $loop) {
                            $tem_pn .= $pro_name[$i];
                            if ($i == 40) {
                                $tem_pn .= " " . $qty .$row_u_price. dotInput($amount);

                                echo 'printableXml+= encoder.addText({data:"' . $tem_pn . '"}), printableXml+= encoder.addNewLine();';
                                // . "\n   "
                                $loop = 76;
                            }
                        }
                        if ($i <= 76 && $i >= 40) {
                            $ex_txt .= $pro_name[$i];
                            if($i == 76){
                                $ex_txt .=".";
                            }
                        }
                        if ($i == 76) {
                            $tem_pn .= "..";
                        }
                        $i++;
                    }
                    $item_row .= $tem_pn;
                    //. "\n"
                } elseif ($len == 40) {
                    $item_row .= $pro_name . "  " . $qty . $row_u_price.dotInput($amount);
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                } else {
                    $space = "";
                    $a = 42 - $len;
                    while ($a > 0) {
                        $space .= " ";
                        $a--;
                    }
                    $item_row .= $pro_name . $space . $qty .$row_u_price. dotInput($amount);
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                }
                if(strlen($ex_txt) > 0){
                    echo 'printableXml+= encoder.addText({data:"   ' . $ex_txt . '"}), printableXml+= encoder.addNewLine();';
                }
                echo 'printableXml+= encoder.addText({data:"' . $symbol_line . '"}), printableXml+= encoder.addNewLine();';
                $row_height += $input_height;
                $t++;
                $item_row = "";
            }
        }
        $total_sales--;
    }
    $sub_total = "Sub Total                                                    : " . dotInput(round($trans['sub_total'], 2));
    $discount = "Discount                                                     : " . dotInput(round($trans['discount'], 2));
    $total = "Total                         : " . dotInput(round($trans['total'], 2));
    $paid = "Paid                                                         : " . dotInput(round($trans['paid_amount'], 2));
    $balance = "Balance                                                      : " . dotInput(round($trans['balance'], 2));
    $this_bill_ous_txt = "                                                             : " . dotInput(round($this_bill_ous, 2));
    $oustanding = "Oustanding                                                   : " . dotInput(round($ous, 2));
    ?>
                    // printableXml += encoder.pm_addBox({x: 0, y: 270, width: 384, height: 0, thickness: 2});
                    // printableXml += encoder.pm_addBox({x: 0, y: 310, width: 115, height: 0, thickness: 2}), printableXml += encoder.pm_addBox({x: 260, y: 310, width: 124, height: 0, thickness: 2}), printableXml += encoder.addFeedNDot(15);
                    // printableXml += encoder.addFeedNLine(1);
                    // printableXml += encoder.addText({width: 2, height: 1, data: ""}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.pm_setPosition({x: 384, y: <?php echo $row_height + 340 ?>});
                    printableXml += encoder.addText({data: "  "}), printableXml += encoder.addNewLine();

                    // printableXml+= encoder.addText({data:"Number:         "});
                    // printableXml+= encoder.setFontSize(1);
                    // printableXml+= encoder.addText({data:"6688-9988-6644-3311"}), printableXml+= encoder.addNewLine();
                    // printableXml+= encoder.setFontSize(0);
                    printableXml += encoder.setFontSize(1);
                    printableXml += encoder.addText({data: "<?php echo $sub_total ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "<?php echo $discount ?>"}), printableXml += encoder.addNewLine();
                    
                    printableXml+= encoder.addText({data:""}), printableXml+= encoder.addNewLine();
                    printableXml+= encoder.addText({data:"<?php echo $symbol_line ?>"}), printableXml+= encoder.addNewLine();
                    printableXml += encoder.addText({width: 2, height: 1, data: "<?php echo $total ?>"}), printableXml += encoder.addNewLine();
                    printableXml+= encoder.addText({data:"<?php echo $symbol_line ?>"}), printableXml+= encoder.addNewLine();
                    printableXml+= encoder.addText({data:""}), printableXml+= encoder.addNewLine();
                    printableXml += encoder.addText({data: "<?php echo $paid ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "<?php echo $balance ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "<?php echo $this_bill_ous_txt ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "<?php echo $oustanding ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.pm_addBox({x: 0, y: 490, width: 384, height: 0, thickness: 2}), printableXml += encoder.addFeedNLine(15);
                    // printableXml += encoder.addText({data: "Total:                  $ 9.50"}), printableXml += encoder.addNewLine();
                    // printableXml+= encoder.addText({data:"Credit Card:            $ 9.50"}), printableXml+= encoder.addNewLine();
printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                     printableXml += encoder.addText({data: "                     Packed And Marketed By Tarun Spices And Food Products"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "                                Thank You For Your Business!"}), printableXml += encoder.addNewLine();
                     printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "   Software By Tritcal International (Pvt) Ltd | Nugawela | 081 20 50 437 | 0777 959 789"}), printableXml += encoder.addNewLine();

                    printableXml += encoder.setCutting(0);
                    printableXml += encoder.printData("page");
                    printableXml += encoder.setPrintMode("standard");

                    comm.send(printableXml);
                }
                ;

                print_sample();
                window.location.href="../../report/transaction_report.php";
            </script>
        </body>
    </html>
    <?php
}
