<?php
session_start();
include '../../dbconnect.php';
include '../../valid_fun.php';
$t = 1;
$row_height = 0;
$input_height = 20;
 $date = date("Y-m-d");
$pro_list = [];
                                $item_count = [];
                                $result = mysqli_query($con, "SELECT * FROM mo_pos_sales_order");
                                while ($row = mysqli_fetch_array($result)) {
                                    $have_product = false;
                                    $pro_index = 0;
                                    $sales_date = trim($row["date"]);
                                    if ($sales_date == $date) {
                                        $pro_len = count($pro_list);
                                        while ($pro_len > 0) {
                                            if ($pro_list[$pro_len - 1] == $row["pro_id"]) {
                                                $have_product = true;
                                                $pro_index = $pro_len - 1;
                                                break;
                                            }
                                            $pro_len--;
                                        }
                                        if ($have_product != true) {
                                            $pro_list[] = $row["pro_id"];
                                            $item_count[] = $row["qty"];
                                        } else {
                                            $item_count[$pro_index] += $row["qty"];
                                        }
                                    }
                                }
                                $final_pro_list_len = count($pro_list);
    $prefer_height = 450 + ($final_pro_list_len * ($input_height + 50));

    $chars_per_line = 85;
    $symbol_line = "";
    $symbol = "-";
    while ($chars_per_line > 0) {
        $symbol_line .= $symbol;
        $chars_per_line--;
    }
    $item_title = "   Item Name";
    $qty = "Quantity";
    $amount = "";

    $item_len = strlen($item_title);
    $item_space = $qty_apace = "";
    while ($item_len < 62) {
        $item_space .= " ";
        $item_len++;
    }
    $qty_len = strlen($qty);
    while ($qty_len < 15) {
        $qty_apace .= " ";
        $qty_len++;
    }
    $item_title .= $item_space;
    $qty .= $qty_apace;

    $base_row = $item_title . $qty . $amount;
    $item_row = "";
    
    ?>
    <!DOCTYPE html>
    <style>
        body,head{color:#666;font:14px "Roboto", sans-serif;-webkit-font-smoothing:antialiased;background-color:#eee}
    </style>
    <html>
        <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <script type="text/javascript" charset="utf-8" src='./js/jquery-1.11.1.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSEncoder-1.0.0.min.js'></script>
            <script type="text/javascript" charset="utf-8" src='./js/WSComm-1.0.0.min.js'></script>
            <style type="text/css"> @import url("./css/style.css");</style>
        </head>

        <body>
            <br/>
            <p align="center" id="result">
            </p>
            <script type="text/javascript" charset="utf-8">
                var prefer_height = parseInt('<?php echo $prefer_height ?>');

                var finishedCallback = function (result) {
                    var code = result['ERR_CODE'];

                    switch (code)
                    {
                        case "0":
                            alert("Success");
                            break;
                        case "1":
                            alert("Printer is not connected.");
                            break;
                        case "4":
                            alert("Session is not opened.");
                            break;
                        default:
                            break;
                    }
                };

                function print_sample() {

                    var comm = new WSComm();
                    var encoder = new WSEncoder();

                    var printableXml = encoder.setPrintMode("page");

                    //1 inch:192 , 2 inch:384, 3 inch:576, 4 inch:768
                    printableXml += encoder.pm_setPrintingArea({x: 2, y: 0, width: 800, height: prefer_height});
                    printableXml += encoder.addText({width: 2, height: 2, data: "            TARUSHANI DISTRIBUTORS"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 1, height: 1, data: "           No. 5/B/1, Tank Road, Uggalla, Katugasthota. Tel: 0777 375 0097"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({width: 2, height: 1, data: "  Loading List | <?php echo $date ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(10);
                    printableXml += encoder.setFontSize(1);
                    // printableXml+= encoder.pm_setPosition({x:650, y:105}); 
                    // printableXml+= encoder.addText({data:"2015-01-27"}), printableXml+= encoder.addNewLine();
                    // printableXml+= encoder.setFontSize(0);
                    // printableXml+= encoder.pm_setPosition({x:650, y:5});
                    // printableXml+= encoder.addQrCode({version:0, level:'H', size:2, data:"www.woosim.com/english"});
                    // printableXml += encoder.pm_addBox({x: 0, y: 130, width: 384, height: 0, thickness: 2});
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addFeedNDot(5);
                    printableXml += encoder.addText({data: "<?php echo $base_row ?>"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: ""}), printableXml += encoder.addNewLine();
<?php
    
                                
                                while ($final_pro_list_len > 0) {
                                    $pro_id = $pro_list[$final_pro_list_len - 1];
                                    $pro_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM mo_pos_products WHERE pro_id=$pro_id"));
                                    $cat_id = $pro_det["cat_id"];
                                    $cat_det = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM mo_pos_category WHERE cat_id=$cat_id"));
                                    $item_type = "Item/s";
                                    if ($cat_det["unit"] == 2) {
                                        $item_type = "KG";
                                    } elseif ($cat_det["unit"] == 3) {
                                        $item_type = "L";
                                    }
                                    $pro_name=$t.". ".$pro_det["name"];
                                    $len = strlen($pro_name);
                                    $qty=$item_count[$final_pro_list_len - 1] . " " . $item_type;
                                    if ($len > 60) {
                    $ex_txt = "";
                    $i = 0;
                    $loop = 60;
                    while ($i < $len) {
                        if ($i <= $loop) {
                            $tem_pn .= $pro_name[$i];
                            if ($i == 60) {
                                $tem_pn .= " " . $qty;

                                echo 'printableXml+= encoder.addText({data:"' . $tem_pn . '"}), printableXml+= encoder.addNewLine();';
                                // . "\n   "
                                $loop = 116;
                            }
                        }
                        if ($i <= 116 && $i >= 60) {
                            $ex_txt .= $pro_name[$i];
                            if($i == 116){
                                $ex_txt .=".";
                            }
                        }
                        if ($i == 116) {
                            $tem_pn .= "..";
                        }
                        $i++;
                    }
                    $item_row .= $tem_pn;
                    //. "\n"
                } elseif ($len == 60) {
                    $item_row .= $pro_name . "  " . $qty ;
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                } else {
                    $space = "";
                    $a = 62 - $len;
                    while ($a > 0) {
                        $space .= " ";
                        $a--;
                    }
                    $item_row .= $pro_name . $space . $qty;
                    echo 'printableXml+= encoder.addText({data:"' . $item_row . '"}), printableXml+= encoder.addNewLine();';
                }if(strlen($ex_txt) > 0){
                    echo 'printableXml+= encoder.addText({data:"   ' . $ex_txt . '"}), printableXml+= encoder.addNewLine();';
                }
                                 echo 'printableXml+= encoder.addText({data:"' . $symbol_line . '"}), printableXml+= encoder.addNewLine();';   
                                 $item_row="";
                                 $t++;
                                    $final_pro_list_len--;
                                }
                                ?>
                    // printableXml += encoder.pm_addBox({x: 0, y: 270, width: 384, height: 0, thickness: 2});
                    // printableXml += encoder.pm_addBox({x: 0, y: 310, width: 115, height: 0, thickness: 2}), printableXml += encoder.pm_addBox({x: 260, y: 310, width: 124, height: 0, thickness: 2}), printableXml += encoder.addFeedNDot(15);
                    // printableXml += encoder.addFeedNLine(1);
                    // printableXml += encoder.addText({width: 2, height: 1, data: ""}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.pm_setPosition({x: 384, y: <?php echo $row_height + 340 ?>});
                    printableXml += encoder.addText({data: "  "}), printableXml += encoder.addNewLine();

                    // printableXml+= encoder.addText({data:"Number:         "});
                    // printableXml+= encoder.setFontSize(1);
                    // printableXml+= encoder.addText({data:"6688-9988-6644-3311"}), printableXml+= encoder.addNewLine();
                    // printableXml+= encoder.setFontSize(0);
                    // printableXml += encoder.setFontSize(1);
                    // printableXml += encoder.addText({data: "<?php echo $sub_total ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.addText({data: "<?php echo $discount ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.addText({data: "<?php echo $total ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.addText({data: "<?php echo $paid ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.addText({data: "<?php echo $balance ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.addText({data: "<?php echo $oustanding ?>"}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.pm_addBox({x: 0, y: 490, width: 384, height: 0, thickness: 2}), printableXml += encoder.addFeedNLine(15);
                    // printableXml += encoder.addText({data: "Total:                  $ 9.50"}), printableXml += encoder.addNewLine();
                    // printableXml+= encoder.addText({data:"Credit Card:            $ 9.50"}), printableXml+= encoder.addNewLine();

                    // printableXml += encoder.addText({data: "  "}), printableXml += encoder.addNewLine();
                    // printableXml += encoder.addText({data: "                                Thank You For Your Business!"}), printableXml += encoder.addNewLine();
                    printableXml += encoder.addText({data: "   Software By Tritcal International (Pvt) Ltd | Nugawela | 081 20 50 437 | 0777 959 789"}), printableXml += encoder.addNewLine();

                    printableXml += encoder.setCutting(0);
                    printableXml += encoder.printData("page");
                    printableXml += encoder.setPrintMode("standard");

                    comm.send(printableXml);
                }
                ;

                print_sample();
                window.location.href="../../dashboard.php";
            </script>
        </body>
    </html>
