<div class="pages">
    <div data-page="team" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php include 'inc/top_header.php'; ?>

            <div id="pages_maincontent">

                <h2 class="page_title" style="text-align: center;"><strong>MY HISTORY & REPORTS</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <div class="swiper-container-team swiper-init" data-effect="slide" data-space-between="10" data-pagination=".swiper-pagination-team" data-slides-per-view="2">

                        <div class="page_single layout_fullwidth_padding">
                            <ul class="features_list">	
                                <!--<li><a href="direction.php"><img src="images/icons/black/tabs.png" alt="" title="" /><span>Get Direction</span></a></li>  		-->
                                <li><a href="#" onclick="redirectTo('../admin/loc/user-map.php')"><img src="images/icons/black/tabs.png" alt="" title="" /><span>Locations</span></a></li>
                                <!--<li><a href="current_location.php"><img src="images/icons/black/tabs.png" alt="" title="" /><span>Current Location</span></a></li>-->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'inc/footer.php';
?>