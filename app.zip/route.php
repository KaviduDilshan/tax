<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
           // include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>SELECT ROUTE</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <ul class="features_list_block">
                        <?php
                        $route_re = getRoutes($conn);
                        while ($row = mysqli_fetch_array($route_re)) {
                            ?>
                            <li><a href="customer.php?r=<?= base64_encode($row["r_id"]) ?>"><img src="images/icons/black/car.png" alt="" title="" /><span><?= $row["name"] . " - " . getDateText($row["date"]) ?></span></a></li>
                            <?php
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="index.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="customer.php" class="next_shop">NEXT</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>