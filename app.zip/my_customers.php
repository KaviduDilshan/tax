<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
            include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>MY CUSTOMERS</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <ul class="responsive_table">
                        <li class="table_row">
                            <div class="table_section">NAME</div>
                            <div class="table_section_small">CITY</div>
                            <div class="table_section_small">MOBILE</div> 
                        </li>
                        <?php
                        $cus_re = getCustomers($conn, $_SESSION["user"]["a_id"]);
                        while ($row = mysqli_fetch_array($cus_re)) {
                            ?>
                            <li class="table_row">
                                <div class="table_section"><?= $row["customer_name"] ?></div>
                                <div class="table_section_small"><?= ucwords($row["customer_city"]) ?></div>
                                <div class="table_section_small"><?= $row["customer_mobile"] ?></div> 
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="history.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="index.php" class="next_shop">HOME</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>