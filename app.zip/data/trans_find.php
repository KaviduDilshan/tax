<?php

session_start();
include '../../conn.php';
include '../../inc/functions.php';

if (isset($_POST["add"])) {
    $c_code=trim($_POST["c_code"]);
    $user=base64_decode(trim($_POST["user"]));
    $t_det=getLastTransDetByCCode($conn,$user,$c_code);
    if ($t_det!=null && $c_code!=null) {
    
    $t_id=base64_encode($t_det["t_id"]);
    ?>
        <script>window.location.href="<?="../#!/transaction_history.php?t=".$t_id?>";</script>
        <?php
    } else {?>
        <script>window.location.href="<?="../#!/transaction_history.php"?>";</script>
        <?php
    }
}