<?php

session_start();
include '../../conn.php';
include '../../inc/functions.php';

if (isset($_GET["pro"]) && isset($_GET["qty"]) && isset($_GET["f_qty"]) && isset($_GET["invoice"])) {
    $obj = [];
    $user = $_SESSION["user"]["a_id"];
    $pro = intval(base64_decode(trim($_GET["pro"])));
    $invoice = base64_decode(trim($_GET["invoice"]));
    $u_price=floatval($_GET["u_price"]);
    $this_date = date("Y-m-d");

    if ($pro > 0) {
        $pro_det = getProDet($conn, $pro);
        $unit_price = $u_price;

        $qty = floatval(trim($_GET["qty"]));
        $f_qty = floatval(trim($_GET["f_qty"]));
        $dec_qty = $qty + $f_qty;

        if ($pro_det != null) {
            if ($qty > 0) {
                $total = $unit_price * $qty;
                $profit = $total - (floatval($pro_det["dealer_price"]) * $dec_qty);

                $query = "INSERT INTO sales_order(invoice,date,pro_id,quantity,unit_price,total,a_id,profit) "
                        . "VALUES(\"$invoice\",\"$this_date\",\"$pro\",\"$qty\",\"$unit_price\",\"$total\",\"$user\",\"$profit\")";
                if (mysqli_query($conn, $query)) {
                    if ($f_qty > 0) {
                        $query = "INSERT INTO free_sales(invoice,s_date,pro_id,quantity,unit_price,a_id) "
                                . "VALUES(\"$invoice\",\"$this_date\",\"$pro\",\"$f_qty\",\"$unit_price\",\"$user\")";
                        mysqli_query($conn, $query);
                    }
                    $obj["error"] = 0;
                } else {
                    $obj["error"] = 1;
                }
                $sales_det = getSumByInvoice($conn, $invoice);
                $obj["total"] = number_format($sales_det["SUM(total)"], 2, ".", ",");
                $obj["item_count"] = $sales_det["COUNT(sales_id)"];
            } elseif ($qty == 0 && $f_qty > 0) {
                $query = "INSERT INTO free_sales(invoice,s_date,pro_id,quantity,unit_price,a_id) "
                        . "VALUES(\"$invoice\",\"$this_date\",\"$pro\",\"$f_qty\",\"$unit_price\",\"$user\")";
                mysqli_query($conn, $query);
                $obj["error"] = 0;
            } else {
                $obj["error"] = 1;
            }
            $query = "UPDATE products SET quantity=quantity-$dec_qty WHERE pro_id=$pro";
            mysqli_query($conn, $query);
        } else {
            $obj["error"] = 1;
        }
    } else {
        $obj["error"] = 1;
    }
    $full_url="c=".$_GET["c"]."&r=".$_GET["r"]."&invoice=".$_GET["invoice"]."&cat=".$_GET["cat"];
    ?>
    <script>
        window.location.href="../#!/product.php?<?=$full_url?>";
    </script>
    <?php
}
// if (isset($_GET["del"]) && isset($_GET["s"])) {
//     $obj = [];
//     $del = intval($_GET["del"]);
//     if ($del === 1) {
//         $sa_id = intval(base64_decode(trim($_GET["s"])));
//         if ($sa_id > 0) {
//             $query = "DELETE FROM sales_order WHERE sales_id=$sa_id";
//             $sales_det = getSalseDet($conn, $sa_id);
//             if ($sales_det != null) {
//                 if (mysqli_query($conn, $query)) {
//                     $qty = floatval($sales_det["quantity"]);
//                     $pro = floatval($sales_det["pro_id"]);
//                     $query = "UPDATE products SET quantity=quantity+$qty WHERE pro_id=$pro";
//                     if (mysqli_query($conn, $query)) {
//                             $invoice = $sales_det["invoice"];
                        
//                                 $ret_det = getReturnDet($conn, $invoice);
//                                 $cus=intval($_GET["cus"]);
//                                 $ous_det = getUserTrans($conn,$cus);
//                                 $user_det = getUserDet($conn, $cus);
//                                 $ous_amount = floatval($ous_det["SUM(total)"]) - floatval($ous_det["SUM(paid_amount)"]);
//                                 $re_tot = floatval($ret_det["SUM(total)"]);
//                                 $loop = 1;
//                                 $sales_re = getSalesByInvoice($conn, $invoice);
//                                 $sub_tot = 0;
//                                 while ($row = mysqli_fetch_array($sales_re)) {
//                                     $pro_id = $row["pro_id"];
//                                     $pro_det = getProDet($conn, $pro_id);
//                                     $sub_tot += (floatval($row["quantity"]) * $pro_det["unit_price"]);
//                                     $loop++;
//                                 }
//                                 $g_tot = $sub_tot - $re_tot;
                                
//                                 $obj["error"] = 0;
//                                 $obj["sub_tot"] = number_format($sub_tot, 2, ".", ",");
//                                 $obj["free_sales"] = floatval(getFreeSales($conn, $invoice)["SUM(quantity)"]);
//                                 $obj["tot_amount"] = number_format($g_tot, 2, ".", ",");
//                                  if ($user_det["credit_accept"] != 0) {
//                                     $g_tot = ($sub_tot + $ous_amount) - $re_tot;
//                                  }
//                                 $obj["ous"] = number_format($ous_amount, 2, ".", ",");
//                                 $obj["g_tot"] = number_format($g_tot, 2, ".", ",");
//                                 $obj["re_tot"] = number_format($re_tot, 2, ".", ",");
//                                 $obj["re_qty"] = floatval($ret_det["SUM(quantity)"]);
//                     } else {
//                         $obj["error"] = 1;
//                     }
//                 } else {
//                     $obj["error"] = 1;
//                 }
//             } else {
//                 $obj["error"] = 1;
//             }
//         } else {
//             $obj["error"] = 1;
//         }
//     } else {
//         $obj["error"] = 1;
//     }
//     echo json_encode($obj);
// }