<?php

session_start();
include '../../conn.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$c_id = $cat = $r = $invoice = null;

if (isset($_GET["c"])) {
    $c_id = intval($_GET["c"]);
}
if (isset($_GET["cat"])) {
    $cat = intval($_GET["cat"]);
}
if (isset($_GET["r"])) {
    $r_id = intval($_GET["r"]);
}
if (isset($_GET["invoice"])) {
    $invoice = $_GET["invoice"];
}

$real_invoice = base64_decode($invoice);

$max_s_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(sales_id) FROM sales_order"))["MAX(sales_id)"]) + 1;
$max_t_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(t_id) FROM transaction"))["MAX(t_id)"]) + 1;
$new_invoice = ($max_s_id * $max_t_id) * mt_rand(100000, 1000000);

$url = "?c=" . $c_id . "&cat=" . $cat . "&r=" . base64_encode($r_id) . "&invoice=" . base64_encode($new_invoice) . "&prev=1&prev_invoice=".$_GET["invoice"];

mysqli_query($conn, "UPDATE transaction SET status=1 WHERE invoice=\"$real_invoice\"");
$result = mysqli_query($conn, "SELECT * FROM sales_order WHERE invoice=\"$real_invoice\"");
while ($row = mysqli_fetch_array($result)) {
    $sales_id = intval($row["sales_id"]);
    $free_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM free_sales WHERE sales_id=\"$sales_id\""));
    $date = $row["date"];
    $pro_id = $row["pro_id"];
    $quantity = $row["quantity"];
    $unit_price = $row["unit_price"];
    $total = $row["total"];
    $a_id = $row["a_id"];
    $profit = $row["profit"];
    $query = "INSERT INTO sales_order(invoice,date,pro_id,quantity,unit_price,total,a_id,profit) "
            . "VALUES(\"$new_invoice\",\"$date\",\"$pro_id\",\"$quantity\",\"$unit_price\",\"$total\",\"$a_id\",\"$profit\")";
    mysqli_query($conn, $query);
    if ($free_det != null) {
        $new_sales_id = mysqli_insert_id($conn);
        $f_qty = $free_det["quantity"];
        $s_date = $free_det["s_date"];
        $f_u_price = $free_det["unit_price"];
        $query = "INSERT INTO free_sales(invoice,s_date,pro_id,quantity,unit_price,a_id,sales_id) "
                . "VALUES(\"$new_invoice\",\"$s_date\",\"$pro_id\",\"$f_qty\",\"$f_u_price\",\"$a_id\",\"$new_sales_id\")";
        mysqli_query($conn, $query);
    }
}
$result2 = mysqli_query($conn, "SELECT * FROM return_stock WHERE invoice=\"$real_invoice\"");
while ($row2 = mysqli_fetch_array($result2)) {
    $c_id = $row2["c_id"];
    $pro_id = $row2["pro_id"];
    $date = $row2["date"];
    $quantity = $row2["quantity"];
    $description = $row2["description"];
    $a_id = $row2["a_id"];
    $unit_price = $row2["unit_price"];
    $total = $row2["total"];
    $query = "INSERT INTO return_stock(c_id,date,quantity,invoice,a_id,unit_price,total) VALUES(\"$c_id\",\"$date\",\"$quantity\",\"$new_invoice\",\"$a_id\",\"$unit_price\",\"$total\")";
    mysqli_query($conn, $query);
}
header("location:../billing2.php" . $url);
