<?php
session_start();

include '../../conn.php';
include '../../inc/functions.php';

if (isset($_POST["add"]) && !isset($_SESSION['from_print'])) {
    $user = $_SESSION["user"]["a_id"];
    $this_date = date("Y-m-d H:i:s");
    $sub_tot = 0;

    $in = trim($_POST["invoice"]);
    $prev = intval($_POST["prev"]);
    $invoice = base64_decode($in);
    $paid_amount_cash = floatval($_POST["paid_amount_cash"]);
    $paid_amount_cheque = floatval($_POST["paid_amount_cheque"]);
    $pay_amount = $paid_amount_cash;
    $return = floatval($_POST["return"]);
    $balance = floatval($_POST["balance"]);
    $check_no = null;
    $pay_type = intval($_POST["pay_type"]);
    $r = trim($_POST["r"]);
    $c = trim($_POST["c"]);
    $cat = 0;
//    $tem_ous = floatval($_POST["other_dis"]);
    $customer = intval(($c));

    $cus_det = getUserDet($conn, $customer);
    $cc_coden = $cus_det["customer_code"];
    $c_id = $cus_det["c_id"];
//    $last_trans_det = getLastTransDetByCCode($conn, 0, $cus_det["customer_code"], $invoice);
    $last_trans_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `transaction` WHERE `c_code`=\"$cc_coden\" AND `invoice` != \"$invoice\" ORDER BY `t_id` DESC"));
    $r_id = $cus_det["r_id"];
    if (($pay_type == 2) || ($pay_type == 3)) {
        $pay_amount += $paid_amount_cheque;
        $check_no = trim($_POST["cheque_no"]);
    }
    
    $tem_ous = floatval($_POST["final_tot"]) - $pay_amount;

    $ret_det = getReturnDet($conn, $invoice);
    $ous_amount = floatval($_POST["other_dis"]);
    $re_tot = floatval($ret_det["SUM(total)"]);

    $sales_re = getSalesByInvoice($conn, $invoice);
    while ($row = mysqli_fetch_array($sales_re)) {
        $pro_id = $row["pro_id"];
        $pro_det = getProDet($conn, $pro_id);
        $sub_tot += (floatval($row["quantity"]) * $row["unit_price"]);
    }
    $this_trans_ous = ($sub_tot + $ous_amount - $return) - $pay_amount;
    $total = $sub_tot + $ous_amount - $return;

    // if ($sub_tot > 0) {
    $have_trans = getTransDetByInvoice($conn, $invoice);
    if ($have_trans != null) {
        $t_id = $have_trans["t_id"];
    }
    $create_new = false;
    if ((($prev == 0) && ($have_trans == null)) || (($prev == 0) && (($have_trans != null) && ($have_trans['status'] == 1)))) {
        $create_new = true;
    }
    $updated = "";
    if (($create_new) || ($have_trans == null)) {
        $query = "INSERT INTO transaction(c_id,transaction_date,invoice,sub_total,total,rturn,paid_amount,balance,pay_type,a_id,check_no,r_id,paid_cheque,ous,c_code) "
                . "VALUES(\"$customer\",\"$this_date\",\"$invoice\",\"$sub_tot\",\"$total\",\"$return\",\"$paid_amount_cash\",\"$balance\",\"$pay_type\",\"$user\",\"$check_no\",\"$r_id\",\"$paid_amount_cheque\",\"$tem_ous\",\"$cc_coden\")";
        mysqli_query($conn, $query);
        $t_id = mysqli_insert_id($conn);
    } else {
        $query = "UPDATE transaction SET sub_total=\"$sub_tot\",total=\"$total\",rturn=\"$return\",paid_amount=\"$paid_amount_cash\",balance=\"$balance\",pay_type=\"$pay_type\",up_a_id=\"$user\",check_no=\"$check_no\",r_id=\"$r_id\",paid_cheque=\"$paid_amount_cheque\",ous=\"$tem_ous\",c_code=\"$cc_coden\" WHERE invoice='$invoice'";

        $updated = "Updated";
        mysqli_query($conn, $query);
    }
    
    if ($sub_tot > 0) {
        header("location:my.bluetoothprint.scheme://../bill_print/response.php?invoice=$in&type=1&copy=0");
    } else {
        header("location:my.bluetoothprint.scheme://../bill_print/response.php?invoice=$in&type=1");
    }
} else {
    if (isset($_SESSION['from_print'])) {
        unset($_SESSION['from_print']);
    }
    header("location:../");
}