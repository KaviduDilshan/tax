<?php
session_start();
include '../../conn.php';
include '../../inc/functions.php';

if (isset($_POST["add"])) {
    $obj = [];
    $user = $_SESSION["user"]["a_id"];
    $pro = trim($_POST["pro_code"]);
    $invoice = base64_decode(trim($_POST["invoice"]));
    $u_price = floatval($_POST["u_price"]);
    $this_date = date("Y-m-d");

    $pro_det = getProDetByCode($conn, $pro);
    $unit_price = floatval($u_price);

    $qty = floatval(trim($_POST["qty"]));
    $f_qty = floatval(trim($_POST["f_qty"]));
    $dec_qty = $qty + $f_qty;

    if ($pro_det != null) {
        $pro_id = $pro_det["pro_id"];
        if ($unit_price < 1) {
            $unit_price = floatval($pro_det["unit_price"]);
        }
        if ($qty > 0) {
            $total = $unit_price * $qty;
            $profit = $total - (floatval($pro_det["dealer_price"]) * $dec_qty);

            $query = "INSERT INTO sales_order(invoice,date,pro_id,quantity,unit_price,total,a_id,profit) "
                    . "VALUES(\"$invoice\",\"$this_date\",\"$pro_id\",\"$qty\",\"$unit_price\",\"$total\",\"$user\",\"$profit\")";
            if (mysqli_query($conn, $query)) {
                $sales_id=mysqli_insert_id($conn);
                if ($f_qty > 0) {
                    $query = "INSERT INTO free_sales(invoice,s_date,pro_id,quantity,unit_price,a_id,sales_id) "
                            . "VALUES(\"$invoice\",\"$this_date\",\"$pro_id\",\"$f_qty\",\"$unit_price\",\"$user\",\"$sales_id\")";
                    mysqli_query($conn, $query);
                }
                $obj["error"] = 0;
            } else {
                $obj["error"] = 1;
            }
            $sales_det = getSumByInvoice($conn, $invoice);
            $obj["total"] = number_format($sales_det["SUM(total)"], 2, ".", ",");
            $obj["item_count"] = $sales_det["COUNT(sales_id)"];
        } elseif ($qty == 0 && $f_qty > 0) {
            $query = "INSERT INTO free_sales(invoice,s_date,pro_id,quantity,unit_price,a_id) "
                    . "VALUES(\"$invoice\",\"$this_date\",\"$pro_id\",\"$f_qty\",\"$unit_price\",\"$user\")";
            mysqli_query($conn, $query);
            $obj["error"] = 0;
        } else {
            $obj["error"] = 1;
        }
        $query = "UPDATE products SET quantity=quantity-$dec_qty WHERE pro_id=$pro_id";
        mysqli_query($conn, $query);
    } else {
        $obj["error"] = 1;
    }
    $full_url = "c=" . $_POST["c"] . "&r_id=" . $_POST["r"] . "&invoice=" . $_POST["invoice"];
    ?>
    <script>
        window.location.href = "../billing2.php?<?= $full_url ?>";
    </script>
    <?php
}