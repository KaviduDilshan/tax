<?php

session_start();
include '../../conn.php';

if (isset($_POST["add"])) {
    $customer_code=ucwords(trim($_POST["customer_code"]));
    $cus_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customer WHERE customer_code='$customer_code'"));
    if($cus_det!=null){
        
        $invoice = 1;
        $pay_type = 1;
        $check_no = null;
        $user = $_SESSION["user"]["a_id"];
        $this_date = date("Y-m-d H:i:s");
    
        $paid = floatval($_POST["paid"]);
        $customer = $cus_det["c_id"];
        if ($customer > 0 && $paid > 0) {
            $query = "INSERT INTO transaction(c_id,transaction_date,invoice,total,pay_type,a_id,check_no,ou,c_codes) "
                    . "VALUES(\"$customer\",\"$this_date\",\"$invoice\",\"$paid\",\"$pay_type\",\"$user\",\"$check_no\",\"$paid\",\"$customer_code\")";
            mysqli_query($conn, $query);
        }
        
        header("location:../");
    }else{
        header("location:../#!/pay_oustanding.php?err=1");
    }
}