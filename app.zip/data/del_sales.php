<?php

session_start();
include '../../conn.php';
include '../../inc/functions.php';

if(isset($_GET["s"])){
    $sales_id=intval($_GET["s"]);
    $sales_det=mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM sales_order WHERE sales_id=$sales_id"));
    $qty=floatval($sales_det["quantity"]);
    $pro_id=intval($sales_det["pro_id"]);
    mysqli_query($conn,"UPDATE products SET quantity = quantity + $qty WHERE pro_id=$pro_id");
    $sql="DELETE FROM sales_order WHERE sales_id=$sales_id";
    $sql2="DELETE FROM free_sales WHERE sales_id=$sales_id";
    mysqli_query($conn,$sql);
    mysqli_query($conn,$sql2);
    $url = "../billing2.php?c=".$_GET["c"]."&r_id=".$_GET["r_id"]."&invoice=".$_GET["invoice"]."&cat=".$_GET["cat"];
    header("location:$url");
}else{
     header("location:../../app/");
}