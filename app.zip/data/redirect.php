<?php 
 $full_url="../#!/return.php?c=".$_GET["c"]."&r=".$_GET["r"]."&invoice=".$_GET["invoice"]."&cat=".$_GET["cat"];
?>
<script>
    window.location.href="<?=$full_url?>";
</script>