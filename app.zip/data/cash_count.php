<?php

include '../../conn.php';
session_start();

if (isset($_POST["add"])) {
    $user = $_SESSION["user"]["a_id"];
    $this_date = date("Y-m-d H:i:s");

    $c_5000 = trim(intval($_POST["count_5000"]));
    $t_5000 = trim(intval($_POST["total_5000"]));

    $c_1000 = trim(intval($_POST["count_1000"]));
    $t_1000 = trim(intval($_POST["total_1000"]));

    $c_500 = trim(intval($_POST["count_500"]));
    $t_500 = trim(intval($_POST["total_500"]));

    $c_100 = trim(intval($_POST["count_100"]));
    $t_100 = trim(intval($_POST["total_100"]));

    $c_50 = trim(intval($_POST["count_50"]));
    $t_50 = trim(intval($_POST["total_50"]));

    $c_20 = trim(intval($_POST["count_20"]));
    $t_20 = trim(intval($_POST["total_20"]));

    $c_10 = trim(intval($_POST["count_10"]));
    $t_10 = trim(intval($_POST["total_10"]));
    
    $route = $_POST["route"];

    $total = $t_5000 + $t_1000 + $t_500 + $t_100 + $t_50 + $t_20 + $t_10;
    $sql = "INSERT INTO cash_count(a_id,date,cc_5000,cc_1000,cc_500,cc_100,cc_50,cc_20,cc_10,total,route) "
            . "VALUES(\"$user\",\"$this_date\",\"$c_5000\",\"$c_1000\",\"$c_500\",\"$c_100\",\"$c_50\",\"$c_20\",\"$c_10\",\"$total\",\"$route\")";
    mysqli_query($conn, $sql);
    header("location:../");
}