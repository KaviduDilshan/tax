<?php

session_start();
include '../../conn.php';

if (isset($_POST["add"])) {
    $user = $_SESSION["user"]["a_id"];
    $this_date = date("Y-m-d H:i:s");

    $des = trim($_POST["des"]);
    $amount = floatval(trim($_POST["amount"]));

    $sql = "INSERT INTO expenses(a_id,date,description,amount) VALUES(\"$user\",\"$this_date\",\"$des\",\"$amount\")";
    mysqli_query($conn, $sql);
    header("location:../expenses.php");
}