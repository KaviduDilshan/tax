<?php
session_start();
include '../../conn.php';
//include '../../inc/functions.php';

if (isset($_POST["add"])) {
    $user = $_SESSION["user"]["a_id"];
    $this_date = date("Y-m-d H:i:s");

    $in = trim($_POST["invoice"]);
    $invoice = base64_decode($in);
    $r = trim($_POST["r"]);
    $c = trim($_POST["c"]);
    $cat = trim($_POST["cat"]);
    $unit_price = floatval(trim($_POST["pro_price"]));
    $rqty = floatval(trim($_POST["rqty"]));
    if ($unit_price > 0 && $rqty > 0) {
        $tot = $unit_price * $rqty;
        $query = "INSERT INTO return_stock(c_id,date,quantity,invoice,a_id,unit_price,total) VALUES(\"$c\",\"$this_date\",\"$rqty\",\"$invoice\",\"$user\",\"$unit_price\",\"$tot\")";
        mysqli_query($conn, $query);
    }
    header("location:../return2.php?invoice=" . $in . "&c=" . $c . "&r_id=" . $r );
} elseif (isset($_GET["del"]) && isset($_GET["re"])) {
    $obj = [];
    $del = intval($_GET["del"]);
    if ($del === 1) {
        $re_id = intval(base64_decode(trim($_GET["re"])));
        if ($re_id > 0) {
            $query = "DELETE FROM return_stock WHERE r_id=$re_id";
            if (mysqli_query($conn, $query)) {
                $obj["error"] = 0;
            } else {
                $obj["error"] = 1;
            }
        } else {
            $obj["error"] = 1;
        }
    } else {
        $obj["error"] = 1;
    }
    echo json_encode($obj);
}