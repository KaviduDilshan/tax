<?php
session_start();
include '../../conn.php';

if (isset($_POST["add"])) {
    $customer_code = ucwords(trim($_POST["customer_code"]));

    $the_date = date("Y-m-d");
    $user = $_SESSION["user"]["a_id"];
    $name = $city = $address = $mobile = $email = $gender = $birth_day = null;
    $err = 1;
    $avoid_reg = false;
    $f_url = "";
    $current_ous = $_POST["current_ous"];
    
    
        $name = trim($_POST["cname"]);
        $route = trim($_POST["r_id"]);
        $r = $_POST["customer_code"];

        
    $exists = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customer WHERE customer_code=\"$customer_code\""));
    if ($exists != null) {
        $avoid_reg = true;
    }
    if (!isset($_POST["invoice"])) {
        $max_s_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(sales_id) FROM sales_order"))["MAX(sales_id)"]) + 1;
        $max_t_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(t_id) FROM transaction"))["MAX(t_id)"]) + 1;
        $invoice = base64_encode(($max_s_id * $max_t_id) * mt_rand(100000, 1000000));
    } else {
        $invoice = trim($_POST["invoice"]);
        $f_url = "&invoice=" . $invoice;
    }
    $this_date = date("Y-m-d H:i:s");
    if ($avoid_reg != true) {
        $sql = "INSERT INTO customer(a_id,r_id,customer_name,customer_code,customer_status,reg_date) "
                . "VALUES(\"$user\",\"$route\",\"$name\",\"$customer_code\",\"1\",\"$the_date\")";

        if (mysqli_query($conn, $sql)) {
            $c_id = mysqli_insert_id($conn);

            $sql_ous = "INSERT INTO `transaction`(invoice,c_id,transaction_date,total,ous,a_id,r_id,c_code) VALUES(0,\"$c_id\",\"$this_date\",\"$current_ous\",\"$current_ous\",\"$user\",\"$route\",\"$customer_code\")";

            if (mysqli_query($conn, $sql_ous)) {
                $url = "../return2.php?r_id=" . $route . "&c=" . $c_id . "&invoice=" . $invoice;
                ?>
                <script>
                    window.location.href = "<?= $url ?>";
                </script>
                <?php
            } else {
                ?>
                <script>
                    window.location.href = "../../app/select_customer.php";
                </script>
                <?php
            }
        }
    } else {
        ?>
        <script>
            window.location.href = "../../app/new_customer.php?err=<?= $err . $f_url ?>";
        </script>
        <?php
    }
}