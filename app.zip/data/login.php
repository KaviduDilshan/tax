<?php

session_start();
require_once '../../conn.php';

function validField($data, $type) {
    if ($type == 1) {
        if (!preg_match("/^[-a-z.A-Z_0-9]*$/", $data)) {
            return false;
        } else {
            return true;
        }
    } elseif ($type == 2) {
        if (!preg_match("/^[0-9]*$/", $data)) {
            return false;
        } else {
            return true;
        }
    } elseif ($type == 3) {
        if (!preg_match("/^[a-zA-Z ]*$/", $data)) {
            return false;
        } else {
            return true;
        }
    } elseif ($type == 4) {
        if (!preg_match("/^[-a-z.A-Z_)(0-9#@]*$/", $data)) {
            return false;
        } else {
            return true;
        }
    }
}

if (isset($_GET["username"]) && isset($_GET["password"])) {
    $obj = [];
    $username = trim($_GET["username"]);
    $password = trim($_GET["password"]);
    $avoid_login = false;
    if (!validField($username, 1) && validField($password, 4)) {
        $avoid_login = true;
        $obj["error"] = 1;
    } elseif (validField($username, 1) && !validField($password, 4)) {
        $avoid_login = true;
        $obj["error"] = 2;
    } elseif (!validField($username, 1) && !validField($password, 4)) {
        $avoid_login = true;
        $obj["error"] = 3;
    }
    if ($avoid_login != true) {
        $sql = "SELECT * FROM admins WHERE a_username=\"$username\" AND a_type=4";
        $user_re = mysqli_fetch_assoc(mysqli_query($conn, $sql));
        if ($user_re != null) {
            if (password_verify($password, $user_re["a_password"])) {
                $_SESSION["user"] = $user_re;
                $obj["error"] = 0;
            } else {
                $obj["error"] = 5;
            }
        } else {
            $obj["error"] = 4;
        }
    }
    echo json_encode($obj);
}