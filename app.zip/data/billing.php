
<?php
session_start();
include '../../conn.php';
// include '../../inc/functions.php';

if (isset($_POST["pg_cus"])) {
//    $qr_code = trim($_POST["qr_code"]);
//    $cus = 0;
//    $route = 0;
//    $cus_code = trim($_POST["customer_code"]);
//    $error = 0;
//    if ($cus == 0) {
//        $cus_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customer WHERE customer_code='$cus_code'"));
//        if ($cus_det != null) {
//            $cus = $cus_det["c_id"];
//            $route = base64_encode($cus_det["r_id"]);
//        } else {
//            $error = 1;
//        }
//    }

    if (!isset($_POST["invoice"])) {
        $max_s_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(sales_id) FROM sales_order"))["MAX(sales_id)"]) + 1;
        $max_t_id = intval(mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(t_id) FROM transaction"))["MAX(t_id)"]) + 1;
        $invoice = base64_encode($_SESSION["user"]["a_id"] . (($max_s_id * $max_t_id) * mt_rand(100, 1000) * mt_rand(10000, 100000)));
    } else {
        $invoice = trim($_POST["invoice"]);
    }
    if ($error == 0) {
        ?>
        <script>window.location.href = "<?= "../return2.php?c=" . $cus . "&r=" . $route . "&invoice=" . $invoice ?>";</script>
        <?php
    } else {
        ?>
        <script>window.location.href = "../select_customer.php";</script>
        <?php
    }
}
