<div class="pages">
    <div data-page="team" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
           // include 'sessions.php';
            ?>

            <div id="pages_maincontent">

                <h2 class="page_title" style="text-align: center;"><strong>RETURN PRODUCTS</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <div class="swiper-container-team swiper-init" data-effect="slide" data-space-between="10" data-pagination=".swiper-pagination-team" data-slides-per-view="2">

                        <div class="page_single layout_fullwidth_padding">
                            <div class="contactform">
                                <form class="cmxform" id="ContactForm" method="post" action="data/return.php">
                                    <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                                    <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                                    <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                                    <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
                                    <div class="form_row">
                                        <label>PRODUCT PRICE:</label>
                                        <input type="text" name="pro_price" class="form_input" required/>
                                    </div>
                                    <div class="form_row">
                                        <label>QTY:</label>
                                        <input type="number" name="rqty" class="form_input" required/>
                                    </div>
                                    <input type="submit" name="add" class="form_submit" id="submit" value="ADD" />
                                    <label id="loader" style="display:none;"><img src="images/loader.gif" alt="Loading..." id="LoadingGraphic" /></label>
                                </form>
                                <br>
                                <ul class="responsive_table">
                                    <li class="table_row">
                                        <div class="table_section_small" style="width: 15px;">#</div>
                                        <div class="table_section_small">QTY</div> 
                                        <div class="table_section">PRODUCT PRICE</div>
                                        <div class="table_section_small">TOTAL</div>
                                    </li>
                                    <?php
                                    $loop = 1;
                                    $sales_re = getReturnByInvoice($conn, base64_decode($_GET["invoice"]));
                                    while ($row = mysqli_fetch_array($sales_re)) {
                                        ?>
                                        <li class="table_row" id="re_row_<?= $loop ?>">
                                            <div class="table_section_small text-right" style="width: 15px; color: red;" onclick="delFromReturn('<?= base64_encode($row["r_id"]) ?>', '<?= $loop ?>')"><strong>X</strong></div>
                                      
                                            <div class="table_section_small"><?= $row["quantity"] ?></div> 
                                            <div class="table_section"><?= number_format($row["unit_price"], 2, ".", ",") ?></div>
                                            <div class="table_section_small"><?= number_format($row["total"], 2, ".", ",") ?></div> 
                                        </li>
                                        <?php
                                        $loop++;
                                    }
                                    ?>
                                </ul>
                                
                            </div>
                        </div>
                            <div class="contactform">
                            <form method="get" id="next_1" action="bill_print/woosim/return.php">
                                <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                                <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                                <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                                <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
                                   <input type="submit" name="add" class="form_submit" id="submit" value="PRINT" />
                            </form>
                            </div>
                        <div class="shop_pagination">
                            
                            <a href="product.php?invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>&c=<?= $_GET["c"] ?>&cat=<?= $_GET["cat"] ?>" class="prev_shop">BACK</a>
                            <span class="shop_pagenr"> </span>
                            <form method="get" id="next" action="billing.php">
                                <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                                <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                                <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                                <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
                                  <a href="#" onclick="$('#next').submit()" class="next_shop">NEXT</a>
                            </form>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'inc/footer.php';
