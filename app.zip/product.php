
<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
            include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>SELECT PRODUCT</strong></h2>
                <div class="page_single layout_fullwidth_padding">
                    <h3>Total: LKR. <b><span id="tot_dis"><?=  number_format(getSumByInvoice($conn, base64_decode($_GET["invoice"]))["SUM(total)"], 2, ".", ","); ?></span></b></h3>
                    <ul class="shop_items">
                        <?php
                        $pro_re = getProductsByCat($conn, base64_decode($_GET["cat"]));
                        $loop = 1;
                        while ($row = mysqli_fetch_array($pro_re)) {
                            ?>
                            <form method="GET" action="data/add_to_cart.php" id="form_<?= $loop ?>">
                                    <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                                    <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                                    <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                                    <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
                            <li>
                                <div class="shop_thumb"><img src="images/photos/1.jpg" alt="" title="" /></div>
                                <div class="shop_item_details">
                                    <h4><?= $row["barcode"] . ". " .$row["product_name"] ?></h4>
                                    <table>
                                        <tr style="display:none">
                                            <td style="width:500px;"></td>
                                            <td><input type="text" value="<?= base64_encode($row["pro_id"]) ?>" name="pro" readonly required hidden></td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="width:500px;">PRICE </td>
                                            <td><input type="number" value="<?= number_format(floatval($row["unit_price"]), 2); ?>" name="u_price"></td>
                                        </tr>
                                        <tr>
                                            <td style="width:500px; font-size:6px;">----------------------------------------------------- </td>
                                            <td> </td>
                                        </tr>
                                        <tr>
                                            <td style="width:500px;">QTY </td>
                                            <td><input type="number" name="qty"></td>
                                        </tr>
                                        <tr>
                                            <td style="width:500px; font-size:6px;">----------------------------------------------------- </td>
                                            <td> </td>
                                        </tr>
                                        <tr>
                                            <td style="width:500px;">FREE </td>
                                            <td><input type="number" name="f_qty"></td>
                                        </tr>
                                        <tr>
                                            <td style="width:500px; font-size:6px;">----------------------------------------------------- </td>
                                            <td> </td>
                                        </tr>
                                    </table>
                                    <a  href="#" onclick="$('#form_<?= $loop ?>').submit()" id="addtocart" style="width:170px;">ADD TO BILL</a>
                                </div>
                            </li> 
                            </form>
                            <?php
                            $loop++;
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="category.php?invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>&c=<?= $_GET["c"] ?>" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="return.php?invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>&c=<?= $_GET["c"] ?>&cat=<?= $_GET["cat"] ?>" class="next_shop">NEXT</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'inc/footer.php';
