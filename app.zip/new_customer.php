<?php include '../conn.php';?>

<!DOCTYPE html>
<html>
    <head>
        <title>Customers</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 2%;">

        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> REGISTER NEW CUSTOMER </strong></h5></div><br>
        <div class="col col-sm-12">
            <div class="row">
                <h2 class="page_title" style="text-align: center;"><strong></strong></h2>
                <?php
                if (isset($_GET['err'])) {
                    $err = intval($_GET['err']);
                    ?>
                    <div style="background-color: red;text-align: center;padding: 2%;font-size: 100%;font-weight: bold;color: #fff" id="err_txt">
                        <?php
                        if ($err == 1) {
                            echo 'Customer Already Exists';
                        }
                        ?>
                    </div><br>
                    <?php
                }
                ?>
                <form class="cmxform" id="ContactForm" method="post" action="data/customer.php">
                    <div class="col col-sm-6">
                        <?php
                        if (isset($_GET["invoice"]) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
                            $invoice = "&invoice=" . $_GET["invoice"];
                            ?>
                            <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                            <?php
                        }
                        ?>
                        <label>CUSTOMER NAME:</label>
                        <input type="text" value="" name="cname" onchange="$('#err_txt').hide()" class="form-control" style="width: 100%; height:50px ;" required autocomplete="off">
                    </div><br>
                    <div class="col col-sm-6">
                        <input type="number" name="reg_type" value="1" required readonly hidden/>
                        <label>CUSTOMER CODE:</label>
                        <input type="text" value="" name="customer_code" onchange="$('#err_txt').hide()" class="form-control" style="width: 100%; height:50px ;" required autocomplete="off">
                    </div><br>
                    <div class="col col-sm-6">
                        <label>ROUTE:</label>
                        <select class="form-control" style="width: 100%; height:50px ;" name="r_id" id="r_id">
                            <?php
                            $query_rou = "SELECT * FROM `route`";
                            $result_rou = mysqli_query($conn, $query_rou);
                            while ($row_rou = mysqli_fetch_array($result_rou)) {
                                ?>
                                <option value="<?php echo $row_rou['r_id']; ?>">
                                    <?php echo $row_rou['name']; ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>
                        <!--<input type="text" name="route" id="route" onchange="$('#err_txt').hide()" class="form-control" style="width: 100%; height:50px ;" required>-->
                    </div><br>
                    <div class="col col-sm-6">
                        <label>OUTSTANDING:</label>
                        <input type="number" step="0.01" name="current_ous" id="current_ous" class="form-control" style="width: 100%; height:50px ;" autocomplete="off">
                    </div><br>
                    <div class="col col-sm-6">
                        <input type="submit" name="add" class="btn btn-primary" value="REGISTER" style="width: 100%; background-color: #007aff;"/>
                    </div><br>

                </form>
                <br>
                <a href="select_customer.php" class="btn btn-primary" style="width: 100%;">BACK TO HOME</a>
                <br>
            </div>
        </div>     
    </div>
