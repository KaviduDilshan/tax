<!DOCTYPE html>
<html>
    <head>
        <?php
        session_start();
        ?>
        <title>Syncing</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="../new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="../new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="../new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="../new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="../new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="../new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
<!--        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>-->
        <!-- lined-icons -->
        <link rel="stylesheet" href="../new/css/icon-font.min.css" type='text/css' />
    </head>

    <body style="margin-top: 5%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> ----- Download Last Bills ----- </strong></h5></div><br>
        <br>
        <div class="container">
            <div class="col col-sm-12">
                <div class="row">
                    <form action="../../api/backup_local.php">
                        <div class="col col-sm-12">
                            <select name="r" style="width: 100%">
                                <?php
                                require '../../conn.php';
                                $result = mysqli_query($conn, "SELECT * FROM `route`");
                                while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <option value="<?= base64_encode($row["r_id"]) ?>"><?= $row["name"] ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div><br>
                        <div class="col col-sm-12">
                            <button type="submit" class="btn btn-success" style="width: 100%">CONTINUE</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <br><br>
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> ----- Sync New Bills ----- </strong></h5></div><br>
        <br>
        <div class="container">
            <div class="col col-sm-12">
                <div class="row">
                    <!--<a href="../../api/index_5.php" class="btn btn-success" style="width: 100%">Sync Cash Count</a> <br><br><br>-->
                    <a href="../../api/" class="btn btn-success" style="width: 100%">Sync Now</a> <br><br><br>
                    <a href="../index.php" class="btn btn-danger" style="width: 100%">Cancel</a>
                </div>
            </div>
        </div>
    </body>
</html>

