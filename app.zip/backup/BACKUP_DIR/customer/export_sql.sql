USE `venrocha_venro`;
SET foreign_key_checks = 0;
SET foreign_key_checks = 1;
