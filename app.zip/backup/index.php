﻿<?php
session_start();
if (isset($_SESSION["user"])) {
    $user_det = $_SESSION["user"];
    $url = '?token=' . md5($user_det["a_id"]) . "_" . md5($user_det["a_username"]) . "_" . md5(mt_rand(100000, 1000000)) . "&val=" . base64_encode($user_det["a_id"]);

    if (file_exists('BACKUP_DIR/export_sql.sql')) {
        unlink('BACKUP_DIR/export_sql.sql');
    }

    /**
     * This file contains the Backup_Database class wich performs
     * a partial or complete backup of any given MySQL database
     * @author Daniel López Azaña <daniloaz@gmail.com>
     * @version 1.0
     */
    /**
     * Define database parameters here
     */
    define("DB_USER", 'root');
    define("DB_PASSWORD", '');
    define("DB_NAME", 'venrocha_venro');
    define("DB_HOST", 'localhost');
//define("BACKUP_DIR", 'D:\Backup'); // Comment this line to use same script's directory ('.')
    define("TABLES", '*'); // Full backup
//define("TABLES", 'table1, table2, table3'); // Partial backup
    define("CHARSET", 'utf8');
    define("GZIP_BACKUP_FILE", true); // Set to false if you want plain SQL backup files (not gzipped)
    define("DISABLE_FOREIGN_KEY_CHECKS", true); // Set to true if you are having foreign key constraint fails
    define("BATCH_SIZE", 1000); // Batch size when selecting rows from database in order to not exhaust system memory
// Also number of rows per INSERT statement in backup file
    /**
     * The Backup_Database class
     */

    class Backup_Database {

        /**
         * Host where the database is located
         */
        var $host;

        /**
         * Username used to connect to database
         */
        var $username;

        /**
         * Password used to connect to database
         */
        var $passwd;

        /**
         * Database to backup
         */
        var $dbName;

        /**
         * Database charset
         */
        var $charset;

        /**
         * Database connection
         */
        var $conn;

        /**
         * Backup directory where backup files are stored 
         */
        var $backupDir;

        /**
         * Output backup file
         */
        var $backupFile;

        /**
         * Use gzip compression on backup file
         */
        var $gzipBackupFile;

        /**
         * Content of standard output
         */
        var $output;

        /**
         * Disable foreign key checks
         */
        var $disableForeignKeyChecks;

        /**
         * Batch size, number of rows to process per iteration
         */
        var $batchSize;
        var $delete_rows = array();

        /**
         * Constructor initializes database
         */
        public function __construct($host, $username, $passwd, $dbName, $charset = 'utf8') {
            $this->host = $host;
            $this->username = $username;
            $this->passwd = $passwd;
            $this->dbName = $dbName;
            $this->charset = $charset;
            $this->conn = $this->initializeDatabase();
            $this->backupDir = '.';
            $this->backupFile = 'export_sql.sql';
            $this->gzipBackupFile = defined('GZIP_BACKUP_FILE') ? GZIP_BACKUP_FILE : true;
            $this->disableForeignKeyChecks = defined('DISABLE_FOREIGN_KEY_CHECKS') ? DISABLE_FOREIGN_KEY_CHECKS : true;
            $this->batchSize = defined('BATCH_SIZE') ? BATCH_SIZE : 1000; // default 1000 rows
            $this->output = '';
        }

        protected function initializeDatabase() {
            try {
                $conn = mysqli_connect($this->host, $this->username, $this->passwd, $this->dbName);
                if (mysqli_connect_errno()) {
                    throw new Exception('ERROR connecting database: ' . mysqli_connect_error());
                    die();
                }
                if (!mysqli_set_charset($conn, $this->charset)) {
                    mysqli_query($conn, 'SET NAMES ' . $this->charset);
                }
            } catch (Exception $e) {
                print_r($e->getMessage());
                die();
            }
            return $conn;
        }

        /**
         * Backup the whole database or just some tables
         * Use '*' for whole database or 'table1 table2 table3...'
         * @param string $tables
         */
        public function backupTables($tables = '*') {
            $theDate = strtotime(date("Y-m-d"));
            try {
                /**
                 * Tables to export
                 */
                if ($tables == '*') {
                    $tables = array();
                    $result = mysqli_query($this->conn, 'SHOW TABLES');
//                while ($row = mysqli_fetch_row($result)) {
                    $tables[] = 'sales_order';
                    $tables[] = 'transaction';
                    $tables[] = 'return_stock';
                    $tables[] = 'cash_count';
                    $tables[] = 'expenses';
                    $tables[] = 'free_sales';
                    $tables[] = 'customer';
//                }
                } else {
                    $tables = is_array($tables) ? $tables : explode(',', str_replace(' ', '', $tables));
                }
//            $sql = 'CREATE DATABASE IF NOT EXISTS `' . $this->dbName . "`;\n\n";
                $sql = 'USE `' . $this->dbName . "`;\n";
                /**
                 * Disable foreign key checks 
                 */
                if ($this->disableForeignKeyChecks === true) {
                    $sql .= "SET foreign_key_checks = 0;\n";
                }
                /**
                 * Iterate tables
                 */
                $products = [];
                $qty = [];
                foreach ($tables as $table) {
//                $this->obfPrint("Backing up `" . $table . "` table..." . str_repeat('.', 50 - strlen($table)), 0, 0);
                    /**
                     * CREATE TABLE
                     */
//                $sql .= 'DROP TABLE IF EXISTS `' . $table . '`;';
//                $row = mysqli_fetch_row(mysqli_query($this->conn, 'SHOW CREATE TABLE `' . $table . '`'));
//                $sql .= "\n\n" . $row[1] . ";\n\n";
                    /**
                     * INSERT INTO
                     */
                    $row = mysqli_fetch_row(mysqli_query($this->conn, 'SELECT COUNT(*) FROM `' . $table . '`'));
                    $numRows = $row[0];
                    // Split table in batches in order to not exhaust system memory 
                    $numBatches = intval($numRows / $this->batchSize) + 1; // Number of while-loop calls to perform
//                $numBatches = intval($numRows);
                    for ($b = 1; $b <= $numBatches; $b++) {
                                $rowCount = 1;

                        $have_data = false;
                        $query = 'SELECT * FROM `' . $table . '` LIMIT ' . ($b * $this->batchSize - $this->batchSize) . ',' . $this->batchSize;
//                    $query = 'SELECT * FROM `' . $table . '`';
                        $realBatchSize = 0;
                        $result2 = mysqli_query($this->conn, 'SELECT * FROM `' . $table . '`');
                        while ($row = mysqli_fetch_row($result2)) {
                            $have_pro = false;
                            $row_date = null;
                            if ($table == 'sales_order') {
                                $row_date = ($row[2]);
                            } elseif ($table == 'transaction') {
                                $row_date = ($row[2]);
                            } elseif ($table == 'return_stock') {
                                $row_date = ($row[3]);
                            } elseif ($table == 'cash_count') {
                                $row_date = ($row[2]);
                            } elseif ($table == 'expenses') {
                                $row_date = ($row[2]);
                            } elseif ($table == 'free_sales') {
                                $row_date = ($row[4]);
                            } elseif ($table == 'customer') {
                                $row_date = ($row[16]);
                            }
                            $db_date = strtotime(explode(" ", $row_date)[0]);
                            if (($row_date != null) && ($theDate == $db_date)) {
                                $realBatchSize++;
                            }
                        }

                        $result = mysqli_query($this->conn, $query);
//                        $realBatchSize = mysqli_num_rows($result); // Last batch size can be different from $this->batchSize
                        $numFields = mysqli_num_fields($result);

                        if ($realBatchSize !== 0) {
                            for ($i = 0; $i < $numFields; $i++) {
//                                $rowCount = 1;
                                while ($row = mysqli_fetch_row($result)) {
                                    $have_pro = false;
                                    $row_date = null;
                                    if ($table == 'sales_order') {
                                        $row_date = ($row[2]);
                                    } elseif ($table == 'transaction') {
                                        $row_date = ($row[2]);
                                    } elseif ($table == 'return_stock') {
                                        $row_date = ($row[3]);
                                    } elseif ($table == 'cash_count') {
                                        $row_date = ($row[2]);
                                    } elseif ($table == 'expenses') {
                                        $row_date = ($row[2]);
                                    } elseif ($table == 'free_sales') {
                                        $row_date = ($row[4]);
                                    } elseif ($table == 'customer') {
                                        $row_date = ($row[16]);
                                    }
                                    $db_date = strtotime(explode(" ", $row_date)[0]);
                                    if (($row_date != null) && ($theDate == $db_date)) {
                                        $invoice = $row[1];
                                        $trans_data = mysqli_fetch_assoc(mysqli_query($this->conn, "SELECT * FROM `transaction` WHERE `invoice`=\"$invoice\" AND `status`=1"));
                                        if ($trans_data == null) {
                                            $this_qty = floatval($row[4]);
                                            if ($table == 'sales_order') {
                                                $l = count($products);
                                                while ($l > 0) {
                                                    if ($products[$l - 1] == $row[3]) {
                                                        $have_pro = true;
                                                        $qty[$l - 1] += floatval($row[4]);
                                                        break;
                                                    }
                                                    $l--;
                                                }
                                                if ($have_pro != true) {
                                                    $products[] = $row[3];
                                                    $qty[] = $this_qty;
                                                }
                                            } elseif ($table == 'free_sales') {
                                                $l = count($products);
                                                while ($l > 0) {
                                                    echo $row[3];
                                                    if ($products[$l - 1] == $row[3]) {
                                                        $have_pro = true;
                                                        $qty[$l - 1] += floatval($row[4]);
                                                        break;
                                                    }
                                                    $l--;
                                                }
                                                if ($have_pro != true) {
                                                    $products[] = $row[3];
                                                    $qty[] = $this_qty;
                                                }
                                            }
                                        }
                                        if ($have_data != true) {
                                            $sql .= 'INSERT INTO `' . $table . '` VALUES ';
                                        }
                                        $have_data = true;
                                        $sql .= '(';
                                        for ($j = 0; $j < $numFields; $j++) {
                                            if ($j > 0) {
                                                if (isset($row[$j])) {
                                                    $row[$j] = addslashes($row[$j]);
                                                    $row[$j] = str_replace("\n", "\\n", $row[$j]);
                                                    $row[$j] = str_replace("\r", "\\r", $row[$j]);
                                                    $row[$j] = str_replace("\f", "\\f", $row[$j]);
                                                    $row[$j] = str_replace("\t", "\\t", $row[$j]);
                                                    $row[$j] = str_replace("\v", "\\v", $row[$j]);
                                                    $row[$j] = str_replace("\a", "\\a", $row[$j]);
                                                    $row[$j] = str_replace("\b", "\\b", $row[$j]);
                                                    if ($row[$j] == 'true' or $row[$j] == 'false' or preg_match('/^-?[0-9]+$/', $row[$j]) or $row[$j] == 'NULL' or $row[$j] == 'null') {
                                                        $sql .= $row[$j];
                                                    } else {
                                                        $sql .= '"' . $row[$j] . '"';
                                                    }
                                                } else {
                                                    $sql .= 'NULL';
                                                }
                                            } else {
                                                $sql .= 'NULL';
                                                $this->delete_rows["'" . $row[$j] . "'"] = $table;
                                            }
                                            if ($j < ($numFields - 1)) {
                                                $sql .= ',';
                                            }
                                        }

                                        if ($rowCount == $realBatchSize) {
//                                            $rowCount = 1;
                                            $sql .= ");\n"; //close the insert statement
                                        } else {
                                            $sql .= "),\n"; //close the row
                                        }
                                        $rowCount++;
                                    }
                                }
                            }

                            $this->saveFile($sql);
                            $sql = '';
                        }
                    }

                    /**
                     * CREATE TRIGGER
                     */
                    // Check if there are some TRIGGERS associated to the table
                    /* $query = "SHOW TRIGGERS LIKE '" . $table . "%'";
                      $result = mysqli_query ($this->conn, $query);
                      if ($result) {
                      $triggers = array();
                      while ($trigger = mysqli_fetch_row ($result)) {
                      $triggers[] = $trigger[0];
                      }

                      // Iterate through triggers of the table
                      foreach ( $triggers as $trigger ) {
                      $query= 'SHOW CREATE TRIGGER `' . $trigger . '`';
                      $result = mysqli_fetch_array (mysqli_query ($this->conn, $query));
                      $sql.= "\nDROP TRIGGER IF EXISTS `" . $trigger . "`;\n";
                      $sql.= "DELIMITER $$\n" . $result[2] . "$$\n\nDELIMITER ;\n";
                      }
                      $sql.= "\n";
                      $this->saveFile($sql);
                      $sql = '';
                      } */

//                $sql .= "\n\n";
//                $this->obfPrint('OK');
                }
                /**
                 * Re-enable foreign key checks 
                 */
                $l = count($products);
                while ($l > 0) {
                    $pro_id = $products[$l - 1];
                    $pro_quantity = $qty[$l - 1];
                    $sql .= "UPDATE `products` SET `quantity` = `quantity`-$pro_quantity WHERE `pro_id`=$pro_id;\n";
                    $l--;
                }

                if ($this->disableForeignKeyChecks === true) {
                    $sql .= "SET foreign_key_checks = 1;\n";
                }
                $this->saveFile($sql);
//            if ($this->gzipBackupFile) {
//                $this->gzipBackupFile();
//            } else {
//                $this->obfPrint('Backup file succesfully saved to ' . $this->backupDir . '/' . $this->backupFile, 1, 1);
//            }
            } catch (Exception $e) {
                print_r($e->getMessage());
                return false;
            }
            return true;
        }

        /**
         * Save SQL to file
         * @param string $sql
         */
        protected function saveFile($sql) {
            if (!$sql)
                return false;
            try {
                foreach ($this->delete_rows as $key => $table) {
                    $primary_key_col = mysqli_fetch_assoc(mysqli_query($this->conn, "SHOW KEYS FROM `" . $table . "` WHERE Key_name = 'PRIMARY'"))["Column_name"];
  //                  $a = //mysqli_query($this->conn, 'DELETE FROM //transaction');
                  //  if ($a == TRUE){
                        //mysqli_query($this->conn, 'DELETE FROM sales_order');
                   // }
                }

                if (!file_exists($this->backupDir)) {
                    mkdir($this->backupDir, 0777, true);
                }
                file_put_contents('BACKUP_DIR/' . $this->backupFile, $sql, FILE_APPEND | LOCK_EX);
            } catch (Exception $e) {
                print_r($e->getMessage());
                return false;
            }
            return true;
        }

        /*
         * Gzip backup file
         *
         * @param integer $level GZIP compression level (default: 9)
         * @return string New filename (with .gz appended) if success, or false if operation fails
         */

        protected function gzipBackupFile($level = 9) {
            if (!$this->gzipBackupFile) {
                return true;
            }
            $source = $this->backupDir . '/' . $this->backupFile;
            $dest = $source . '.gz';
            $this->obfPrint('Gzipping backup file to ' . $dest . '... ', 1, 0);
            $mode = 'wb' . $level;
            if ($fpOut = gzopen($dest, $mode)) {
                if ($fpIn = fopen($source, 'rb')) {
                    while (!feof($fpIn)) {
                        gzwrite($fpOut, fread($fpIn, 1024 * 256));
                    }
                    fclose($fpIn);
                } else {
                    return false;
                }
                gzclose($fpOut);
                if (!unlink($source)) {
                    return false;
                }
            } else {
                return false;
            }

            $this->obfPrint('OK');
            return $dest;
        }

        /**
         * Prints message forcing output buffer flush
         *
         */
        public function obfPrint($msg = '', $lineBreaksBefore = 0, $lineBreaksAfter = 1) {
            if (!$msg) {
                return false;
            }
            if ($msg != 'OK' and $msg != 'KO') {
                $msg = date("Y-m-d H:i:s") . ' - ' . $msg;
            }
            $output = '';
            if (php_sapi_name() != "cli") {
                $lineBreak = "<br />";
            } else {
                $lineBreak = "\n";
            }
            if ($lineBreaksBefore > 0) {
                for ($i = 1; $i <= $lineBreaksBefore; $i++) {
                    $output .= $lineBreak;
                }
            }
            $output .= $msg;
            if ($lineBreaksAfter > 0) {
                for ($i = 1; $i <= $lineBreaksAfter; $i++) {
                    $output .= $lineBreak;
                }
            }
            // Save output for later use
            $this->output .= str_replace('<br />', '\n', $output);
            echo $output;
            if (php_sapi_name() != "cli") {
                if (ob_get_level() > 0) {
                    ob_flush();
                }
            }
            $this->output .= " ";
            flush();
        }

        /**
         * Returns full execution output
         *
         */
        public function getOutput() {
            return $this->output;
        }

    }

    $backupDatabase = new Backup_Database(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, CHARSET);
    $result = $backupDatabase->backupTables();
    if ($result) {
        $remote_file = 'BACKUP_DIR/export_sql.sql';

        /* FTP Account */
        $ftp_host = 'ftp.venrochandana.com'; /* host */
        $ftp_user_name = 'local@venrochandana.com'; /* username */
        $ftp_user_pass = 'local@123'; /* password */


        /* New file name and path for this file */
        $local_file = 'export_sql.sql';

        /* Connect using basic FTP */
        $connect_it = ftp_connect( $ftp_host );

        /* Login to FTP */
        $login_result = ftp_login( $connect_it, $ftp_user_name, $ftp_user_pass );

        /* Download $remote_file and save to $local_file */
        if ( ftp_put( $connect_it, $local_file, $remote_file, FTP_BINARY ) ) {
  header('location:https://venrochandana.com/app/backup/' . $url);
        }
        else {
            echo "Doh! There was a problem\n";
        }

        /* Close the connection */
        ftp_close( $connect_it );
//        header('location:https://venrochandana.com/app/backup/' . $url);
    } else {
        header('location:../');
    }
} else {
    header('location:../');
}