<!DOCTYPE html>
<html >
    <head>
        <style>
            /*Styling preloader*/
            .preloader{
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                z-index: 1000;
            }
        </style>
    </head>

    <body>
        <div class="preloader">
            <span class="preloader-js">
                <img src="loader.gif" style="width: 100%">
                <br>
                <h1 style="text-align: center">Please Wait For While..</h1>
            </span>
        </div>
    </body>
    <script>

        window.onload = function () {
            location.href = "../";
        };
    </script>
</html>
<?php
require '../../conn.php';

class sqlImporter {

    function __construct($sqlfile, $connection) {

        $file = file($sqlfile);
        $sql = "";
        $del_num = false;
        foreach ($file as $line) {
            $query = trim($line);
            try {
                $delimiter = is_int(strpos($query, "DELIMITER"));
                if ($delimiter || $del_num) {
                    if ($delimiter && !$del_num) {
                        $sql = "";
                        $sql = $query . "; ";
                        $del_num = true;
                    } else if ($delimiter && $del_num) {
                        $sql .= $query . " ";
                        $del_num = false;
                        mysqli_query($connection, $sql);
                        $sql = "";
                    } else {
                        $sql .= $query . "; ";
                    }
                } else {
                    $delimiter = is_int(strpos($query, ";"));
                    if ($delimiter) {
                        mysqli_query($connection, "$sql $query");
                        $sql = "";
                    } else {
                        $sql .= " $query";
                    }
                }
            } catch (Exception $e) {
                echo $e->getMessage() . "<br /> <p>The sql is: $query</p>";
            }
        }
    }

}

$local_file = 'BACKUP_DIR/customer/export_sql.sql';
if (is_file($local_file)) {
   // mysqli_query($conn, 'TRUNCATE TABLE customer');
	//mysqli_query($conn, 'TRUNCATE TABLE products');
   // $file = "BACKUP_DIR/customer" . "/export_sql.sql";
   // $sqlImporter = new sqlImporter($file, $conn);

header("location:../");
}

header("location:../");