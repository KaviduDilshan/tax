<?php

class sqlImporter {

    function __construct($sqlfile, $connection) {

        $file = file($sqlfile);
        $sql = "";
        $del_num = false;
        foreach ($file as $line) {
            $query = trim($line);
            try {
                $delimiter = is_int(strpos($query, "DELIMITER"));
                if ($delimiter || $del_num) {
                    if ($delimiter && !$del_num) {
                        $sql = "";
                        $sql = $query . "; ";
                        $del_num = true;
                    } else if ($delimiter && $del_num) {
                        $sql .= $query . " ";
                        $del_num = false;
                        mysqli_query($connection, $sql);
                        $sql = "";
                    } else {
                        $sql .= $query . "; ";
                    }
                } else {
                    $delimiter = is_int(strpos($query, ";"));
                    if ($delimiter) {
                        mysqli_query($connection, "$sql $query");
                        $sql = "";
                    } else {
                        $sql .= " $query";
                    }
                }
            } catch (Exception $e) {
                echo $e->getMessage() . "<br /> <p>The sql is: $query</p>";
            }
        }
    }

}

define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "venrocha_venro");
define('APP_NAME', 'venro');


$conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

if (isset($_POST["submit"])) {
    $base_dir = "BACKUP_DIR";

    if (!empty($_FILES["sqlFile"]["name"])) {
        $total = 1;
        $ext = explode("/", $_FILES["sqlFile"]["type"])[1];
        $file = $base_dir . "/v_" . date("Y-m-d") . ".sql";
        if (move_uploaded_file($_FILES["sqlFile"]["tmp_name"], $file)) {
            $sqlImporter = new sqlImporter($file, $conn);
        }
    }
}
header("location:upload.php?err=0");
