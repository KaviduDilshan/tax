<?php

$remote_file = 'customer/export_sql.sql';

/* FTP Account */
$ftp_host = 'ftp.venrochandana.com'; /* host */
$ftp_user_name = 'local@venrochandana.com'; /* username */
$ftp_user_pass = 'local@123'; /* password */


/* New file name and path for this file */
$local_file = 'BACKUP_DIR/customer/export_sql.sql';
if (is_file($local_file)) {
    unlink($local_file);
}

/* Connect using basic FTP */
$connect_it = ftp_connect($ftp_host);

/* Login to FTP */
$login_result = ftp_login($connect_it, $ftp_user_name, $ftp_user_pass);

/* Download $remote_file and save to $local_file */
if (ftp_get($connect_it, $local_file, $remote_file, FTP_BINARY)) {
    header('location:sync_cus.php');
} else {
    header('location:../');
}

/* Close the connection */
ftp_close($connect_it);


