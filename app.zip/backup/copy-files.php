<?php
/**
 * Transfer (Import) Files Server to Server using PHP FTP
 * @link https://shellcreeper.com/?p=1249
 */

/* Source File Name and Path */
$remote_file = 'BACKUP_DIR/export_sql.sql';

/* FTP Account */
$ftp_host = 'ftp.venrochandana.com'; /* host */
$ftp_user_name = 'local@venrochandana.com'; /* username */
$ftp_user_pass = 'local@123'; /* password */


/* New file name and path for this file */
$local_file = 'export_sql.sql';

/* Connect using basic FTP */
$connect_it = ftp_connect( $ftp_host );

/* Login to FTP */
$login_result = ftp_login( $connect_it, $ftp_user_name, $ftp_user_pass );

/* Download $remote_file and save to $local_file */
if ( ftp_put( $connect_it, $local_file, $remote_file, FTP_BINARY ) ) {
    echo "WOOT! Successfully written to $local_file\n";
}
else {
    echo "Doh! There was a problem\n";
}

/* Close the connection */
ftp_close( $connect_it );
?>