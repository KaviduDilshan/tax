<?php

include_once '../inc/functions.php';
?>
<div class="homenavbar" style="background-image: linear-gradient(to top, transparent 0% , black 120%);">
    <!--<h1> <a href="index.php"> <span>< </span></a></h1>-->
    <?php if (userLogined()) { ?>
        <a href="#" data-panel="right" class="open-panel">
            <div class="navbar_right"><img src="images/icons/white/user.png" alt="" title="" /></div>
        </a>
    <?php } ?>
    <a href="#" data-panel="left" class="open-panel">
        <div class="navbar_right"><img src="images/icons/white/menu.png" alt="" title="" /></div>
    </a>
</div>
