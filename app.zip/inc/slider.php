<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../inc/functions.php';
?>

<div class="statusbar-overlay"></div>
<div class="panel-overlay"></div>
<div class="panel panel-left panel-reveal">
    <nav class="sidebar-nav">
        <ul>
            <li><h3 style="text-align: center; color: #fff; margin-top: 10%;"><strong>VENRO CHANDANA MEDICINE</strong></h3></li>
            <li><a href="index.php"><img src="images/icons/white/home.png" alt="" title="" /><span>BACK TO HOME</span></a></li>
            <li><a <?= userLogined('customer.php'.$in2) ?>><img src="images/icons/white/form.png" alt="" title="" /><span>START BILLING</span></a></li>
            <li><a <?= userLogined('customer_list_view.php') ?>><img src="images/icons/white/user.png" alt="" title="" /><span>ADD NEW CUSTOMER</span></a></li>
            <li><a <?= userLogined('shop.php') ?>><img src="images/icons/white/shop.png" alt="" title="" /><span>PRODUCT lIST</span></a></li>
            <li><a <?= userLogined('history.php') ?>><img src="images/icons/white/categories.png" alt="" title="" /><span>HISTORY</span></a></li>
            <li><a <?= userLogined('location_view.php') ?>><img src="images/icons/white/map.png" alt="" title="" /><span>LOCATIONS</span></a></li>
            <?php if (userLogined()) { ?>
                <li><a href="#" onclick="logOut()"><img src="images/icons/white/logout.png" alt="" title="" /><span>LOGOUT</span></a></li>
            <?php } else { ?>
                <li><a href="#" data-popup=".popup-login" class="open-popup"><img src="images/icons/white/lock.png" alt="" title="" /><span>LOGIN</span></a></li>
            <?php } ?>
        </ul>
    </nav>
</div>

<div class="panel panel-right panel-reveal">
    <div class="user_login_info">
        <div class="user_thumb">
            <div class="user_avatar"><img src="images/avt.png" alt="" title="" /></div>  
            <div class="user_details">
                <p>Welcome <span><?= $_SESSION["user"]["a_name"] ?></span></p>
            </div>  
            <div class="user_social">
                <ul>
                    <li><a href="http://twitter.com/" class="external"><img src="images/icons/green/twitter.png" alt="" title="" /></a></li>
                    <li><a href="http://www.facebook.com/" class="external"><img src="images/icons/green/facebook.png" alt="" title="" /></a></li>
                    <li><a href="http://plus.google.com" class="external"><img src="images/icons/green/gplus.png" alt="" title="" /></a></li>
                </ul>	  
            </div>     
        </div>
        <nav class="user-nav">
            <ul>
<!--                <li><a href="#" class="close-panel"><img src="images/icons/white/settings.png" alt="" title="" /><span>Account Settings</span></a></li>
                <li><a href="#" class="close-panel"><img src="images/icons/white/briefcase.png" alt="" title="" /><span>My Account</span></a></li>
                <li><a href="#" class="close-panel"><img src="images/icons/white/message.png" alt="" title="" /><span>Messages</span><strong>12</strong></a></li>-->
                <li><a href="#" onclick="logOut()"><img src="images/icons/white/logout.png" alt="" title="" /><span>LOGOUT</span></a></li>

            </ul>
        </nav>
    </div>
</div>