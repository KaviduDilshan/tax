<?php
session_start();
include_once '../inc/functions.php';
if (!isset($_SESSION["user"])) {
    header("location:../app/");
}
$prev = 0;
if (isset($_GET["prev"])) {
    $prev = intval($_GET["prev"]);
}
if (!isset($_GET['prev'])) {
    if (isset($_SESSION['from_print'])) {
        unset($_SESSION['from_print']);
        //  header("location:../app/");
    }
} else {
    if (isset($_SESSION['from_print'])) {
        unset($_SESSION['from_print']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Billing</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
        <!--        <link href="new/fonts.css" rel='stylesheet' type='text/css'/>
                <link href="new/fonts2.css" rel='stylesheet' type='text/css'>-->
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
    </head>
    <body style="padding-top: 0%;">
        <form action="data/add_sales.php" method="post" class="form-horizontal">
            <div class="span12" style="padding:2%;">
                <?php $user_det = getUserDet($conn, ($_GET["c"])); ?>
                <input class="form-control" type="text" name="pro_code" Placeholder="Product Code" style="margin-bottom:2%; height: 40px; font-size: 15px;" required autocomplete="off"/>
                <input class="form-control" type="number" name="qty" Placeholder="QTY" style="margin-bottom:2%; height: 40px; font-size: 15px;" autocomplete="off"/>
                <input class="form-control" type="number" name="u_price" Placeholder="Unit Price" style="margin-bottom:2%; height: 40px; font-size: 15px;" autocomplete="off"/>
                <input class="form-control" type="number" name="f_qty" Placeholder="Free Items" style="margin-bottom:2%; height: 40px; font-size: 15px;" autocomplete="off"/>
                <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                <input type="text" value="<?= $_GET["r_id"] ?>" name="r" readonly required hidden>
                <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly hidden>
                <button type="submit" name="add" value="0" class="form-control btn-sm btn-primary" style="font-size: 15px; background-color: #007aff;"><strong> ADD ITEM TO BILL </strong></button><br>
            </div>
        </form>
        <div id="content">
            <div class="container-fluid">
                <div class="row-fluid">
                    <div class="span8">
                        <form action="data/transaction.php" method="post" class="form-horizontal">
                            <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                            <input type="text" value="<?= $_GET["r_id"] ?>" name="r" readonly required hidden>
                            <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                            <!--<input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly  hidden>-->
                            <input type="text" value="<?= $prev ?>" name="prev" readonly  hidden>
                            <div style="">
                                <table class="table table-bordered " id="tab_logic" data-responsive="table" style="">
                                    <thead>
                                        <tr>
                                            <th> Co</th>
                                            <th> Pr</th>
                                            <th> Qty </th>
                                            <th> Total </th>
                                            <th> # </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $full_url = "c=" . $_GET["c"] . "&r_id=" . $_GET["r_id"] . "&invoice=" . $_GET["invoice"];
                                        $c_id = $_GET["c"];
                                        $invoice = $tmp_in = base64_decode($_GET["invoice"]);
                                        $ret_det = getReturnDet($conn, $invoice);
                                        $ret_user = getUserReturnDet($conn, ($_GET["c"]));
                                        $ous_det = getUserTrans($conn, ($_GET["c"]));
                                        $user_det = getUserDet($conn, ($_GET["c"]));
                                        $c_id = $_GET["c"];
                                        $cc_coden = $user_det["customer_code"];

                                        if (isset($_GET["prev_invoice"])) {
                                            $tmp_in = base64_decode($_GET["prev_invoice"]);
                                        }
//                                        $tmp_sql = "SELECT * FROM `transaction` WHERE `c_code`=\"$cc_coden\" AND `status`=0 AND `invoice` != '$tmp_in' ORDER BY `t_id` DESC";
                                        $tmp_sql = "SELECT sum(sub_total),sum(rturn),sum(discount),sum(paid_amount),sum(paid_cheque) FROM `transaction` WHERE `c_id`=\"$c_id\"";
//                                        echo $tmp_in;
                                        $last_trans_det = mysqli_fetch_assoc(mysqli_query($conn, $tmp_sql));

                                        //    $ous_amount = $ous_det["SUM(total)"] - $ous_det["SUM(paid_amount)"] - $ret_user;
                                        $ous_amount = floatval($last_trans_det["sum(sub_total)"] - ($last_trans_det["sum(rturn)"] + $last_trans_det["sum(discount)"] + $last_trans_det["sum(paid_amount)"] + $last_trans_det["sum(paid_cheque)"]));
                                        $re_tot = floatval($ret_det["SUM(total)"]);
                                        $loop = 1;
                                        $sales_re = getSalesByInvoice($conn, base64_decode($_GET["invoice"]));
                                        $sub_tot = 0;
                                        while ($row = mysqli_fetch_array($sales_re)) {
                                            $pro_id = $row["pro_id"];
                                            $pro_det = getProDet($conn, $pro_id);
                                            $sub_tot += (floatval($row["quantity"]) * $row["unit_price"]);
                                            $url = "?s=" . $row["sales_id"] . "&c=" . $_GET["c"] . "&r_id=" . $_GET["r_id"] . "&invoice=" . $_GET["invoice"];
                                            $freesales_re = getFreeSalesByInvoice($conn, base64_decode($_GET["invoice"]), $pro_id);
                                            $p_txt = '';
                                            $in_loop = 0;
                                            while ($in_loop < 2) {
                                                $p_txt .= trim($pro_det["product_name"])[$in_loop];
                                                $in_loop++;
                                            }
                                            ?>
                                            <tr class="record" style="color: #000;">
                                                <td style="font-size:12px; color: #000;"><?= $pro_det["barcode"] . ". " . $p_txt ?></td>
                                                <td style="font-size:12px; color:#000;"><input type="text" style="width: 70px; text-align: right; color: #000; height: 30px;" value='<?= number_format($row["unit_price"], 2, ".", ",") ?>' class="span12" readonly=""/></td>

                                                <td style="font-size:12px; color:#000;"><input type="text" style="width: 40px; text-align: center; color: #000; height: 30px;" name="srow_quantity" id="srow_quantity" value='<?= $row["quantity"] ?>' class="span12 qty" readonly=""/></td>
                                                <td style="font-size:12px; color:#000;"><input type="text" style="width: 70px; text-align: right; color: #000; height: 30px;" value='<?= number_format($row["total"], 2, ".", ",") ?>' class="span12 row_total" readonly=""/></td>
                                                <td style="font-size:12px; color:#000;"><a href='data/del_sales.php<?= $url ?>'><button type="button" class="btn-xs btn-warning" style="background-color: #9d0000;"><?php
                                                            if ($freesales_re == null) {
                                                                echo 'X';
                                                            } else {
                                                                echo $freesales_re;
                                                            }
                                                            ?></button></a></td>
                                            </tr>
                                            <?php
                                            $loop++;
                                        }
                                        $g_tot = $sub_tot;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                    <div class="span4">
                        <div style="background-color: #fff; padding: 2%;">
                            <table class="table table-bordered" id="tab_logic_total" style="border: none">
                                <tbody>
                                    <tr>
                                        <th class="text-right" style="width: 40%; font-size: 15px;">Sub Total</th>
                                        <td class="form-group2">
                                            <input type="text" id="sub_total" style="height: 30px; width: 100%; font-size: 14px; color: #000;" value="<?= number_format($sub_tot, 2, ".", ",") ?>" readonly autocomplete="off"/>
                                            <input type="text" id="sub_total_tmp" value="<?= $sub_tot ?>" hidden readonly/>
                                        </td>
                                    </tr>
                                    <?php
                                    if ($user_det["credit_accept"] != 0) {
                                        $g_tot += $ous_amount;
                                        ?>
                                        <tr>
                                            <th class="text-right" style="width: 40%; font-size: 15px;">Outstanding</th>
                                            <td class="form-group2">
                                                <input type="text" id="other_dis" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name="other_dis" value="<?= $ous_amount ?>" placeholder="0.00" readonly autocomplete="off"/>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                        
                                    <tr>
                                        <th class="text-right" style="width: 40%; font-size: 15px;">Return</th>
                                        <td class="form-group2">
                                            <input type="hidden" id="return" name="return" value="<?= $re_tot ?>">
                                            <input type="text" style="height:30px; width: 100%; font-size: 14px; color: #000;" readonly value="<?= number_format($re_tot, 2, ".", ",") ?>" autocomplete="off">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right" style="width: 40%; font-size: 15px;">Bill Amount</th>
                                        <td class="form-group2">
                                            <input type="text" id="total" name="final_tot" value="<?= $g_tot - $re_tot ?>" readonly required hidden>
                                            <input type="text" id="bill_amount_tmp" style="height: 30px; width: 100%; font-size: 14px; color: #000;" value="<?= $g_tot - $re_tot ?>" readonly autocomplete="off"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right" style="width: 40%; font-size: 15px;">Paid (Cash)</th>
                                        <td class="form-group2">
                                            <input type="number" step=".01" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name="paid_amount_cash" class="calcBal" id="paid_amount_cash" placeholder='0.00' autocomplete="off"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right" style="width: 40%; font-size: 15px;">Paid (Cheque)</th>
                                        <td class="form-group2">
                                            <input type="number" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name='paid_amount_cheque' class="calcBal" id="paid_amount_cheque" placeholder='0.00' autocomplete="off"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="form-group2 text-right" style="width: 40%; font-size: 15px;">Balance</th>
                                        <td class="form-group2 mb10">
                                            <input type="number" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name="balance" value="<?= 0 - ($g_tot - $re_tot) ?>" id="balance" class="balance" placeholder='0.00' readonly autocomplete="off"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-right" style="width: 40%; font-size: 16px;">Payment Type</th>
                                        <td class="form-group2">
                                            <select name="pay_type" style="width: 100%; height: 30px; color: #000;">
                                                <option value="1" >Cash</option>
                                                <option value="2">Cash / Cheque</option>
                                                <option value="3">Cheque</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr id="cheque_row" style="display: none; width: 40%; font-size: 15px;">
                                        <th class="text-right" style="width: 40%; font-size: 16px;">Cheque No</th>
                                        <td class="form-group2">
                                            <input type="text" name="cheque_no" placeholder="" style="height: 30px; width: 100%; font-size: 15px; color: #000;" autocomplete="off">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="form-group2" style="margin-left: 0%; margin-top: 5%;">
                                <a href="return2.php?<?= $full_url ?>" name="save_bill" class="btn btn-warning" style="width: 48%">Back</a>
                                <button type="submit" name="add" class="btn btn-success" style="width: 48%">Print Bill</button>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="new/js/jquery.nicescroll.js"></script>
        <script src="new/js/scripts.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="new/js/bootstrap.min.js"></script>
        <!-- /Bootstrap Core JavaScript -->	   
        <!-- morris JavaScript -->	
        <script src="new/js/raphael-min.js"></script>
        <script src="new/js/morris.js"></script>
        <script>
            function reduceBal() {
                localStorage.setItem("ch", $("#balance").val());
                $("#balance").val("0.00");
                document.getElementById("chec").setAttribute("onclick", "rec()");
            }
            function rec() {
                $("#balance").val(localStorage.getItem("ch"));
                localStorage.removeItem("ch");
                document.getElementById("chec").setAttribute("onclick", "reduceBal()");
            }
            $(".calcBal").on("input", function () {
                var paid_amount = parseFloat($("#paid_amount_cash").val());
                var paid_amount_cheque = parseFloat($("#paid_amount_cheque").val());
                if (isNaN(paid_amount_cheque)) {
                    paid_amount_cheque = 0;
                }
                if (isNaN(paid_amount)) {
                    paid_amount = 0;
                }
                var bill_amount_tmp = parseFloat($("#bill_amount_tmp").val());
                var balance = ((paid_amount + paid_amount_cheque) - bill_amount_tmp).toFixed(2);
                $("#balance").val(balance);
            });
            $("select[name='pay_type']").on("change", function () {
                var pay_type = parseInt($(this).val());
                if (pay_type == 2 || pay_type == 3) {
                    $("#cheque_row").show();
                } else {
                    $("#cheque_row").hide();
                }
            });

            $("#other_dis").on("input", function () {
                var other_dis = parseFloat($(this).val());
                if (isNaN(other_dis)) {
                    other_dis = 0;
                }
                var sub_total_tmp = parseFloat($("#sub_total_tmp").val());
                var return2 = parseFloat($("#return").val());
                var total_sum = (other_dis + sub_total_tmp - return2).toFixed(2);
                $("#bill_amount_tmp").val(total_sum);
            });
        </script>
    </body>
</html>