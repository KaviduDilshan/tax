<?php
include_once '../inc/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <?php
        session_start();
        $_SESSION['from_home'] = 1;
        $in2 = "";
        if (isset($_GET["invoice"]) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
            $in2 = "?invoice=" . $_GET["invoice"];
        }
        ?>
        <script>
            window.onbeforeunload = function () {
                window.location.href = 'index.php';
            };
        </script>
        <title>Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 5%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> SOORIYA PRODUCTS </strong></h5></div><br>
        <div class="col col-sm-12">
            <div class="row">
                <div class="col col-sm-6">
                    <a <?= userLogined('select_route.php' . $in2) ?> style="width: 100%; background-color: #007aff;"><span>START BILLING</span></a><br>
                </div> <br>
                <div class="col col-sm-6">
                    <a <?= userLogined('customer_free.php') ?> style="width: 100%; background-color: #007aff;"><span>CUSTOMER LIST</span></a><br>
                </div><br>
                <div class="col col-sm-6">
                    <a <?= userLogined("pay_oustanding.php") ?> style="width: 100%; background-color: #007aff;"><span>OUSTANDING LIST</span></a><br>
                </div> <br>
                <div class="col col-sm-6">
                    <a <?= userLogined("shop.php") ?> style="width: 100%; background-color: #007aff;"><span>PRODUCT lIST</span></a><br>
                </div><br>
                <div class="col col-sm-12">
                    <a href="backup/index_f.php" class="btn btn-warning" style="width: 100%;"><span>SYNC BILL</span></a>
                </div><br>
                <div class="col col-sm-12">
                    <?php if (!userLogined()) { ?>
                        <a href="login.php" class="btn btn-danger" style="width: 100%;"><span>LOGIN</span></a><br>
                    <?php } else { ?>
                        <a href="#" onclick="logOut()" class="btn btn-danger" style="width: 100%;"><span>LOGOUT</span></a><br>
                    <?php } ?>
                </div>
            </div>
        </div>
    </body>
    <script src="js/login.js" type="text/javascript"></script>
</html>