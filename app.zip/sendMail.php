<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

function sendMail($subject,$body){
    
    $mail = new PHPMailer(true);
    try {
        //Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host = 'mail.venrochandana.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth = true;                                   // Enable SMTP authentication
        $mail->Username = 'sales@venrochandana.com';                     // SMTP username
        $mail->Password = 'venro@123';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        //Recipients
        $mail->setFrom('sales@venrochandana.com', 'Venro Chandana');
        $mail->addAddress('danuja.dilanka@gmail.com', 'Venro Chandana'); //info@venrochandana.com
    
        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body = '<h2 style="text-align:center">'.$body.'</h2>';
        $mail->AltBody = $body;
    
        $mail->send();
        $sendStatus = true;
    } catch (Exception $e) {
        //  echo "<h1>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</h1>";
        $sendStatus = false;
    }
    return $sendStatus;
}