<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION["user"]) || (isset($_SESSION["user"]) && $_SESSION["user"] == null)) {
    session_destroy();
    header("location:../login.php");
}