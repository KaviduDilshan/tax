<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php include 'inc/top_header.php'; ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>FIND CUSTOMER</strong></h2>
                <div class="page_single layout_fullwidth_padding">
                    
                    <ul class="responsive_table">
                        <li class="table_row">
                            <div class="table_section" style="width: 250px;">CUSTOMER</div>
                            <div class="table_section_small">DIRECTION</div> 
                        </li>
                        <li class="table_row">
                            <div class="table_section" style="width: 250px;">Web design</div>
                            <div class="table_section_small"><a href="#">FIND</a></div> 
                        </li>
                    </ul>
                    <div class="shop_pagination">
                        <a href="location_view.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="index.php" class="next_shop">HOME</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

