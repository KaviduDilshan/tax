<?php
include_once '../conn.php';
include_once 'sessions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 2%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> CUSTOMER OUTSTANDING </strong></h5></div><br>
        <div class="col col-sm-12">
            <table class="table-bordered" style="width: 100%; background-color: #fff">
                <tr>
                    <th>Cus. Code</th>
                    <th>Amount</th>
                </tr>

                <?php
                $cus_re = "SELECT * FROM `transaction`";
                $result = mysqli_query($conn, $cus_re);
                while ($row = mysqli_fetch_array($result)) {
                    $c_id = $row['c_id'];
                    $tmp_sql = "SELECT sum(sub_total),sum(rturn),sum(discount),sum(paid_amount),sum(paid_cheque) FROM `transaction` WHERE `c_id`=\"$c_id\"";
                    $last_trans_det = mysqli_fetch_assoc(mysqli_query($conn, $tmp_sql));
                    $ous_amount = floatval($last_trans_det["sum(sub_total)"] - ($last_trans_det["sum(rturn)"] + $last_trans_det["sum(discount)"] + $last_trans_det["sum(paid_amount)"] + $last_trans_det["sum(paid_cheque)"]));

                    $code = mysqli_fetch_assoc(mysqli_query($conn, "SELECT customer_code FROM customer WHERE c_id=$c_id"))["customer_code"];
                    ?>
                    <tr>
                        <td><?= $code; ?></td>
                        <td><?= $ous_amount; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </table>
            <br>
            <a href="index.php" class="btn btn-primary" style="width: 100%;">BACK TO HOME</a>
            <br>
        </div>
    </body>
</html>