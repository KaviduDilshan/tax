<div class="pages">
    <div data-page="shopitem" class="page no-toolbar no-navbar">
        <?php include 'inc/top_header.php'; ?>
        <div id="pages_maincontent">  
            <h2 class="page_title">SELECTED VEHICLE DETAILS</h2> 
            <div class="page_single layout_fullwidth_padding">
                <div class="shop_item">
                    <div class="shop_thumb">
                        <div class="swiper-container-team swiper-init" data-effect="slide" data-space-between="10" data-pagination=".swiper-pagination-team" data-slides-per-view="1">

                            <div class="swiper-wrapper">
                                <div class="swiper-slide team-block">
                                    <a rel="gallery-3" href="images/photos/photo1.jpg" title="Photo title" class="swipebox"><img src="images/avatar.jpg" alt="" title="" /></a>
                                </div>
                                <div class="swiper-slide team-block">
                                    <a rel="gallery-3" href="images/photos/photo1.jpg" title="Photo title" class="swipebox"><img src="images/avatar.jpg" alt="" title="" /></a>
                                </div>
                                <div class="swiper-slide team-block">
                                    <a rel="gallery-3" href="images/photos/photo1.jpg" title="Photo title" class="swipebox"><img src="images/avatar.jpg" alt="" title="" /></a>
                                </div>
                                <div class="swiper-slide team-block">
                                    <a rel="gallery-3" href="images/photos/photo1.jpg" title="Photo title" class="swipebox"><img src="images/avatar.jpg" alt="" title="" /></a>
                                </div>
                                <div class="swiper-slide team-block">
                                    <a rel="gallery-3" href="images/photos/photo1.jpg" title="Photo title" class="swipebox"><img src="images/avatar.jpg" alt="" title="" /></a>
                                </div>
                            </div>
                            <div class="swiper-pagination-team"></div>
                        </div>
                        <div class="shop_item_price">$100</div>
                        <a href="#" data-popup="" class="open-popup shopfav"><img src="images/icons/white/like.png" alt="" title="" /></a>
                    </div>
                    <div class="shop_item_details">
                        <h3>Vehicle Title</h3>
                        <p>(Vehical Overview) Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.</p>
                        
                        <div class="page_single layout_fullwidth_padding">
                            <h3><strong>VEHICLE GENARAL DETAILS:</strong></h3>
                            <ul class="responsive_table">
                                <li class="table_row">
                                    <div class="table_section_15">&nbsp;</div>
                                    <div class="table_section_15">&nbsp;</div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Car Brand</div>
                                    <div class="table_section_15">BMW</div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Fule Type</div>
                                    <div class="table_section_15">Petrol</div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Model Year</div>
                                    <div class="table_section_15">2010</div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Seating Capacity</div>
                                    <div class="table_section_15">10 Seats</div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Price Per Day</div>
                                    <div class="table_section_15">Rs. 1,000.00</div>
                                </li>
                            </ul>
                        </div>
                        
                        <div class="page_single layout_fullwidth_padding">
                            <h3><strong>VEHICLE SPECIFICATIONS:</strong></h3>
                            <ul class="responsive_table">
                                <li class="table_row">
                                    <div class="table_section_15">&nbsp;</div>
                                    <div class="table_section_15">&nbsp;</div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Air Conditioner</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Power Steering</div>
                                    <div class="table_section_15"><img src="images/icons/2.2.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">CD Player</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Power Door Locks</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Driver Airbag</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Central Locking</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">AntiLock Braking Sys.</div>
                                    <div class="table_section_15"><img src="images/icons/2.2.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Passenger Airbag</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Crash Sensor</div>
                                    <div class="table_section_15"><img src="images/icons/2.2.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Brake Assist</div>
                                    <div class="table_section_15"><img src="images/icons/1.1.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Power Windows</div>
                                    <div class="table_section_15"><img src="images/icons/2.2.png" alt="" title="" /></div>
                                </li>
                                <li class="table_row">
                                    <div class="table_section_15">Leather Seats</div>
                                    <div class="table_section_15"><img src="images/icons/2.2.png" alt="" title="" /></div>
                                </li>
                            </ul>
                        </div>
                        
                        <a href="cart.php" class="button_full btyellow">I NEED TO HIRE</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>