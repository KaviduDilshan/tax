<?php
include 'sessions.php';
include_once '../inc/functions.php';
$user_det = getUserDet($conn, ($_GET["c"]));
$last_trans_det = getLastTransDetByCCode($conn, 0, $user_det["customer_code"]);
if (isset($_SESSION['from_home'])) {
    unset($_SESSION['from_home']);
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Returns</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
<!--        <link href="new/fonts.css" rel='stylesheet' type='text/css'/>
        <link href="new/fonts2.css" rel='stylesheet' type='text/css'>-->
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
    </head>
    <body style="padding-top: 2%;">
        <form action="data/return.php" method="post" class="form-horizontal">
            <?php $user_det = getUserDet($conn, ($_GET["c"])); ?>
            
            <a href="../app/bill_preview.php?c=<?= ($_GET["c"]) ?>&invoice=<?= base64_encode($last_trans_det["invoice"]) ?>&new_invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>">
                <button type="button" class="form-control btn-sm btn-primary" style="font-size: 15px;">Preview Old Bill - <strong>( <?php echo $user_det['customer_code']; ?> ) </strong></button></a>
            <br>
            <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
            <input type="text" value="<?= $_GET["r_id"] ?>" name="r" readonly required hidden>
            <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
            <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
            <div class="span12" style="padding:2%;">
                <input class="form-control" type="number" name="pro_price" Placeholder="Unit Price" style="margin-bottom:2%; height: 50px; font-size: 15px;"/>
                <input class="form-control" type="number" name="rqty" Placeholder="QTY" style="margin-bottom:2%; height: 50px; font-size: 15px;"/>
                <button type="submit" name="add" class="form-control btn-sm btn-primary" style="font-size: 15px; background-color: #007aff;">ADD RETURN ITEMS - <strong>( <?php echo $user_det['customer_code']; ?> ) </strong></button><br>
            </div>
        </form>
        <div id="content">
            <div class="">
                <div class="row-fluid" style="background-color: #fff; padding: 2%;">
                    <div class="span8" >
                        <div style="">
                            <table class="table table-bordered " id="tab_logic" data-responsive="table" style="">
                                <thead>
                                    <tr>
                                        <th style="font-size:14px; color:#000;"> PRICE</th>
                                        <th style="font-size:14px; color:#000;"> QTY </th>
                                        <th style="font-size:14px; color:#000;"> TOTAL </th>
                                        <th style="font-size:14px; color:#000;"> # </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $url = "?r_id=" . $_GET["r_id"] . "&c=" . $_GET["c"] . "&invoice=" . $_GET["invoice"];
                                    $loop = 1;
                                    $sales_re = getReturnByInvoice($conn, base64_decode($_GET["invoice"]));
                                    while ($row = mysqli_fetch_array($sales_re)) {
                                        ?>
                                        <tr class="record" id="re_row_<?= $loop ?>">
                                            <td style="font-size:15px; color:#000;"><?= number_format($row["unit_price"], 2, ".", ",") ?></td>
                                            <td style="font-size:15px; color:#000;"><?= $row["quantity"] ?></td>
                                            <td style="font-size:15px; color:#000;"><?= number_format($row["total"], 2, ".", ",") ?></td>
                                            <td style="width:12%;"><a href="#"><button type="button" class="btn-sm btn-warning" style="height: 20px ;text-align: center; background-color: #9d0000;" onclick="delFromReturn('<?= base64_encode($row["r_id"]) ?>', '<?= $loop ?>')"></button></a></td>
                                        </tr>
                                        <?php
                                        $loop++;
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                        <div class="form-group2" style="margin-left: 3%; margin-top: 5%;">
                            <a href="select_customer.php<?= $url ?>" name="save_bill" class="btn btn-warning" style="width: 45%">Back</a>
                            <a href="billing2.php<?= $url ?>" class="btn btn-primary" style="width: 50%">Continue</a>
                            <br><br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="new/js/jquery.nicescroll.js"></script>
        <script src="new/js/scripts.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="new/js/bootstrap.min.js"></script>
        <!-- /Bootstrap Core JavaScript -->	   
        <!-- morris JavaScript -->	
        <script src="new/js/raphael-min.js"></script>
        <script src="js/return.js" type="text/javascript"></script>
        <script src="new/js/morris.js"></script>
        <script>
                                                function reduceBal() {
                                                    localStorage.setItem("ch", $("#balance").val());
                                                    $("#balance").val("0.00");
                                                    document.getElementById("chec").setAttribute("onclick", "rec()");
                                                }
                                                function rec() {
                                                    $("#balance").val(localStorage.getItem("ch"));
                                                    localStorage.removeItem("ch");
                                                    document.getElementById("chec").setAttribute("onclick", "reduceBal()");
                                                }
                                                $('#paid_amount').on('input', function () {
                                                    var paid_amount = $(this).val();
                                                    var sub_total = $("#total").val();
                                                    var balance = (sub_total - paid_amount).toFixed(2);
                                                    $("#balance").val(balance);
                                                });
        </script>
    </body>
</html>