<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            session_start();
            include 'inc/top_header.php';
            include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>RETURN HISTORY</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <ul class="responsive_table">
                        <li class="table_row">
                            <div class="table_section_small" style="width: 15px;">#</div>
                            <div class="table_section_small">BILL</div>
                            <div class="table_section">DATE</div>
                            <div class="table_section_small">TOTAL</div>
                        </li>
                        <?php
                        $ret_re = getReturnsByUser($conn, $_SESSION["user"]["a_id"]);
                        while ($row = mysqli_fetch_array($ret_re)) {
                            $trans_det = getTransDetByInvoice($conn, $row["invoice"]);
                            if ($trans_det != null) {
                                $cus_det = getUserDet($conn, $trans_det["c_id"]);
                                ?>
                                <li class="table_row">
                                    <div class="table_section_small text-right" style="width: 15px; color: green;"><strong>#</strong></div>
                                    <div class="table_section_small"><?= $trans_det["t_id"] ?></div>
                                    <div class="table_section"><?= explode(" ", $row["date"])[0] ?></div> 
                                    <div class="table_section_small"><?= number_format($row["total"], 2, ".", ",") ?></div> 
                                </li>
                                <?php
                            }
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="history.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="index.php" class="next_shop">HOME</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>