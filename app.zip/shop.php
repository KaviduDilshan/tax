<?php
include_once '../conn.php';
include_once '../inc/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 2%;">
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> AVAILABLE PRODUCT LIST </strong></h5></div><br>
        <div class="col col-sm-12">
            <?php
            $pro = 1;
            $limit = 10;
            $tot_pro = mysqli_num_rows(getProducts($conn));
            if (isset($_GET["p"])) {
                $pro_no = intval(base64_decode($_GET["p"]));
                if ($pro_no > 0) {
                    $pro = $pro_no;
                }
            }
            $pro_re = getProducts($conn, $limit, $pro - 1);
            ?>
            <table class="table-bordered" style="width: 100%; background-color: #fff">
                <tr>
                    <th>Product. Code</th>
                    <th>Selling Price</th>
                </tr>
                <?php
                while ($pro_det = mysqli_fetch_array($pro_re)) {
                    ?>
                    <tr>
                        <td><?= $pro_det["product_name"] ?></td>
                        <td><?= number_format($pro_det["unit_price"], 2, ".", ",") ?></td>
                    </tr>
                <?php } ?>
            </table>
            <br>
            <div class="shop_pagination">
                <a href="shop.php?p=<?= ($pro > 1) ? base64_encode($pro - $limit) : base64_encode(1) ?>" class="prev_shop btn btn-warning" style="width: 42%;">PREV PAGE</a>
                <span class="shop_pagenr" style="width: 10%;"><?= (($pro - 1) + $limit) . "/" . $tot_pro ?></span>
                <a href="shop.php?p=<?= base64_encode($pro + $limit) ?>" class="next_shop btn btn-success" style="width: 42%;">NEXT PAGE</a>
            </div>
            <br>
            <a href="index.php" class="btn btn-primary" style="width: 100%;">BACK TO HOME</a>
            <br>
        </div>
    </body>
</html>