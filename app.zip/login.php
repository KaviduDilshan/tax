<!DOCTYPE HTML>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
<!--        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>-->
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head> 
    <body>
        <div class="main-wthree">
            <div class="container">
                <div class="sin-w3-agile">
                    <h2>Sign In</h2>
                    <div class="username">
                        <input type="text" name="Username" value="" class="name" placeholder="username" required="" style="width:100%;"/>
                        <div class="clearfix"></div>
                    </div>
                    <div class="password-agileits">
                        <input type="password" name="Password" value="" class="password" placeholder="password" required="" style="width:100%;"/>
                        <div class="clearfix"></div>
                    </div>
                    <div class="">
                        <input onclick="login()" class="btn btn-warning login" id="log_btn" value="LOGIN" readonly style="width:100%;"/>
                    </div>
                    <div class="clearfix"></div>
                    <br><br>
                    <div class="footer">
                        <p>&copy; Developed by <a href="https://tritcal.com">Tritcal International</a></p>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script type="text/javascript" src="js/login.js"></script>
</html>