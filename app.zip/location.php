<div class="pages">
    <div data-page="contact" class="page no-toolbar no-navbar">
        <div class="page-content">

            <?php include 'inc/top_header.php'; ?>

            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>SETUP NEW LOCATION</strong></h2>
                <div class="page_single layout_fullwidth_padding">
                    <iframe src="../admin/loc/user-map.php" width="100%" height="500" frameborder="0" style="border:0"></iframe> 
                    <div class="clear"></div>
                    <div class="shop_pagination">
                        <a href="location_view.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="index.php" class="next_shop">HOME</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>