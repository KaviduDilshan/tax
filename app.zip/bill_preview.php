<?php
include_once '../inc/functions.php';
if (isset($_GET["c"]) && isset($_GET["invoice"])) {
    $invoice = base64_decode($_GET["invoice"]);
    $customer = $_GET["c"];
    $user_det = getUserDet($conn, ($_GET["c"]));
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <title>Old Bill</title>
            <meta charset="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
            <!-- Custom CSS -->
            <link href="new/css/style.css" rel='stylesheet' type='text/css' />
            <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
            <!-- Graph CSS -->
            <link href="new/css/font-awesome.css" rel="stylesheet"> 
            <!-- jQuery -->
            <script src="new/js/jquery-2.1.4.min.js"></script>
            <!-- //jQuery -->
            <!--        <link href="new/fonts.css" rel='stylesheet' type='text/css'/>
                    <link href="new/fonts2.css" rel='stylesheet' type='text/css'>-->
            <!-- lined-icons -->
            <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        </head>
        <body style="padding-top: 0%;">
            <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong>BILL PREVIEW</strong> ( <strong><?= $user_det["customer_code"] ?></strong> )</h5></div><br>
            <div id="content">
                <?php
                include 'sessions.php';
                if (isset($_SESSION['from_home'])) {
                    unset($_SESSION['from_home']);
                }
                $trans_det = getTransDetByInvoice($conn, $invoice);
                $user_det = getUserDet($conn, $user_det["c_id"]);
                if ($trans_det != null) {
                    $c_id = $user_det["c_id"];
                    $this_t_id = intval($trans_det["t_id"]);
                    ?>
                    <div class="container-fluid">
                        <div class="row-fluid">
                            <div class="span8">
                                <div style="">
                                    <table class="table table-bordered " id="tab_logic" data-responsive="table" style="">
                                        <thead>
                                            <tr>
                                                <th> Co</th>
                                                <th> Pr</th>
                                                <th> Qty </th>
                                                <th> U. Price </th>
                                                <th> Total </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $g_tot = 0;
                                            $ret_det = getReturnDet($conn, $invoice);
                                            $ous_det = getUserTrans($conn, $c_id);
                                            $query = "SELECT MAX(t_id) FROM transaction WHERE t_id=$this_t_id AND c_id=$c_id";
                                            $prev_trans_t_id = mysqli_fetch_assoc(mysqli_query($conn, $query))["MAX(t_id)"];
                                            $last_trans_det = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM transaction WHERE t_id='$prev_trans_t_id'"));
                                            $ous_amount = floatval($last_trans_det["ous"]);
                                            $tot_b = floatval($last_trans_det["total"]);
                                            $balance = floatval($last_trans_det["balance"]);
                                            $re_tot = floatval($ret_det["SUM(total)"]);
                                            $date_last = $last_trans_det["transaction_date"];
                                            $loop = 1;
                                            $sales_re = getSalesByInvoice($conn, $invoice);
                                            $sub_tot = 0;
                                            while ($row = mysqli_fetch_array($sales_re)) {
                                                $pro_id = $row["pro_id"];
                                                $pro_det = getProDet($conn, $pro_id);
                                                $sub_tot += (floatval($row["quantity"]) * $row["unit_price"]);
                                                $fqty = '';
                                                $freeTot = getFreeItem($conn, $pro_id, $invoice);
                                                if ($freeTot > 0) {
                                                    $fqty = ' - ( ' . $freeTot . ' )';
                                                }
                                                ?>
                                                <tr class="record">
                                                    <td style="color: #000;"><?= $pro_det["barcode"] ?></td>
                                                    <td style=""><input type="text" style="width: 70px; text-align: right; color: #000; height: 30px;" value='<?= $pro_det["product_name"] . $fqty ?>' class="span12" readonly=""/></td>
                                                    <td style=""><input type="text" style="width: 40px; text-align: center; color: #000; height: 30px;" name="srow_quantity" id="srow_quantity" value='<?= $row["quantity"] ?>' class="span12 qty" readonly=""/></td>
                                                    <td style=""><input type="text" style="width: 70px; text-align: right; color: #000; height: 30px;" value='<?= number_format($row["unit_price"], 2, ".", ",") ?>' class="span12 row_total" readonly=""/></td>
                                                    <td style=""><input type="text" style="width: 70px; text-align: right; color: #000; height: 30px;" value='<?= number_format($row["total"], 2, ".", ",") ?>' class="span12 row_total" readonly=""/></td>
                                                </tr>
                                                <?php
                                                $loop++;
                                            }
                                            $ous_amount2 = $tot_b - ($sub_tot + $re_tot);
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="span4">
                                <div style="background-color: #fff; padding: 2%;">
                                    <table class="table table-bordered" id="tab_logic_total" style="border: none">
                                        <tbody>
                                            <tr>
                                                <th class="text-right" style="width: 40%; font-size: 15px;">Sub Total</th>
                                                <td class="form-group2">
                                                    <input type="text" id="sub_total" style="height: 30px; width: 100%; font-size: 14px; color: #000;" value="<?= number_format($sub_tot, 2, ".", ",") ?>" readonly autocomplete="off"/>
                                                </td>
                                            </tr>
                                            <?php
                                            if ($user_det["credit_accept"] != 0) {
                                                $g_tot += $ous_amount;
                                                ?>
                                                <tr>
                                                    <th class="text-right" style="width: 40%; font-size: 15px;">Outstanding</th>
                                                    <td class="form-group2">
                                                        <input type="text" id="other_dis" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name="other_dis" value="<?= number_format($ous_amount2, 2, ".", ",") ?>" placeholder="0.00" readonly autocomplete="off"/>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                            <tr>
                                                <th class="text-right" style="width: 40%; font-size: 15px;">Bill Amount</th>
                                                <td class="form-group2">
                                                    <input type="text" id="bill_amount_tmp" style="height: 30px; width: 100%; font-size: 14px; color: #000;" value="<?= number_format($tot_b, 2, ".", ",") ?>" readonly autocomplete="off"/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="text-right" style="width: 40%; font-size: 15px;">Paid</th>
                                                <td class="form-group2">
                                                    <input type="text" step=".01" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name="paid_amount_cash" class="calcBal" id="paid_amount_cash" value='<?= number_format(floatval($trans_det["paid_amount"]), 2, ".", ",") ?>' autocomplete="off"/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="form-group2 text-right" style="width: 40%; font-size: 15px;">Balance</th>
                                                <td class="form-group2 mb10">
                                                    <input type="text" style="height: 30px; width: 100%; font-size: 14px; color: #000;" name="balance" value="<?= number_format($balance, 2, ".", ",") ?>" id="balance" class="balance" placeholder='0.00' readonly autocomplete="off"/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="text-right" style="width: 40%; font-size: 15px;">Return</th>
                                                <td class="form-group2">
                                                    <input type="text" style="height:30px; width: 100%; font-size: 14px; color: #000;" readonly value="<?= number_format($re_tot, 2, ".", ",") ?>" autocomplete="off">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="form-group2" style="margin-left: 0%; margin-top: 5%;">
                                        <a class="form-control btn-sm btn-primary" href="bill_print/woosim/print.php<?= "?c=" . ($_GET["c"]) . "&r=" . $_GET["r"] . "&invoice=" . $_GET["invoice"] . "&new_invoice=" . $_GET["new_invoice"] ?>&type=3"  class="prev_shop">Print</a><br>
                                        <a class="form-control btn-sm btn-default" href="../app/return2.php<?= "?c=" . ($_GET["c"]) . "&r=" . $_GET["r"] . "&invoice=" . $_GET["new_invoice"] ?>" >Back</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </body>
        </html>
        <?php
    }
}?>