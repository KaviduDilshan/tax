<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
          //  include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>FINAL STEP - PRINT BILL</strong></h2>
                <div class="contactform">
                    <form method="post" action="data/transaction.php">
                        <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                        <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                        <input type="text" value="<?= $_GET["c"] ?>" name="c" readonly required hidden>
                        <input type="text" value="<?= $_GET["cat"] ?>" name="cat" readonly required hidden>
                        <div class="page_single layout_fullwidth_padding">

                            <ul class="responsive_table">
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;">#</div>
                                    <div class="table_section">ITEM</div>
                                    <div class="table_section_small">QTY</div> 
                                    <div class="table_section_small">PRICE</div>
                                    <div class="table_section_small">TOTAL</div>
                                </li>
                                <?php
                                $invoice = base64_decode($_GET["invoice"]);
                                $ret_det = getReturnDet($conn, $invoice);
                                $ous_det = getUserTrans($conn, ($_GET["c"]));
                                $user_det = getUserDet($conn, ($_GET["c"]));
                                $ous_amount = floatval($ous_det["SUM(total)"]) - floatval($ous_det["SUM(paid_amount)"]);
                                $re_tot = floatval($ret_det["SUM(total)"]);
                                $loop = 1;
                                $sales_re = getSalesByInvoice($conn, base64_decode($_GET["invoice"]));
                                $sub_tot = 0;
                                while ($row = mysqli_fetch_array($sales_re)) {
                                    $pro_id = $row["pro_id"];
                                    $pro_det = getProDet($conn, $pro_id);
                                    $sub_tot += (floatval($row["quantity"]) * $pro_det["unit_price"]);
                                    ?>
                                    <li class="table_row" id="s_row_<?= $loop ?>">
                                        <div class="table_section_small text-right" onclick="delFromCart('<?= base64_encode($row["sales_id"]) ?>', '<?= $loop ?>','<?= $_GET["c"] ?>')" style="width: 15px; color: red;"><strong>X</strong></div>
                                        <div class="table_section"><?= $pro_det["product_name"] ?></div>
                                        <div class="table_section_small"><?= $row["quantity"] ?></div> 
                                        <div class="table_section_small"><?= number_format($pro_det["unit_price"], 2, ".", ",") ?></div>
                                        <div class="table_section_small"><?= number_format($row["total"], 2, ".", ",") ?></div> 
                                    </li>
                                    <?php
                                    $loop++;
                                }
                                $g_tot = $sub_tot - $re_tot;
                                ?>
                                <li class="table_row" style="margin-top: 10px;">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Sub Total</strong> </div>
                                    <div class="table_section_small"><strong>-</strong></div> 
                                    <div class="table_section_small2"><strong id="sub_tot"><?= number_format($sub_tot, 2, ".", ",") ?></strong></div> 
                                </li>
                                <!--                        <li class="table_row">
                                                            <div class="table_section_small" style="width: 15px;"> - </div>
                                                            <div class="table_section"> <strong>Discount</strong> </div>
                                                            <div class="table_section_small"><strong>10%</strong></div> 
                                                            <div class="table_section_small2"><strong>150.00</strong></div> 
                                                        </li>-->
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Return</strong> </div>
                                    <div class="table_section_small"><strong id="re_qty"> <?= floatval($ret_det["SUM(quantity)"]) ?> </strong></div> 
                                    <div class="table_section_small2"><strong id="re_tot"><?= number_format($re_tot, 2, ".", ",") ?></strong></div> 
                                </li>
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Free Items</strong> </div>
                                    <div class="table_section_small"><strong id="free_sales"> <?= floatval(getFreeSales($conn, $invoice)["SUM(quantity)"]) ?> </strong></div> 
                                    <div class="table_section_small2"><strong></strong></div> 
                                </li>
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Total Amount</strong> </div>
                                    <div class="table_section_small"><strong> - </strong></div> 
                                    <div class="table_section_small2"><strong id="tot_amount"><?= number_format($g_tot, 2, ".", ",") ?></strong></div> 
                                </li>
                                <?php
                                if ($user_det["credit_accept"] != 0) {
                                    $g_tot = ($sub_tot + $ous_amount) - $re_tot;
                                    ?>
                                    <li class="table_row">
                                        <div class="table_section_small" style="width: 15px;"> - </div>
                                        <div class="table_section"> <strong>Oustanding</strong> </div>
                                        <div class="table_section_small"><strong> - </strong></div> 
                                        <div class="table_section_small2"><strong id="ous"><?= number_format($ous_amount, 2, ".", ",") ?></strong></div> 
                                    </li>
                                    <li class="table_row">
                                        <div class="table_section_small" style="width: 15px;"> - </div>
                                        <div class="table_section"> <strong>Grand Total</strong> </div>
                                        <div class="table_section_small"><strong> - </strong></div> 
                                        <div class="table_section_small2"><strong id="grand_tot"><?= number_format($g_tot, 2, ".", ",") ?></strong></div> 
                                    </li>
                                <?php } ?>
                                <input type="text" value="<?= floatval($g_tot) ?>" name="g_tot" id="g_tot" readonly required hidden>
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Paid Amount</strong> </div>
                                    <div class="table_section_small"><input type="text" id="pay_amount" name="pay_amount"></div> 
                                </li>
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Balance</strong> </div>
                                    <div class="table_section_small"><strong> - </strong></div> 
                                    <div class="table_section_small2"><strong><span id="balance"><?= number_format($g_tot, 2, ".", ",") ?></span></strong></div> 
                                </li>
                                <li class="table_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Payment Type</strong> </div>
                                    <div class="table_section_small">
                                        <select class="cs-select cs-skin-overlay" id="pay_type" name="pay_type" style="width:360%;" required>
                                            <option value="1">Cash</option>
                                            <option value="2">Cheque</option>
                                        </select>
                                    </div> 
                                </li>
                                <li class="table_row" id="check_no_row">
                                    <div class="table_section_small" style="width: 15px;"> - </div>
                                    <div class="table_section"> <strong>Cheque No</strong> </div>
                                    <div class="table_section_small"><input type="text" name="cheque_no"></div> 
                                </li>
                            </ul>
                            <input type="submit" name="add" class="form_submit" id="submit" value="PRINT" />
                        </div>
                    </form>
                    <div class="shop_pagination">
                        <a href="return.php?invoice=<?= $_GET["invoice"] ?>&r=<?= $_GET["r"] ?>&c=<?= $_GET["c"] ?>&cat=<?= $_GET["cat"] ?>" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'inc/footer.php';

