function redirectTo(url) {
    window.location.href = url;
}
$(document).on('input', '.counts', function () {
    var ele = $(this);
    var c_counts = ele.attr("name");
    var c_count = parseInt(ele.val());
    var cash = parseInt(c_counts.split("_")[1]);
    var calc = c_count * cash;
    $("input[name='total_" + cash + "']").val(calc);
});
$(document).on('input', '#pay_amount', function () {
    var pay_amount = parseFloat($(this).val());
    var sub_tot = parseFloat($("input[name='g_tot']").val());
    var calc = 0;
    if (!isNaN(pay_amount)) {
        calc = sub_tot - pay_amount;
    }
    $("#balance").html(calc.toFixed(2));
});