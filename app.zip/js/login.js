function login() {
    var username = $("input[name='Username']").val();
    var password = $("input[name='Password']").val();
    $("#log_btn").attr("disabled", "true");
    $.ajax({
        url: "data/login.php",
        Type: "GET",
        data: {"username": username, "password": password},
        success: function (data) {
            $("#log_btn").removeAttr("disabled");
            var obj = JSON.parse(data);
            var err = parseInt(obj["error"]);
            if (err === 0) {
                window.location.href = "../app/index.php";
            }
        }
    });
}
function logOut() {
    $.ajax({
        url: "data/logout.php",
        Type: "GET",
        data: {"status": 1},
        success: function () {
            window.location.href = "../app/login.php";
        }
    });
}