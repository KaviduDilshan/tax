function delFromReturn(the_key, the_row) {
    $.ajax({
        url: "data/return.php",
        Type: "GET",
        data: {"del": 1, "re": the_key},
        success: function (data) {
            var obj = JSON.parse(data);
            var err = parseInt(obj["error"]);
            if (err === 0) {
               location.reload();
            }
        }
    });
}