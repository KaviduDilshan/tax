function addToCart(the_key, tot_dis_id) {
    var qty = $("#qty_" + the_key).val();
    var f_qty = $("#fqty_" + the_key).val();
    var pro = $("#pro_" + the_key).val();
    var u_price = $("#price_" + the_key).val();
    var invoice = $("#invoice").val();
    $.ajax({
        url: "data/add_to_cart.php",
        Type: "GET",
        data: {"qty": qty,"u_price":u_price, "f_qty": f_qty, "pro": pro, "invoice": invoice},
        success: function (data) {
            location.reload();
         //   var obj = JSON.parse(data);
          //  $("#" + tot_dis_id).html(obj["total"]);
          //  $("#qty_" + the_key).val("");
          //  $("#fqty_" + the_key).val("");
        }
    });
}
function delFromCart(the_key, the_row,cus) {
    $.ajax({
        url: "data/add_to_cart.php",
        Type: "GET",
        data: {"del": 1, "s": the_key,"cus":cus},
        success: function (data) {
            var obj = JSON.parse(data);
            var err = parseInt(obj["error"]);
            if(err === 0){
                var sub_tot=obj["sub_tot"];
                var free_sales=obj["free_sales"];
                var tot_amount=obj["tot_amount"];
                var ous=obj["ous"];
                var g_tot=obj["g_tot"];
                $("#sub_tot").html(obj["sub_tot"]);
                $("#re_qty").html(obj["re_qty"]);
                $("#re_tot").html(obj["re_tot"]);
                $("#free_sales").html(obj["free_sales"]);
                $("#tot_amount").html(obj["tot_amount"]);
                
                var ous_ele=document.getElementById("ous");
                if(ous_ele != null){
                    ous_ele.innerHTML=obj["ous"];
                }
                var g_tot_ele = document.getElementById("grand_tot");
                if(g_tot_ele != null){
                    g_tot_ele.innerHTML=obj["g_tot"];
                }
                
                $("#g_tot").val(obj["g_tot"]);
                $("#balance").html('0.00');
                $("#s_row_"+the_row).remove();
            }
        }
    });
}