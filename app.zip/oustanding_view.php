<div class="pages">
    <div data-page="shop" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php
            include 'inc/top_header.php';
            include 'sessions.php';
            ?>
            <div id="pages_maincontent">
                <h2 class="page_title" style="text-align: center;"><strong>OUSTANDING LIST</strong></h2>
                <div class="page_single layout_fullwidth_padding">

                    <ul class="responsive_table">
                        <li class="table_row">
                            <div class="table_section">C.CODE</div>
                            <div class="table_section">AMOUNT</div>
                            <div class="table_section_small">ACTION</div>
                        </li>
                        <?php
                        $ous_re = getCusOus($conn);
                        foreach ($ous_re as $key => $value) {
                            $data = explode("_", $key);
                            ?>
                            <li class="table_row">
                                <div class="table_section"><?= $data[1] ?></div>
                                <div class="table_section"><?= number_format($value, 2, ".", ",") ?></div>
                                <div class="table_section_small">-</div> 
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                    <div class="shop_pagination">
                        <a href="index.php" class="prev_shop">BACK</a>
                        <span class="shop_pagenr"> </span>
                        <a href="index.php" class="next_shop">HOME</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>