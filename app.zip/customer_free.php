<?php
include_once '../inc/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body>
        <?php
        //include 'sessions.php';
        $invoice = "&invoice=1";
        $in2 = "";
        ?>
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> CUSTOMER DETAILS </strong></h5></div><br>
        <!--<div class="col col-sm-12">-->
            <table class="table-bordered" style="width: 100%; background-color: #fff" data-responsive="table">
                <tr>
                    <th style="width: 10%;">Mobile</th>
                    <th style="width: 10%;">Name</th>
                </tr>

                <?php
                $cus_re = getAllCustomers($conn);
                while ($row = mysqli_fetch_array($cus_re)) {
                    ?>
                    <tr>
                        <td style="width: 10%;"><?= $row["customer_phone"]; ?></td>
                        <td style="width: 10%;"><?= $row["customer_name"]; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </table>
            <br>
            <a href="index.php" class="btn btn-primary" style="width: 100%;">BACK TO HOME</a>
            <br>
        <!--</div>-->
    </body>
</html>