<div class="pages">
    <div data-page="toggle" class="page no-toolbar no-navbar">
        <div class="page-content">
            <?php include 'inc/top_header.php'; ?>
            <div id="pages_maincontent">
                <h2 class="page_title">FAQS</h2>
                <div class="page_single layout_fullwidth_padding">
                    <div class="custom-accordion accordion-list">
                        <div class="accordion-item">
                            <div class="accordion-item-toggle">
                                <i class="icon icon-plus">+</i>
                                <i class="icon icon-minus">-</i>
                                <span>Accordion element one</span>
                            </div>
                            <div class="accordion-item-content">
                                <p>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                                </p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <div class="accordion-item-toggle">
                                <i class="icon icon-plus">+</i>
                                <i class="icon icon-minus">-</i>
                                <span>Accordion element two</span>
                            </div>
                            <div class="accordion-item-content">
                                <p>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                                </p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <div class="accordion-item-toggle">
                                <i class="icon icon-plus">+</i>
                                <i class="icon icon-minus">-</i>
                                <span>Accordion element three</span>
                            </div>
                            <div class="accordion-item-content">
                                <p>
                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                                </p>
                            </div>
                        </div>   
                    </div>  
                </div> <!--end of page single-->  
            </div>
        </div>
    </div>
</div>