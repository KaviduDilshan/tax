<!DOCTYPE html>
<html>
    <head>
        <title>Customers</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- Bootstrap Core CSS -->
        <link href="new/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom CSS -->
        <link href="new/css/style.css" rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="new/css/morris.css" type="text/css"/>
        <!-- Graph CSS -->
        <link href="new/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="new/css/jquery-ui.css"> 
        <!-- jQuery -->
        <script src="new/js/jquery-2.1.4.min.js"></script>
        <!-- //jQuery -->
<!--        <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>-->
        <!-- lined-icons -->
        <link rel="stylesheet" href="new/css/icon-font.min.css" type='text/css' />
        <!-- //lined-icons -->
    </head>
    <body style="margin-top: 2%;">
        <?php
        //include 'sessions.php';
        $invoice = "&invoice=1";
        $in2 = "";
        ?>
        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> SELECT CUSTOMER </strong></h5></div><br>
        <div class="col col-sm-12">
            <div class="row">
                <form id="ContactForm" method="post" action="data/billing.php">
                    <div class="col col-sm-6">
                        <input type="text" value="<?= $_GET["r"] ?>" name="r" readonly required hidden>
                        <?php
                        if (isset($_GET["invoice"]) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
                            $invoice = "&invoice=" . $_GET["invoice"];
                            $in2 = "?invoice=" . $_GET["invoice"];
                            ?>
                            <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                            <?php
                        }
                        if (!isset($_GET["fromCode"])) {
                            ?>
                            <div class="form_row">
                                <label>CUSTOMER CODE:</label>
                                <input type="text" value="" name="customer_code" class="form-control" style="width: 100%; height:50px ;" required><br>
                            </div>
                        <?php } else { ?>
                            <div class="form_row">
                                <label>CUSTOMER CODE:</label>
                                <input type="text" value="<?= trim($_GET["fromCode"]) ?>" name="customer_code" class="form-control" style="width: 100%; height:50px ;" required readonly>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="col col-sm-6">
                        <input type="submit" name="pg_cus" class="btn btn-primary" id="submit" value="NEXT" style="width: 100%; background-color: #007aff;"/>
                        <label id="loader" style="display:none;"><img src="images/loader.gif" alt="Loading..." id="LoadingGraphic" /></label>
                    </div>
                </form>
            </div>
        </div><br>

        <div style="padding: 2%; background-color: #fff; text-align: center;"> <h5><strong> REGISTER NEW CUSTOMER </strong></h5></div><br>
        <div class="col col-sm-12">
            <div class="row">
                <h2 class="page_title" style="text-align: center;"><strong></strong></h2>
                <?php
                if (isset($_GET['err'])) {
                    $err = intval($_GET['err']);
                    ?>
                    <div style="background-color: red;text-align: center;padding: 2%;font-size: 100%;font-weight: bold;color: #fff" id="err_txt">
                        <?php
                        if ($err == 2) {
                            echo 'Invalid Route';
                        } elseif ($err == 1) {
                            echo 'Customer Already Exists';
                        }
                        ?>
                    </div><br>
                    <?php
                }
                ?>
                <form class="cmxform" id="ContactForm" method="post" action="data/customer.php">
                    <div class="col col-sm-6">
                        <?php
                        if (isset($_GET["invoice"]) && ($_GET["invoice"] != null) && ($_GET["invoice"] == $_SESSION["tmp_invoice"])) {
                            $invoice = "&invoice=" . $_GET["invoice"];
                            ?>
                            <input type="text" value="<?= $_GET["invoice"] ?>" name="invoice" readonly required hidden>
                            <?php
                        }
                        ?>
                        <input type="number" name="reg_type" value="1" required readonly hidden/>
                        <label>CUSTOMER CODE:</label>
                        <input type="text" value="" name="customer_code" onchange="$('#err_txt').hide()" class="form-control" style="width: 100%; height:50px ;" required >
                    </div><br>
                    <div class="col col-sm-6">
                        <label>ROUTE:</label>
                        <select class="form-control" style="width: 100%; height:50px ;">
                            <option>sdasdasd</option>
                            <option>sdasdasd</option>
                        </select>
                        <!--<input type="text" name="route" id="route" onchange="$('#err_txt').hide()" class="form-control" style="width: 100%; height:50px ;" required>-->
                    </div><br>
                    <div class="col col-sm-6">
                        <label>OUTSTANDING:</label>
                        <input type="number" step="0.01" name="current_ous" id="current_ous" class="form-control" style="width: 100%; height:50px ;">
                    </div><br>
                    <div class="col col-sm-6">
                        <input type="submit" name="add" class="btn btn-primary" value="REGISTER" style="width: 100%; background-color: #007aff;"/>
                    </div><br>

                </form>
                <br>
                <a href="index.php" class="btn btn-primary" style="width: 100%;">BACK TO HOME</a>
                <br>
            </div>
        </div>     
    </div>
